function Cells_FR_binned = GetFR_SpatialBinned(Cells_spikes,LapStructure,bin_n)

% divide 180 cm into bin_n bins and calculate the firing rate (FR) of each bin
% create a 3D array containing binned dFoF by lap for each cell
% bin_size: size of each spatial bin, in cm

Cells_FR_binned = [];
bin_size = 180/bin_n;

for i = 1:size(Cells_spikes,1)
    EachCell_FR_binned_mean_by_lap = [];
    for k = 1:numel([LapStructure.LapNumber])
        Distance_frame_running = [];
        EachCell_spikes_each_lap = Cells_spikes(i,[LapStructure(k).FrameNumber_running]);
        SpatialBin_edges_centimeter = 0:bin_size:180;
        SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
        Distance_frame_running = LapStructure(k).Distance_frame_running;
        first_index = find(Distance_frame_running < 0.1, 1);
        if ~isempty(first_index)
            if first_index ~= 1
                Distance_frame_running(1:(first_index-1)) = Distance_frame_running(first_index);
            end
        end
        SpatialBin_indices = discretize(Distance_frame_running,SpatialBin_edges_meter);
        EachCell_FR_by_bin_mean = [];
        for j = 1:bin_n
            Indices_in_bins = find(SpatialBin_indices == j);
            spikes_in_bin = [];
            spikes_in_bin = EachCell_spikes_each_lap(Indices_in_bins);
            FR_bin = [];
            if ~isempty(spikes_in_bin)
                FR_bin = sum(spikes_in_bin(:))/(numel(spikes_in_bin)/30);
            else
                FR_bin = NaN;
            end
            EachCell_FR_by_bin_mean = [EachCell_FR_by_bin_mean,FR_bin];
        end
        EachCell_FR_binned_mean_by_lap = [EachCell_FR_binned_mean_by_lap;EachCell_FR_by_bin_mean];
    end
    Cells_FR_binned = cat(3,Cells_FR_binned,EachCell_FR_binned_mean_by_lap);
end
end