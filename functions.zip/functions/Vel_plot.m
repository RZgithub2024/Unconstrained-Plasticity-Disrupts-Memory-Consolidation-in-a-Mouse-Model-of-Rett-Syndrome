function [Vel_by_lap,Mean_velocity] = Vel_plot(LapStructure,WS,folderpath)

% Velocity plot of the entire session
Vel_by_lap = [];
for k = 1:numel([LapStructure.LapNumber])
    Distance_running = [];
    Vel_each_lap = [];
    Vel_each_lap = [LapStructure(k).Velocity_running];
    SpatialBin_edges_centimeter = 0:3.6:180;
    SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
    Distance_running = LapStructure(k).Distance_running;
    first_index = find(Distance_running < 0.1, 1);
    if ~isempty(first_index)
       if first_index ~= 1
          Distance_running(1:(first_index-1)) = Distance_running(first_index);
       end
    end
    SpatialBin_indices = discretize(Distance_running,SpatialBin_edges_meter);
    Vel_by_bin = [];
    for j = 1:50
        Indices_in_bins = find(SpatialBin_indices == j);
        Vel_by_bin = [Vel_by_bin,mean(Vel_each_lap(Indices_in_bins))];
    end
    Vel_by_lap = [Vel_by_lap;Vel_by_bin];
end

Mean_velocity = nanmean(Vel_by_lap,1);

fig = figure('Visible', 'off');
hold on;
for i=1:size(Vel_by_lap,1)
    plot(Vel_by_lap(i,:),'Color',[0.8 0.8 0.8],'LineWidth',0.1)    
end
plot(Mean_velocity,'blue','LineWidth',1);
newxticks = [0,12.5,25,37.5,50];  % Replace with your desired positions
newxticklabels = {'0','45','90','135','180'};  % Replace with your desired labels
xticks(newxticks);
xticklabels(newxticklabels);
ylim([0,70]);
xlabel('Position (cm)');
ylabel('Velocity (cm/s)');
xline(25,'-k',{'Reward'},'LineWidth',1);
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);
hold off;

filename = 'Mean_velocity.png';
fullpath = fullfile(folderpath,filename);
saveas(fig, fullpath);

end