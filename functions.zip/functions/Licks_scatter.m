function AnticiLicks_Prob = Licks_scatter(LapStructure,WS,folderpath)

% scatter plot of licks
% Reward_location = nanmean([LapStructure.RewardDeliveryLocation]) * 100;
AnticiLicks_180_bins_scatter_x = [];
AnticiLicks_180_bins_scatter_y = [];
RewardLocations = [];
for k = 1:numel([LapStructure.LapNumber])
        EachCell_licks_each_lap = [LapStructure(k).LickingLocation];
        SpatialBin_edges_180_centimeter = 0:180;
        SpatialBin_edges_180_meter = SpatialBin_edges_180_centimeter / 100;
        SpatialBin_indices = discretize(EachCell_licks_each_lap,SpatialBin_edges_180_meter);
        AnticiZone_left = floor([LapStructure(k).RewardDeliveryLocation] * 100 - 10.8);
        AnticiZone_right = floor([LapStructure(k).RewardDeliveryLocation] * 100);
        RewardLocations = [RewardLocations,[LapStructure(k).RewardDeliveryLocation] * 100];
        for j = (AnticiZone_left + 1):AnticiZone_right
            if numel(find(SpatialBin_indices == j)) > 0
               AnticiLicks_180_bins_scatter_x = [AnticiLicks_180_bins_scatter_x,(j-0.5)];
               AnticiLicks_180_bins_scatter_y = [AnticiLicks_180_bins_scatter_y,k];   
            end
        end
end


OutAnticiLicks_180_bins_scatter_x = [];
OutAnticiLicks_180_bins_scatter_y = [];
for k = 1:numel([LapStructure.LapNumber])
        EachCell_licks_each_lap = [LapStructure(k).LickingLocation];
        SpatialBin_edges_180_centimeter = 0:180;
        SpatialBin_edges_180_meter = SpatialBin_edges_180_centimeter / 100;
        SpatialBin_indices = discretize(EachCell_licks_each_lap,SpatialBin_edges_180_meter);
        AnticiZone_left = floor([LapStructure(k).RewardDeliveryLocation] * 100 - 10.8);
        AnticiZone_right = floor([LapStructure(k).RewardDeliveryLocation] * 100);
        for j = 1:AnticiZone_left
            if numel(find(SpatialBin_indices == j)) > 0
               OutAnticiLicks_180_bins_scatter_x = [OutAnticiLicks_180_bins_scatter_x,(j-0.5)];
               OutAnticiLicks_180_bins_scatter_y = [OutAnticiLicks_180_bins_scatter_y,k];
            end
        end
        for i = (AnticiZone_right + 1):180
            if numel(find(SpatialBin_indices == i)) > 0
               OutAnticiLicks_180_bins_scatter_x = [OutAnticiLicks_180_bins_scatter_x,(i-0.5)];
               OutAnticiLicks_180_bins_scatter_y = [OutAnticiLicks_180_bins_scatter_y,k];
            end
        end
end

fig = figure('Visible', 'off');
scatter(OutAnticiLicks_180_bins_scatter_x,OutAnticiLicks_180_bins_scatter_y,20,"black","filled");
set(gca,'Ydir','reverse');
xlim([-0.4 180]);
LapNumber = numel([LapStructure.LapNumber]);
ylim([1 (LapNumber+0.4)]);
newyticks = [1,LapNumber];
newyticklabels = {'1',num2str(LapNumber)};
yticks(newyticks);
xlabel('Position (cm)');
ylabel('Laps');
hold on;
scatter(AnticiLicks_180_bins_scatter_x,AnticiLicks_180_bins_scatter_y,20,"red","filled");
legend('Non-anticipatory licks','Anticipatory licks','Location','northeastoutside');
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);

% label the reward delivery location
% for i = 1:numel(RewardLocations)
%     plot([RewardLocations(i), RewardLocations(i)], [i - 0.3, i + 0.3],...
%         'b-', 'LineWidth', 3,'HandleVisibility', 'off');
% end

% Probability of anticipatory licks 
AnticiLicks_laps = unique(AnticiLicks_180_bins_scatter_y);
AnticiLicks_Prob = numel(AnticiLicks_laps)/numel([LapStructure.LapNumber]);

filename = 'LicksByLap.png';
fullpath = fullfile(folderpath,filename);
saveas(fig, fullpath);

end