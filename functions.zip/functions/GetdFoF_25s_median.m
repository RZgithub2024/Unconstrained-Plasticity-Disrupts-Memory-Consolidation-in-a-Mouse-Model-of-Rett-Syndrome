function [Cells_F_smoothed,Cells_F0_median,Cells_dFoF_median] = GetdFoF_25s_median(Cells_F)

% smooth the raw F
Cells_F_smoothed = [];
for i = 1:size(Cells_F,1)
    Cells_F_smoothed(i,:) = smooth(Cells_F(i,:));
end


% calculate F0 using a 25-s sliding window, F0 is the 50th percentile
Cells_F0_median = zeros(size(Cells_F_smoothed));

a1 = size(Cells_F_smoothed,2)-375;
a2 = size(Cells_F_smoothed,2);
a3 = size(Cells_F_smoothed,2)-376;

parfor i = 1:size(Cells_F_smoothed,1)
       % Frame 1~376
       for ii = 1:376
           Cells_F0_median(i,ii) = prctile(Cells_F_smoothed(i,1:751),50);
       end
       
       % Frame size(Cells_F,2)-375~size(Cells_F,2)
       for ii = a1:a2
           Cells_F0_median(i,ii) = prctile(Cells_F_smoothed(i,(size(Cells_F_smoothed,2)-751):size(Cells_F_smoothed,2)),50);
       end
       
       % Frames in the middle
       for ii = 377:a3
           Cells_F0_median(i,ii) = prctile(Cells_F_smoothed(i,(ii-375):(ii+375)),50);
       end
end

% calculate dFoF as (F_smoothed–F0)/F0
Cells_dFoF_median = (Cells_F_smoothed-Cells_F0_median)./Cells_F0_median;

end