function [Cellstats_residue,Search_Table_residue_out,search_string_laps]...
    = Get_cellstats_residue_out(BinnedData,cell,start_lap,end_lap,PF_loc,BTSP_peak_frame)

% search for events outside the template PF location

Search_Table_residue = [];
search_string_laps = [];

LapStructure = BinnedData.LapStructure;
LapStructure_residue = LapStructure(start_lap:(end_lap+1));

Cellstats_residue = nan((numel([LapStructure_residue.LapNumber])-1),25);
Cellstats_residue(:,1) = str2num(BinnedData.AnimalID(3:5));
Cellstats_residue(:,2) = BinnedData.LongitudinalDay;
Cellstats_residue(:,3) = cell;
for i = 1:(numel([LapStructure_residue.LapNumber])-1)
    Cellstats_residue(i,4) = i;
end

dFoF_residue = BinnedData.Cells_dFoF_binned_mean(start_lap:(end_lap+1),:,cell);
Events = BinnedData.Events(cell).Events;

if ~isempty(Events)
    Events_Running = Events(Events(:,3)>0,:);
    edges = 0:3.6:180;
    PF_loc_bin = discretize(PF_loc,edges);
    [Search_Table_residue] = Get_SearchTable_2(PF_loc_bin,LapStructure_residue);
    Flat_firing_array = reshape((dFoF_residue>0).',1,[]);
    Flat_dFoF_array = reshape(dFoF_residue.',1,[]);

    Search_Table_residue_out = [];
    Search_Table_residue_out(:,1) = Search_Table_residue(:,1);
    
    for i = 1:size(Search_Table_residue_out,1)
        if i == 1
           Search_Table_residue_out(i,2) = 1;
           Search_Table_residue_out(i,4) = LapStructure_residue(1).FrameNumber(1);
        elseif i ~= 1
           Search_Table_residue_out(i,2) = Search_Table_residue((i-1),7)+1;
           Search_Table_residue_out(i,4) = Search_Table_residue((i-1),9)+1;
        end
        Search_Table_residue_out(i,3) = Search_Table_residue(i,6)-1;
        Search_Table_residue_out(i,5) = Search_Table_residue(i,8)-1;
    end
    

    for i = 1:(numel([LapStructure_residue.LapNumber])-1)
       search_string = Flat_firing_array(Search_Table_residue_out(i,2):Search_Table_residue_out(i,3));
       %search_string_dFoF = Flat_dFoF_array(Search_Table_residue(i,6):Search_Table_residue(i,7));
       if ~isempty(strfind(search_string,[1 1 1])) % if there are 3 bins with continuous firing
          %disp('yes')
          % Find events where the frame of the peak amplitude is within 30.6 cm of the midpoint of the search bin
          
          event_idx = find(Events_Running(:,5)>(Search_Table_residue_out(i,4)-1) & Events_Running(:,5)<(Search_Table_residue_out(i,5)+1));
          if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside
             [x,idx] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
             if Events_Running(event_idx(idx),5) ~= BTSP_peak_frame
                 Cellstats_residue(i,5:11) = Events_Running(event_idx(idx),4:10);
                 % if numel(search_string_dFoF) < 17
                 %     a = nan(1,(17-numel(search_string_dFoF)));
                 %     if i == 1
                 %         search_string_dFoF = [a,search_string_dFoF];
                 %     elseif i ~= 1
                 %         search_string_dFoF = [search_string_dFoF,a];
                 %     end
                 % end
                 % search_string_laps = [search_string_laps;search_string_dFoF];
             end
          end
       end

    end


    c = size(Search_Table_residue_out,1)+1;
    if Search_Table_residue(end,7) < 50*(end_lap-start_lap+1)
        Search_Table_residue_out(c,1) = c;
        Search_Table_residue_out(c,2) = Search_Table_residue(end,7)+1;
        Search_Table_residue_out(c,3) = 50*(end_lap-start_lap+1);
        Search_Table_residue_out(c,4) = Search_Table_residue(end,9)+1;
        Search_Table_residue_out(c,5) = LapStructure_residue(c-1).FrameNumber(end);

        for i = c
            search_string = Flat_firing_array(Search_Table_residue_out(i,2):Search_Table_residue_out(i,3));

            if ~isempty(strfind(search_string,[1 1 1])) % if there are 3 bins with continuous firing
                %disp('yes')
                % Find events where the frame of the peak amplitude is within 30.6 cm of the midpoint of the search bin
                event_idx = find(Events_Running(:,5)>(Search_Table_residue_out(i,4)-1) & Events_Running(:,5)<(Search_Table_residue_out(i,5)+1));
                if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside
                    [x,idx] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                    if Events_Running(event_idx(idx),5) ~= BTSP_peak_frame
                        if numel(find(isnan(Cellstats_residue(end,5:11)))) > 0
                           Cellstats_residue((i-1),5:11) = Events_Running(event_idx(idx),4:10);
                        end
                    end
                end
            end
        end
    end

end
end