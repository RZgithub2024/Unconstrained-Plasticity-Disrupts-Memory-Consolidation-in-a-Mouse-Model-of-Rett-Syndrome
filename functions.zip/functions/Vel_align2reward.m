function [Vel_pseudolaps,slf_pseudolaps] = Vel_align2reward(BinnedData)

% get the binned vel and slow down factor, aligned to reward location
% 24 bins before and 25 bins after reward

Vel_by_lap = BinnedData.Vel_by_lap;
Vel_by_lap_flat = reshape(Vel_by_lap', 1, []);
LapStructure = BinnedData.LapStructure;

Vel_pseudolaps = [];
slf_pseudolaps = [];
for k = 1:numel([LapStructure.LapNumber])
    if ~isempty([LapStructure(k).RewardDeliveryLocation])
        reward_loc_cm = LapStructure(k).RewardDeliveryLocation(1)*100;
        if reward_loc_cm >= 0 && reward_loc_cm <= 180
            edges = 0:3.6:180;
            reward_loc_bin = discretize(reward_loc_cm,edges);
            reward_loc_bin_flat = reward_loc_bin + 50*(k-1);
            pseudo_lap = [];
            pseudo_lap = (reward_loc_bin_flat-24):(reward_loc_bin_flat+25);
            pseudo_lap(pseudo_lap<1 | pseudo_lap>numel(Vel_by_lap_flat)) = NaN;
            Vel_pseudo_lap = [];
            slowdown_factor = [];
            for p = 1:length(pseudo_lap)
                if ~isnan(pseudo_lap(p))
                    Vel_pseudo_lap(p) = Vel_by_lap_flat(pseudo_lap(p));
                else
                    Vel_pseudo_lap(p) = NaN;
                end
            end
            vel_bin_deno = nanmean(Vel_pseudo_lap(1:6),2);
            vel_bin_22_24 = Vel_pseudo_lap(22:24);
            vel_bin_22_24_norm = vel_bin_22_24./vel_bin_deno;
            slowdown_factor = nanmean(vel_bin_22_24_norm,2)*100;
        else
            Vel_pseudo_lap = nan(1,50);
            slowdown_factor = NaN;
        end
    else
        Vel_pseudo_lap = nan(1,50);
        slowdown_factor = NaN;
    end
    Vel_pseudolaps = [Vel_pseudolaps;Vel_pseudo_lap];
    slf_pseudolaps = [slf_pseudolaps;slowdown_factor];
end

end