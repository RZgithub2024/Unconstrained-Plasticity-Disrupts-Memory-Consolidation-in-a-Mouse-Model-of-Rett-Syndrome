function [Cells_dFoF,Fmed] = Get_dFoF_median(Cells_F)

Cells_dFoF = zeros(size(Cells_F),'like', Cells_F);
Fmed = zeros(size(Cells_F),'like', Cells_F);
parfor i = 1:size(Cells_dFoF,1)
       [Cells_dFoF(i,:),Fmed(i,:)] = Get_dFoF_cell(Cells_F(i,:),i);
end
end


function [dFoF,Fmed] = Get_dFoF_cell(F,i)
% smooth F

sF = (smooth(F)); % smooth window 5

% use 750 points or 25 secs at 30 Hz to establish sliding median for F0

% calculation

%Fmed =  medfilt1(sF,375,'omitnan','truncate'); Old - 12.5 secs

Fmed =  medfilt1(sF,900,'omitnan','truncate'); % New 30s; 15 on each side

% if medfilt puts out a zero value

if (nansum(Fmed==0)>1)

   Fmed(Fmed==0)= median(sF); % replace zero values by global median
   disp(sprintf('zero values detected in median filter for ROI %d',i));

end

dFoF = (sF-Fmed)./Fmed;

end