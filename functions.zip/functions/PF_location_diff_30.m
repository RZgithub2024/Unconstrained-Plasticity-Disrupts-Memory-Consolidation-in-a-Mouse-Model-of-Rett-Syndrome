function [DiffMoreThan30,DiffLessThan30] = PF_location_diff_30(PF_location_1,PF_location_2)

if PF_location_1 < 30
   PF_plus_30 = PF_location_1+30;
   PF_minus_30 = PF_location_1-30+180;
   if PF_location_2 <= PF_plus_30 || PF_location_2 >= PF_minus_30
      DiffLessThan30 = true;
      DiffMoreThan30 = false;
   else
      DiffLessThan30 = false;
      DiffMoreThan30 = true;
   end
end

if PF_location_1 > 150
   PF_plus_30 = PF_location_1+30-180;
   PF_minus_30 = PF_location_1-30;
   if PF_location_2 <= PF_plus_30 || PF_location_2 >= PF_minus_30
      DiffLessThan30 = true;
      DiffMoreThan30 = false;        
   else
      DiffLessThan30 = false;
      DiffMoreThan30 = true;
   end
end

if PF_location_1 >= 30 && PF_location_1 <= 150
   PF_plus_30 = PF_location_1+30;
   PF_minus_30 = PF_location_1-30;
   if PF_location_2 <= PF_plus_30 && PF_location_2 >= PF_minus_30
      DiffLessThan30 = true;
      DiffMoreThan30 = false;
   else
      DiffLessThan30 = false;
      DiffMoreThan30 = true;
   end
end