function [SearchTable_BTSP] = Get_SearchTable_BTSP_event(event_peak_bin,event_lap,BinnedData)

%{
% this function is used for BTSPStats_6,7,8

Window of search is 45 cm or 12.5 bins.
Search 5 laps after BTSP induction lap.

Search Table Column Params:

    1. Flattened array, start search bin
    2. Flattened array, midpoint of search bins
    3. Flattened array, end search bin
    4. Non-flattened array, start search bin
    5. Non-flattened array, end search bin
    6. Non-flattened array, start search location in cm
    7. Non-flattened array, end search location in cm
    8. Non-flattened array, start search lap
    9. Non-flattened array, end search lap
    10. Lap Start Search Loc Frame
    11. Lap End Search Loc Frame


%}
SearchTable_BTSP = [];

event_loc_bin_flat = [];
event_loc_bin_flat = (event_lap - 1) * 50 + event_peak_bin;

for n = 1:5
    SearchTable_BTSP(n,2) = event_loc_bin_flat + 50 * n;
    SearchTable_BTSP(n,1) = SearchTable_BTSP(n,2) - 12;
    if SearchTable_BTSP(n,1) < 1
        SearchTable_BTSP(n,1) = 1;
    end
    SearchTable_BTSP(n,3) = SearchTable_BTSP(n,2) + 12;
    if SearchTable_BTSP(n,3) > 50 * max([BinnedData.LapStructure.LapNumber])
        SearchTable_BTSP(n,3) = 50 * max([BinnedData.LapStructure.LapNumber]);
    end

    SearchTable_BTSP(n,4) = lap_mod(SearchTable_BTSP(n,1),50);
    SearchTable_BTSP(n,5) = lap_mod(SearchTable_BTSP(n,3),50);
    SearchTable_BTSP(n,6) = SearchTable_BTSP(n,4) * 3.6;
    SearchTable_BTSP(n,7) = SearchTable_BTSP(n,5) * 3.6;

    SearchTable_BTSP(n,8) = ceil(SearchTable_BTSP(n,1)/50);
    SearchTable_BTSP(n,9) = ceil(SearchTable_BTSP(n,3)/50);
    
    [~,idx_start] = min(abs((BinnedData.LapStructure(SearchTable_BTSP(n,8)).Distance_frame * 100)-SearchTable_BTSP(n,6)));
    SearchTable_BTSP(n,10) = BinnedData.LapStructure(SearchTable_BTSP(n,8)).FrameNumber(idx_start);

    [~,idx_end] = min(abs((BinnedData.LapStructure(SearchTable_BTSP(n,9)).Distance_frame * 100)-SearchTable_BTSP(n,7)));
    SearchTable_BTSP(n,11) = BinnedData.LapStructure(SearchTable_BTSP(n,9)).FrameNumber(idx_end);
end

end