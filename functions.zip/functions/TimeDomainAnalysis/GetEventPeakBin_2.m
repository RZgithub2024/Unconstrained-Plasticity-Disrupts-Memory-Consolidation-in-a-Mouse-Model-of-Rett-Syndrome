function [event_peak_bin,event_lap] = GetEventPeakBin_2(BinnedData,event_peak_frame,event_peak_loc)
% input: event_peak_frame
% output: event peak bin, event_lap

event_lap = [];
event_frame_index = [];
for ji = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(ji).FrameNumber == event_peak_frame)
        event_lap = ji;
        event_frame_index = find([BinnedData.LapStructure(ji).FrameNumber] == event_peak_frame);
        break;
    end
end

edges = 0:3.6:180;
event_peak_bin = discretize(event_peak_loc, edges);

if event_peak_loc >= -3.6 && event_peak_loc < 0
    event_peak_bin = 1;
end

if event_peak_loc > 180 && event_peak_loc <= 183.6
    event_peak_bin = 50;
end

if event_peak_bin == 50 && event_frame_index <= 10
    event_peak_bin = 1;
end

end