function [PFStructure] = PFAnalysis(PFStructure,rel,Display_PFs)

%{

PForNot a suite to run all PF_related algorithms and determine if a ROI is
a PF or not.

 
ARGS:

- Binned : (struct) Mother Structure that saves all processed Ca data. 

- Laps: (struct) 1 x nLaps houses all info regarding Laps

- Display_PFs: (logical) open implay to show PFs and non PFs or not

RETURNS:

- [PForNoT] : (double) nROIs X 12 :

    1. Animal
    2. Recording Date
    3. Cell
    4. Shuffle Positive or not
    5. 3/5 Firing detected or not
    6. 30% Reliability after Onset or not
    7. PF based on 4.5.&6. or not
    8. PF loc if PF
    9. Spatial Info if PF
    10. Onset if PF
    11. Reliability if PF
    12. Average Pk Amplitude (dF/F)
    13. Average Pk Width (cm)
    14. Average Pk Dur (ms) 


ALGORITHMS:

Find_Events - Find events in time domain
CellStats - Get Firing stats for each lap for each cell within 45 cm of pk
            average
Shuffle - Spatial Info and Shuffle positive or not.
Onset_Reliability - 3/5 firing or not. If yes, Onset and Reliability.

Note PF location is the peak of the average for all firing laps.

%}



%% PF analysis
[Onset,Reliability] = Onset_Reliability(PFStructure);
PFStructure.Onset = Onset;
PFStructure.Reliability = Reliability;

PForNot = nan(size(PFStructure.Cells_dFoF_denoised,1),18);
PForNot(:,1) = str2num(PFStructure.MouseID(3:5));% Animal
PForNot(:,2) = PFStructure.ImagingDay;%Recording Day
PForNot(:,3) = 1:size(PFStructure.Cells_dFoF_denoised,1);% Cell
PForNot(:,4) = PFStructure.ShufflePositive_ornot; % Shuffle positive
PForNot(:,5) = ~isnan(Onset); % 3/5 Firing
PForNot(:,6) = Reliability>rel; % Reliability > rel
PForNot(:,7) = nansum(PForNot(:,(4:6)),2)==3; % PF if all three conditions are met


PF_IDs = find(PForNot(:,7));

% at least 5 firing laps to become a PC
Firing_laps = [];
for i = 1:size(PF_IDs,1)
    PF = PF_IDs(i);
    % Determine Firing laps
    Firing_laps = find(~isnan(squeeze(PFStructure.Cellstats(PF,:,7))));
    Firing_laps(Firing_laps<Onset(PF)) = [];
    PForNot(PF,15) = numel(Firing_laps);
    if numel(Firing_laps) < 5
       PForNot(PF,7) = false;
    end
end

PF_IDs = find(PForNot(:,7));
notPF_IDS = find(~PForNot(:,7));
PC_peak_firing_laps = {};
PC_width_firing_laps = {};
Firing_laps = [];
for i = 1:size(PF_IDs,1)
    PF = PF_IDs(i);
    % Cellstats
    dFoF = squeeze(PFStructure.Cells_dFoF_binned_mean(:,:,PF));
    % Determine Firing laps
    Firing_laps = find(~isnan(squeeze(PFStructure.Cellstats(PF,:,7))));
    Firing_laps(Firing_laps<Onset(PF)) = [];
    PF_loc = Find_PFloc(dFoF,Firing_laps);
    PForNot(PF,8) = (PF_loc * 3.6) - 1.8; % PF loc
    % Avg Peak Amplitude, Width and Duration
    PForNot(PF,12) = nanmean(squeeze(PFStructure.Cellstats(PF,Firing_laps,5))); % Average Pk amplitude
    PForNot(PF,13) = nanmean(squeeze(PFStructure.Cellstats(PF,Firing_laps,10)));% Average Pk width (cm)
    PForNot(PF,14) = nanmean(squeeze(PFStructure.Cellstats(PF,Firing_laps,11)));% Average Pk width (ms)

    PC_peak_firing_laps{i} = squeeze(PFStructure.Cellstats(PF,Firing_laps,5));
    PC_width_firing_laps{i} = squeeze(PFStructure.Cellstats(PF,Firing_laps,10));
end

PForNot(PF_IDs,9) = PFStructure.SpatialInformation_cells(PF_IDs); % Spatial Info
PForNot(PF_IDs,10) = Onset(PF_IDs); % Onset
PForNot(PF_IDs,11) = Reliability(PF_IDs)*100; % Reliability

PFStructure.PForNot = PForNot;

PFStructure.PF_averaged_peak = PForNot(:,12);
PFStructure.PF_averaged_width = PForNot(:,13);
PFStructure.PC_peak_firing_laps = PC_peak_firing_laps;
PFStructure.PC_width_firing_laps = PC_width_firing_laps;

PFStructure.PFStats = Get_PFdata(PFStructure);
%% Sample PFs and Non-PFs

if (Display_PFs)

implay(PFStructure.Cells_dFoF_binned_mean(:,:,PF_IDs));
implay(PFStructure.Cells_dFoF_binned_mean(:,:,notPF_IDS));

end

end


function [PF_loc] = Find_PFloc(dFoF,Firing_laps)

%{ 

Finds prosp PF loc based on session average and centers the dFoF array on
it; Then gets the peak of the average only for the firing laps and
readjusts if there is an issue with edges.

%}


[~,pros_PF_binloc] = max(nanmean(dFoF,1));
% Get centered dFoF array for PFloc calculation; flatten, shift, reshape
Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
shift = 25 - pros_PF_binloc; % positive if <25; negative if >25;
Centered_flat_array = circshift(Flat_array,shift);
Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM
[~,centered_PFloc] = max(nanmean(Centered_dFoF(Firing_laps,:),1));
PF_loc = centered_PFloc - shift;
if PF_loc>50
   PF_loc = PF_loc -50;
elseif PF_loc<1
   PF_loc = 50 + PF_loc;
end
   
end