function [out_field_peaks,search_range_laps] = Get_out_field_peak_2(PF_bin,laps,Events,dFoF,LapStructure,search_bins)

% find the out-of-field peak (dFoF) for given laps
% used for: 1) out-of-field residue analysis
% searching window: determined by search_bins

pre_bins = 24;
post_bins = 25;

out_field_peaks = [];
Search_Table_1 = [];
Search_Table_1 = Get_SearchTable_4(PF_bin,LapStructure,search_bins);
Search_Table_2 = [];
Search_Table_2 = Get_SearchTable_4(PF_bin,LapStructure,pre_bins);
Search_Table_3 = [];
Search_Table_3 = Get_SearchTable_4(PF_bin,LapStructure,post_bins);

Flat_firing_array = reshape((dFoF>0).',1,[]);

ConsBins = ones(1,3);
frame_numbers = [LapStructure.FrameNumber];
Events_Running = [];
events_running_idx = [];
events_running_idx = ismember(Events(:,1), frame_numbers) & ...
    ismember(Events(:,2), frame_numbers) & ...
    ismember(Events(:,5), frame_numbers) & ...
    (Events(:,3) > 0) & ...
    (Events(:,6) >= 0) & ...
    (Events(:,6) <= 180);
Events_Running = Events(events_running_idx,:);
search_range_laps = [];

for k = 1:length(laps)
    if ~isnan(laps(k))
        i = laps(k);
        Search_Table_1(i,6);
        search_range_1 = NaN(1,9);
        search_range_2 = NaN(1,9);

        search_range_1(6) = Search_Table_2(i,6);
        search_range_1(7) = Search_Table_1(i,6)-1;
        search_range_1(8) = Search_Table_2(i,8);
        search_range_1(9) = Search_Table_1(i,8)-1;

        search_range_2(6) = Search_Table_1(i,7)+1;
        search_range_2(7) = Search_Table_3(i,7);
        search_range_2(8) = Search_Table_1(i,9)+1;
        search_range_2(9) = Search_Table_3(i,9);

        if (search_range_1(7) - search_range_1(6) + 1) < 16 
            search_range_1(6) = NaN;
            search_range_1(7) = NaN;
            search_range_1(8) = NaN;
            search_range_1(9) = NaN;
        end

        if (search_range_2(7) - search_range_2(6) + 1) < 16 
            search_range_2(6) = NaN;
            search_range_2(7) = NaN;
            search_range_2(8) = NaN;
            search_range_2(9) = NaN;
        end
        %search_range_laps = [search_range_laps;search_range_1];
        
        y1 = [];
        if all(~isnan(search_range_1(6:9)))
            search_string = Flat_firing_array(search_range_1(6):search_range_1(7));
            if ~isempty(strfind(search_string,ConsBins))
            %if numel(find(search_string == 1)) > 0
                % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                event_idx = [];
                event_idx = find(Events_Running(:,5)>(search_range_1(8)-1) & Events_Running(:,5)<(search_range_1(9)+1));
                if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
                    [y1,~] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                else
                    y1 = 0;
                end
            else
                y1 = 0;
            end
        else
            y1 = NaN;
        end
        
        y2 = [];
        if all(~isnan(search_range_2(6:9)))
            search_string = Flat_firing_array(search_range_2(6):search_range_2(7));
            if ~isempty(strfind(search_string,ConsBins))
            %if numel(find(search_string == 1)) > 0
                % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                event_idx = [];
                event_idx = find(Events_Running(:,5)>(search_range_2(8)-1) & Events_Running(:,5)<(search_range_2(9)+1));
                if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
                    [y2,~] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                else
                    y2 = 0;
                end
            else
                y2 = 0;
            end
        else
            y2 = NaN;
        end
        
        y = [y1,y2];
        if any(~isnan(y))
            out_field_peaks(k) = nanmax(y);
        else
            out_field_peaks(k) = NaN;
        end
    else
        out_field_peaks(k) = NaN;
    end
end





end