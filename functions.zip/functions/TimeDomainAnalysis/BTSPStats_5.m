function [BTSPstats,PlateauThereshold] = BTSPStats_5(BinnedData)

%%
%     BTSPstats:
%     1. Animal ID (e.g. 01)
%     2. Longitudinal Day
%     3. Cell Number
%     4. Lap
%     5. dFoF_peak_firing_laps_top_20 of a given cell
%     6. Peak Amplitude (dFoF)
%     7. Peak Amplitude >= top 20 percetile && >= 1
%     8-14. Cellstats column 5-11 for BTSP events, or Events column 4-10
%     15. firing lap or not
%     16. whether there are at least 3 out of 5 laps firing after induction
%     17. COM backward shift or not
%     18. BTSP events, 1 = true, 0 = false
%     19. Putative plateaus besides BTSP events
%     20-26. Cellstats column 5-11 for putative plateaus besides BTSP events
%     27. COM shift distance (+, 0 -)
%     28. COM of putative BTSP event lap
%     29. COM of mean activity of firing laps from five post-putative BTSP laps
%     30. First plateau followed by 3/5 lap firing (before the first typical BTSP) considered as a BTSP, 1 = true, 0 = false
%     31. firing lap or not when checking column 30
%     32. COM shift distance (+, 0 -) for the BTSP event in column 30
%     33. COM of the BTSP event in column 30
%     34. COM of mean activity of firing laps from five post BTSP laps for the BTSP event in column 30
%     35. whether a given cell is a PC, 1 = PC, 0 = non-PC

% this function looks for BTSP events in both PCs and non-PCs using Cellstats data

for cell = 1:size(BinnedData.Cells_dFoF_denoised,1)
    [BTSPstats(cell,:,:),PlateauThereshold(cell)] = Get_btspstats(BinnedData,cell);
end

end


function [BTSPStats,PlateauThereshold] = Get_btspstats(BinnedData,cell)

% disp(cell);
PlateauThereshold = NaN;
BTSPStats = nan(numel([BinnedData.LapStructure.LapNumber]),35);

if ismember(cell,BinnedData.PFStats.PFIDs)
    BTSPStats(:,35) = 1;
else
    BTSPStats(:,35) = 0;
end

BTSPStats(:,1) = str2num(BinnedData.AnimalID(3:5));
BTSPStats(:,2) = BinnedData.LongitudinalDay;
BTSPStats(:,3) = cell;
for i = 1:numel([BinnedData.LapStructure.LapNumber])
    BTSPStats(i,4) = i; % Lap
end

dFoF = BinnedData.Cells_dFoF_binned_mean(:,:,cell); % binned denoised dFoF;
Flat_firing_array = reshape((dFoF>0).',1,[]);
Events = BinnedData.Events(cell).Events;
puPlateau_peak_dFoF_1 = [];
puPlateau_peak_dFoF_1_2 = [];

if (~isempty(Events))
   Events_Running = Events(Events(:,3)>0,:); % Filter for events that have a some part when the animal is running.

   Firing_laps = find(~isnan(squeeze(BinnedData.Cellstats(cell,:,7))));
   dFoF_peak_firing_laps_top_20 = prctile(squeeze(BinnedData.Cellstats(cell,Firing_laps,5)),80);

   for n = 1:numel(Firing_laps)
       m = Firing_laps(n);
       if m <= (max([BinnedData.LapStructure.LapNumber])-5)
          BTSPStats(m,5) = dFoF_peak_firing_laps_top_20;
          BTSPStats(m,6) = BinnedData.Cellstats(cell,m,5);
          if BinnedData.Cellstats(cell,m,5) >= dFoF_peak_firing_laps_top_20 &&...
               BinnedData.Cellstats(cell,m,5) >= 1 &&...
               BinnedData.Cellstats(cell,m,7) < 182

             BTSPStats(m,7) = 1;
             BTSPStats(m,8:14) = BinnedData.Cellstats(cell,m,5:11);
             
             [SearchTable_BTSP] = Get_SearchTable_BTSP(cell,m,BinnedData);
             PostFiveLaps = (m+1):(m+5);

             count = 0;
             PostFiveLaps_firing = [];
             for i = 1:5
                 ii = PostFiveLaps(i);
                 if ~isempty(SearchTable_BTSP)
                    search_string_BTSP = Flat_firing_array(SearchTable_BTSP(i,1):SearchTable_BTSP(i,3));
                    if ~isempty(strfind(search_string_BTSP,[1 1 1]))
                       % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                       event_idx = find(Events_Running(:,5)>(SearchTable_BTSP(i,10)-1) & Events_Running(:,5)<(SearchTable_BTSP(i,11)+1));
                       if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside
                          BTSPStats(ii,15) = 1;
                          count = count + 1;
                          PostFiveLaps_firing = [PostFiveLaps_firing,ii];
                          [~,idx] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                          BTSPStats(ii,8:14) = Events_Running(event_idx(idx),4:10);
                       end
                     end
                  end
              end
             
             if count >= 3
                BTSPStats(m,16) = 1;
                puPlateau_location_frame = BinnedData.Cellstats(cell,m,6);
                puPlateau_location_cm = BinnedData.Cellstats(cell,m,7);
                puPlateau_location_bin = floor(puPlateau_location_cm/3.6) + 1;

                jj = 0;
                for jj = 1:numel([BinnedData.LapStructure.LapNumber])
                    if any(BinnedData.LapStructure(jj).FrameNumber == puPlateau_location_frame)
                       puPlateau_location_lap = jj;
                       puPlateau_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == puPlateau_location_frame);
                       break;
                    end
                end

                if puPlateau_location_bin == 50 && puPlateau_frame_index <=10
                   puPlateau_location_bin = 1;
                end

                if puPlateau_location_lap == m
                   shift_1 = 25 - puPlateau_location_bin; % positive if <25; negative if >25;
                
                elseif puPlateau_location_lap < m
                   shift_1 = 50 - puPlateau_location_bin + 25;

                elseif puPlateau_location_lap > m
                   shift_1 = -25 - puPlateau_location_bin;
                end

                Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
                Centered_flat_array = circshift(Flat_array,shift_1);
                Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM

                warning('off');
                COM_BTSP_lap = Find_COM_2(Centered_dFoF(m,:));

                dFoF_PostFiveLaps_firing = Centered_dFoF(PostFiveLaps_firing,:);
                % dFoF_PostFiveLaps_firing_flatten = reshape(dFoF_PostFiveLaps_firing',1,[]);
                % [~,PostFiveLaps_firing_binloc] = max(mean(dFoF_PostFiveLaps_firing,1,"omitnan"),[],"omitnan");
                % shift_2 = 25 - PostFiveLaps_firing_binloc; % positive if <25; negative if >25;
                % Centered_flat_array = circshift(dFoF_PostFiveLaps_firing_flatten,shift_2);
                % Centered_dFoF_PostFiveLaps_firing = reshape(Centered_flat_array,size(dFoF_PostFiveLaps_firing,2),[])'; % use this for COM
                Centered_dFoF_mean_PostFiveLaps_firing = mean(dFoF_PostFiveLaps_firing,1,"omitnan");

                COM_PostFiveLaps_firing = Find_COM_2(Centered_dFoF_mean_PostFiveLaps_firing);
                warning('on');
                
                % debug
                if isnan(COM_BTSP_lap)
                   disp('plateau lap')
                   disp(num2str(puPlateau_location_lap));
                   disp(num2str(puPlateau_location_cm));
                   disp(num2str(puPlateau_location_bin));
                   disp(num2str(shift_1));
                   disp(num2str(Centered_dFoF(m,:)));
                   disp([num2str(cell), ',', num2str(m)]);
                end
                if isnan(COM_PostFiveLaps_firing)
                   disp('COM_PostFiveLaps_firing');
                   disp(num2str(dFoF_PostFiveLaps_firing));
                   disp([num2str(cell), ',', num2str(m)]);
                   disp(num2str(PostFiveLaps_firing));
                end

                BTSP_shift_cm = BeltDistShift(COM_BTSP_lap,COM_PostFiveLaps_firing);
                BTSPStats(m,27) = BTSP_shift_cm;
                BTSPStats(m,28) = COM_BTSP_lap;
                BTSPStats(m,29) = COM_PostFiveLaps_firing;
                
                if BTSP_shift_cm < 0
                   BTSPStats(m,17) = 1;
                else
                   BTSPStats(m,17) = 0;
                end
             else
                BTSPStats(m,16) = 0;
             end

             if nansum([BTSPStats(m,7),BTSPStats(m,16),BTSPStats(m,17)]) == 3
                BTSPStats(m,18) = 1;
                puPlateau_peak_dFoF_1 = [puPlateau_peak_dFoF_1;BTSPStats(m,6)];
                puPlateau_peak_dFoF_1_2 = [puPlateau_peak_dFoF_1_2;BTSPStats(m,6)];
             end
          else
             BTSPStats(m,7) = 0;
          end
       end
   end
   
   if ~isempty(puPlateau_peak_dFoF_1)
      puPlateau_thereshold = min(puPlateau_peak_dFoF_1);
      PlateauThereshold = puPlateau_thereshold;
      for nn = 1:numel(Firing_laps)
          mm = Firing_laps(nn);
          if BTSPStats(mm,18) ~= 1
             if BinnedData.Cellstats(cell,mm,5) >= puPlateau_thereshold
                BTSPStats(mm,19) = 1;
                BTSPStats(mm,20:26) = BinnedData.Cellstats(cell,mm,5:11);
                puPlateau_peak_dFoF_1_2 = [puPlateau_peak_dFoF_1_2;BinnedData.Cellstats(cell,mm,5)];
             end
          end     
      end
   end

   % find the first plateau followed by 3/5 lap firing before the first typical BTSP and identify it as BTSP
   BTSP_typical = find(BTSPStats(:,18)==1);
   if ~isempty(BTSP_typical)
      BTSP_typical_1st = BTSP_typical(1);
      for kk = 1:BTSP_typical_1st
          if BTSPStats(kk,19) == 1
             [SearchTable_BTSP_first] = Get_SearchTable_BTSP(cell,kk,BinnedData);
             PostFiveLaps = (kk+1):(kk+5);
             count = 0;
             PostFiveLaps_firing = [];
             for i = 1:5
                 ii = PostFiveLaps(i);
                 if ~isempty(SearchTable_BTSP_first)
                    search_string_BTSP = Flat_firing_array(SearchTable_BTSP_first(i,1):SearchTable_BTSP_first(i,3));
                    if ~isempty(strfind(search_string_BTSP,[1 1 1]))
                       % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                       event_idx = find(Events_Running(:,5)>(SearchTable_BTSP_first(i,10)-1) & Events_Running(:,5)<(SearchTable_BTSP_first(i,11)+1));
                       if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside       
                          count = count + 1;
                          BTSPStats(ii,31) = 1;
                          PostFiveLaps_firing = [PostFiveLaps_firing,ii];
                       end
                    end
                 end
              end
              
              if count >= 3
                 BTSPStats(kk,30) = 1;
                 puPlateau_location_frame = BinnedData.Cellstats(cell,kk,6);
                 puPlateau_location_cm = BinnedData.Cellstats(cell,kk,7);
                 puPlateau_location_bin = floor(puPlateau_location_cm/3.6) + 1;

                 jj = 0;
                 for jj = 1:numel([BinnedData.LapStructure.LapNumber])
                     if any(BinnedData.LapStructure(jj).FrameNumber == puPlateau_location_frame)
                        puPlateau_location_lap = jj;
                        puPlateau_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == puPlateau_location_frame);
                        break;
                     end
                 end

                 if puPlateau_location_bin == 50 && puPlateau_frame_index <=5
                    puPlateau_location_bin = 1;
                 end

                 if puPlateau_location_lap == kk
                    shift_2 = 25 - puPlateau_location_bin; % positive if <25; negative if >25;
                
                 elseif puPlateau_location_lap < kk
                    shift_2 = 50 - puPlateau_location_bin + 25;

                 elseif puPlateau_location_lap > kk
                    shift_2 = -25 - puPlateau_location_bin;
                 end

                 Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
                 Centered_flat_array = circshift(Flat_array,shift_2);
                 Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM

                 warning('off');
                 COM_BTSP_lap_first = Find_COM_2(Centered_dFoF(kk,:));

                 dFoF_PostFiveLaps_firing = Centered_dFoF(PostFiveLaps_firing,:);
                 Centered_dFoF_mean_PostFiveLaps_firing = mean(dFoF_PostFiveLaps_firing,1,"omitnan");
                 COM_PostFiveLaps_firing_first = Find_COM_2(Centered_dFoF_mean_PostFiveLaps_firing);
                 warning('on');
                 
                 BTSP_first_shift_cm = BeltDistShift(COM_BTSP_lap_first,COM_PostFiveLaps_firing_first);
                 BTSPStats(kk,32) = BTSP_first_shift_cm;
                 BTSPStats(kk,33) = COM_BTSP_lap_first;
                 BTSPStats(kk,34) = COM_PostFiveLaps_firing_first;
                 break;
              end
          end
      end
   end


end
end