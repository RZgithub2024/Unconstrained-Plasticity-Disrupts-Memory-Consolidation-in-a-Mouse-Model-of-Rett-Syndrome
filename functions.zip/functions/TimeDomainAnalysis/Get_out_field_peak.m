function [out_field_peaks,search_range_laps] = Get_out_field_peak(PF_bin,laps,Events,dFoF,LapStructure,search_bins)

% find the out-of-field peak (dFoF) for given laps
% used for: 1) out-of-field residue analysis
% searching window: determined by search_bins


out_field_peaks = [];
Search_Table_1 = [];
Search_Table_1 = Get_SearchTable_4(PF_bin,LapStructure,search_bins);
Search_Table_2 = [];
Search_Table_2 = Get_SearchTable_4(PF_bin,LapStructure,24);
Search_Table_3 = [];
Search_Table_3 = Get_SearchTable_4(PF_bin,LapStructure,25);

Flat_firing_array = reshape((dFoF>0).',1,[]);

ConsBins = ones(1,3);
frame_numbers = [LapStructure.FrameNumber];
Events_Running = [];
events_running_idx = [];
events_running_idx = ismember(Events(:,1), frame_numbers) & ...
    ismember(Events(:,2), frame_numbers) & ...
    ismember(Events(:,5), frame_numbers) & ...
    (Events(:,3) > 0) & ...
    (Events(:,6) >= 0) & ...
    (Events(:,6) <= 180);
Events_Running = Events(events_running_idx,:);
search_range_laps = [];

for k = 1:length(laps)
    if ~isnan(laps(k))
        i = laps(k);
        Search_Table_1(i,6);
        search_range = NaN(1,9);
        if k == 1
            search_range(6) = Search_Table_2(i,6);
            search_range(7) = Search_Table_1(i,6)-1;
            search_range(8) = Search_Table_2(i,8);
            search_range(9) = Search_Table_1(i,8)-1;
        elseif k > 1 && k < length(laps)
            search_range(6) = Search_Table_1((i-1),7)+1;
            search_range(7) = Search_Table_1(i,6)-1;
            search_range(8) = Search_Table_1((i-1),9)+1;
            search_range(9) = Search_Table_1(i,8)-1;
        elseif k == length(laps)
            search_range(6) = Search_Table_1(i,7)+1;
            search_range(7) = Search_Table_3(i,7);
            search_range(8) = Search_Table_1(i,9)+1;
            search_range(9) = Search_Table_3(i,9);
        end

        if (search_range(7) - search_range(6) + 1) < 16 
            search_range(6) = NaN;
            search_range(7) = NaN;
            search_range(8) = NaN;
            search_range(9) = NaN;
        end
        search_range_laps = [search_range_laps;search_range];
        if all(~isnan(search_range(6:9)))
            search_string = Flat_firing_array(search_range(6):search_range(7));
            if ~isempty(strfind(search_string,ConsBins))
            %if numel(find(search_string == 1)) > 0
                % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                event_idx = [];
                event_idx = find(Events_Running(:,5)>(search_range(8)-1) & Events_Running(:,5)<(search_range(9)+1));
                if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
                    [out_field_peaks(k),~] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                else
                    out_field_peaks(k) = 0;
                end
            else
                out_field_peaks(k) = 0;
            end
        else
            out_field_peaks(k) = NaN;
        end
    else
        out_field_peaks(k) = NaN;
    end
end





end