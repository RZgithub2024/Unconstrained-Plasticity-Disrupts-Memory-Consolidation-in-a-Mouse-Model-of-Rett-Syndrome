function event_lap = GetEventLap(BinnedData,event_peak_frame)
% input: event_peak_frame
% output: event peak bin, event_lap

event_lap = [];
event_frame_index = [];
for ji = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(ji).FrameNumber == event_peak_frame)
        event_lap = ji;
        event_frame_index = find([BinnedData.LapStructure(ji).FrameNumber] == event_peak_frame);
        break;
    end
end

end