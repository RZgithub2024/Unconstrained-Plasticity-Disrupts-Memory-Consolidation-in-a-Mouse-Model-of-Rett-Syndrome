function [in_field_peaks,Search_Table] = Get_in_field_peak(PF_bin,laps,Events,dFoF,LapStructure,search_bins)

% find the in-field peak (dFoF) for given laps
% used for: 1) dFoF increase following BTSP analysis;
%           2) in-field residue analysis
% searching window: determined by search_bins

in_field_peaks = [];
Search_Table = [];
Search_Table = Get_SearchTable_4(PF_bin,LapStructure,search_bins);
Flat_firing_array = reshape((dFoF>0).',1,[]);

ConsBins = ones(1,1);
frame_numbers = [LapStructure.FrameNumber];
Events_Running = [];
events_running_idx = [];
events_running_idx = ismember(Events(:,1), frame_numbers) & ...
    ismember(Events(:,2), frame_numbers) & ...
    ismember(Events(:,5), frame_numbers) & ...
    (Events(:,3) > 0) & ...
    (Events(:,6) >= 0) & ...
    (Events(:,6) <= 180);
Events_Running = Events(events_running_idx,:);

for k = 1:length(laps)
    if ~isnan(laps(k))
        i = laps(k);
        Search_Table(i,6);
        search_string = Flat_firing_array(Search_Table(i,6):Search_Table(i,7));
        if ~isempty(strfind(search_string,ConsBins))
            % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
            event_idx = [];
            event_idx = find(Events_Running(:,5)>(Search_Table(i,8)-1) & Events_Running(:,5)<(Search_Table(i,9)+1));
            if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
                [in_field_peaks(k),~] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
            else
                in_field_peaks(k) = 0;
            end
        else
            in_field_peaks(k) = 0;
        end

    else
        in_field_peaks(k) = NaN;
    end

end

end