function [BTSPstats,PlateauThereshold_BTSP,Plateau_events,BTSP_events_comp] = BTSPStats_7_3(BinnedData)

%{
% this function looks for BTSP events in both PCs and non-PCs based
% on calcium events, not depending on Cellstats data

% BTSP criteria:
1) at least 20 3-bin events in the cell
2) >= 80 th percentile (top 20)
3) dF/F >= 1
4) at least 3/5 firing
5) COM backward shift
6) dF/F around plateaus increase > 50%

% % %     BTSPstats: lap based, each row is a lap (not informative for event-based BTSP detection)
% % %     1. Animal ID (e.g. 32)
% % %     2. Longitudinal Day
% % %     3. Cell ID
% % %     4. Lap
% % %     5. threshold for top 20 percentile events (dFoF) of a given cell
% % %     6. Peak Amplitude (dFoF)
% % %     7. Peak Amplitude >= top 20 percetile && >= 1 && at least 5 laps after qualifying events && 3-consecutive bin firing, 1 = true, 0 = false
% % %     8-14. Events column 4-10 for putative plateaus
% % %     15. Post-five firing lap or not (+- 45 cm of the putative plateau)
% % %     16. Whether there are at least 3 out of 5 laps firing after induction
% % %     17. COM of BTSP induction lap
% % %     18. COM of mean activity of firing laps from five post-induction laps
% % %     19. COM shift distance (+, 0, -)
% % %     20. COM backward shift or not
% % %     21. Whether nansum(btsp_lap_ev_info(7,16,20,25)) == 4, 1 = true, 0 = false
% % %     22. BTSP event or not, 1 = true, others = NaN
% % %     23. Whether a given cell is a PC, 1 = PC, 0 = non-PC

%     Plateau_events: record plateau events
%     1. Animal ID (e.g. 32)
%     2. Longitudinal Day
%     3. Cell ID
%     4. Lap where the event happened
%     5. threshold for top 20 percentile events (dFoF) of a given cell
%     6-15. Events column 1-10
%     16. Identified BTSP event = 1, other plateaus identified
%     with plateau thereshold = 3;
%     17. Whether a given cell is a PC, 1 = PC, 0 = non-PC


%     BTSP_events_comp: event based, each row is an event that meet criteria 1 & 2 & 3
%     this output shows the process of identifying BTSP events
%     1. Animal ID (e.g. 32)
%     2. Longitudinal Day
%     3. Cell ID
%     4. Lap where the event happened
%     5. threshold for top 20 percentile event amplitude (dFoF) of a given cell
%     6. Peak Amplitude (dFoF)
%     7. Peak Amplitude >= top 20 percetile && >= 1 && 0 <= event location
         <= 180 cm && at least 5 laps after qualifying events, 1 = true, 0 = false
%     8-14. Events column 4-10 for putative plateaus
%     15. NaN
%     16. Whether there are at least 3 out of 5 laps firing after induction
%     17. COM of BTSP induction lap
%     18. COM of mean activity of firing laps from five post-induction laps
%     19. COM shift distance (+, 0, -)
%     20. COM backward shift or not
%     21. mean amplitude dF/F of at most 3 laps before the induction lap
%     22. mean amplitude dF/F of at most 5 laps after the induction lap
%     23. (column 22 - column 21)/ column 21 (can be Inf or NaN if column 21 = 0 or NaN)
%     24. Whether column 23 > 50% (0, false; 1, true)
%     25. Whether nansum(btsp_lap_ev_info(7,16,20,24)) == 4, 1 = true, NaN = false
%     26. Whether a given event is a BTSP event, 1 = true, NaN = false

%}

BTSPstats = [];
PlateauThereshold_BTSP = [];
Plateau_events = {};
BTSP_events_comp = {};
delete(gcp('nocreate'));
parfor cell = 1:size(BinnedData.Cells_dFoF_denoised,1)
    [BTSPstats(cell,:,:),PlateauThereshold_BTSP(cell),Plateau_events{cell},BTSP_events_comp{cell}] =...
        Get_btspstats_7_3(BinnedData,cell);
end
delete(gcp('nocreate'));

end


function [BTSPStats,PlateauThereshold_BTSP,pl_events,BTSPEvents_comp] = Get_btspstats_7_3(BinnedData,cell)

N_events = 20;
IncF = 1.5;
% disp(cell);
BTSPStats = nan(numel([BinnedData.LapStructure.LapNumber]),35);
lap_number = numel([BinnedData.LapStructure.LapNumber]);
PlateauThereshold_BTSP = NaN;
pl_events = [];
BTSPEvents_comp = [];

if ismember(cell,BinnedData.PFStats.PFIDs)
    BTSPStats(:,23) = 1;
else
    BTSPStats(:,23) = 0;
end

BTSPStats(:,1) = str2num(BinnedData.AnimalID(3:5));
BTSPStats(:,2) = BinnedData.LongitudinalDay;
BTSPStats(:,3) = cell;
for i = 1:numel([BinnedData.LapStructure.LapNumber])
    BTSPStats(i,4) = i; % Lap
end

dFoF = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,cell));
Flat_firing_array = reshape((dFoF>0).',1,[]);
events = BinnedData.Events(cell).Events;
LapStructure = BinnedData.LapStructure;
frame_numbers = [LapStructure.FrameNumber];
puPlateau_peak_dFoF_1 = [];

% 1) at least 20 3-bin events in the cell
N_3binEvents = Get3binEvents(BinnedData,cell);

if N_3binEvents >= N_events
    % look for top 20 strong Ca events
    events_v_idx = ValidEvents(events,frame_numbers,0,180);
    Events_valid = [];
    Events_valid = events(events_v_idx,:);
    if ~isempty(Events_valid)
        Events_top20 = [];
        Events_amp = Events_valid(:,4);
        Events_top20_thres = prctile(Events_amp,80);
        BTSPStats(:,5) = Events_top20_thres;
        % 2) 3) peak dFoF >= 20 percentile threshold, and also >= 1
        Events_top20 = Events_valid(Events_valid(:,4) >= Events_top20_thres...
            & Events_valid(:,4) >= 1,:);

        if ~isempty(Events_top20)
            for n = 1:size(Events_top20,1)
                event_peak_frame = Events_top20(n,5);
                event_peak_loc = Events_top20(n,6);
                [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc);
                Cons_n = event_consecutive_test(event_lap,event_peak_bin,dFoF,3);

                % there should be at least 5 laps after qualifying events
                % the event should be a part of 3-consecutive bin firing
                if event_lap <= (lap_number-5)
                    if Cons_n == 1
                        btsp_lap_ev_info = nan(1,35);
                        btsp_lap_ev_info(1) = str2num(BinnedData.AnimalID(3:5));
                        btsp_lap_ev_info(2) = BinnedData.LongitudinalDay;
                        btsp_lap_ev_info(3) = cell;
                        btsp_lap_ev_info(4) = event_lap;
                        btsp_lap_ev_info(5) = Events_top20_thres;
                        btsp_lap_ev_info(6) = Events_top20(n,4);
                        btsp_lap_ev_info(7) = 1;
                        btsp_lap_ev_info(8:14) = Events_top20(n,4:10);

                        BTSPStats(event_lap,6) = Events_top20(n,4);
                        BTSPStats(event_lap,7) = 1;
                        BTSPStats(event_lap,8:14) = Events_top20(n,4:10);

                        [SearchTable_BTSP] = Get_SearchTable_BTSP_event(event_peak_bin,event_lap,BinnedData);
                        PostFiveLaps = (event_lap+1):(event_lap+5);

                        count = 0;
                        PostFiveLaps_firing = [];
                        for i = 1:numel(PostFiveLaps)
                            ii = PostFiveLaps(i);
                            if ~isempty(SearchTable_BTSP)
                                search_string_BTSP = Flat_firing_array(SearchTable_BTSP(i,1):SearchTable_BTSP(i,3));
                                if ~isempty(strfind(search_string_BTSP,[1 1 1]))
                                    % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                                    event_idx = find(Events_valid(:,5)>(SearchTable_BTSP(i,10)-1) & Events_valid(:,5)<(SearchTable_BTSP(i,11)+1));
                                    if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
                                        BTSPStats(ii,15) = 1;
                                        count = count + 1;
                                        PostFiveLaps_firing = [PostFiveLaps_firing,i];
                                        [~,idx] = max(Events_valid(event_idx,4)); % find the strongest event if there are multiple events
                                        BTSPStats(ii,8:14) = Events_valid(event_idx(idx),4:10);
                                    end
                                end
                            end
                        end

                        % 4) at least 3/5 firing
                        if count >= 3
                            BTSPStats(event_lap,16) = 1;
                            btsp_lap_ev_info(16) = 1;

                            % examine the backward shift after BTSP induction
                            % 5) COM backward shift
                            dFoF_laps_block = [];
                            dFoF_laps_block = Get_nlaps_block(6,dFoF,event_lap,event_peak_bin);

                            warning('off');
                            [COM_induction_lap,~] = Find_COM_2(dFoF_laps_block(1,:));
                            valid_laps = PostFiveLaps_firing + 1;
                            dFoF_PostFiveLaps_firing = dFoF_laps_block(valid_laps,:);
                            dFoF_PostFiveLaps_firing_mean = nanmean(dFoF_PostFiveLaps_firing,1);
                            [COM_PostFiveLaps_firing,~] = Find_COM_2(dFoF_PostFiveLaps_firing_mean);
                            warning('on');

                            % % debug
                            % if isnan(COM_induction_lap)
                            %     disp('plateau lap')
                            %     % disp(num2str(puPlateau_location_lap));
                            %     % disp(num2str(puPlateau_location_cm));
                            %     % disp(num2str(puPlateau_location_bin));
                            %     % disp(num2str(shift_1));
                            %     % disp(num2str(Centered_dFoF(m,:)));
                            %     disp([num2str(cell), ',', num2str(event_lap)]);
                            %     disp(num2str(Events_top20(n,4)));
                            % end
                            % if isnan(COM_PostFiveLaps_firing)
                            %     disp('COM_PostFiveLaps_firing');
                            %     %disp(num2str(dFoF_PostFiveLaps_firing));
                            %     disp([num2str(cell), ',', num2str(event_lap)]);
                            %     %disp(num2str(PostFiveLaps_firing));
                            % end

                            BTSP_shift_cm = BeltDistShift(COM_induction_lap,COM_PostFiveLaps_firing);
                            BTSPStats(event_lap,17) = COM_induction_lap;
                            BTSPStats(event_lap,18) = COM_PostFiveLaps_firing;
                            BTSPStats(event_lap,19) = BTSP_shift_cm;

                            btsp_lap_ev_info(17) = COM_induction_lap;
                            btsp_lap_ev_info(18) = COM_PostFiveLaps_firing;
                            btsp_lap_ev_info(19) = BTSP_shift_cm;

                            if BTSP_shift_cm < 0
                                BTSPStats(event_lap,20) = 1;
                                btsp_lap_ev_info(20) = 1;
                            else
                                BTSPStats(event_lap,20) = 0;
                                btsp_lap_ev_info(20) = 0;
                            end

                            % 6) dF/F around plateaus increase > 100
                            laps_pre_BTSP = (event_lap-5):(event_lap-1);
                            laps_pre_BTSP(laps_pre_BTSP<1) = NaN;
                            laps_post_BTSP = (event_lap+1):(event_lap+5);
                            laps_post_BTSP(laps_post_BTSP>lap_number) = NaN;
                            dFoF_pre_BTSP = [];
                            dFoF_post_BTSP = [];
                            [dFoF_pre_BTSP,~] =...
                                Get_in_field_peak(event_peak_bin,laps_pre_BTSP,events,dFoF,LapStructure,12);
                            [dFoF_post_BTSP,~] =...
                                Get_in_field_peak(event_peak_bin,laps_post_BTSP,events,dFoF,LapStructure,12);
                            X1 = nanmean(dFoF_pre_BTSP);
                            X2 = nanmean(dFoF_post_BTSP);
                            btsp_lap_ev_info(21) = X1;
                            btsp_lap_ev_info(22) = X2;
                            dFoF_change = (X2-X1)/X1;
                            btsp_lap_ev_info(23) = dFoF_change;
                            % take care of possible NaN (event_lap = 1) and Inf
                            if ~isnan(X1)
                                if X2 > X1*IncF
                                    btsp_lap_ev_info(24) = 1;
                                else
                                    btsp_lap_ev_info(24) = 0;
                                end
                            else
                                btsp_lap_ev_info(24) = 1;
                            end

                        else
                            BTSPStats(event_lap,16) = 0;
                            btsp_lap_ev_info(16) = 0;
                        end


                        if nansum([btsp_lap_ev_info(7),btsp_lap_ev_info(16),...
                                btsp_lap_ev_info(20),btsp_lap_ev_info(24)]) == 4

                            BTSPStats(event_lap,21) = 1;
                            btsp_lap_ev_info(25) = 1;
                            btsp_lap_ev_info(26) = 1;
                            puPlateau_peak_dFoF_1 = [puPlateau_peak_dFoF_1;Events_top20(n,4)];

                            event_info = [];
                            event_info(1:5) = btsp_lap_ev_info(1:5);
                            event_info(6:15) = Events_top20(n,1:10);
                            event_info(16) = 1;
                            pl_events = [pl_events;event_info];
                        end

                        BTSPEvents_comp = [BTSPEvents_comp;btsp_lap_ev_info];
                    end
                end
            end

            % % find the first plateau followed by at least 3/5 lap firing and bakcward shift
            % % it is the (first) BTSP event
            % if ~isempty(BTSPEvents_comp)
            %     BTSPEvents_btsp = [];
            %     BTSPEvents_btsp = BTSPEvents_comp(BTSPEvents_comp(:,21) == 1,:);
            %     if ~isempty(BTSPEvents_btsp)
            %         BTSPEvents_btsp_sorted = [];
            %         BTSPEvents_btsp_sorted = sortrows(BTSPEvents_btsp, 9);
            %         first_btsp_lap = BTSPEvents_btsp_sorted(1,4);
            %         BTSPStats(first_btsp_lap,22) = 1;
            %         pl_events(pl_events(:,10) == BTSPEvents_btsp_sorted(1,9),16) = 1;
            %         BTSPEvents_comp(BTSPEvents_comp(:,9)==BTSPEvents_btsp_sorted(1,9),22) = 1;
            %     end
            % end
        end

        % if BTSP events are detected, find the plateau thereshold
        % use the plateau thereshold to identify the plateau events that don't
        % induce typical BTSP
        if ~isempty(puPlateau_peak_dFoF_1)
            PlateauThereshold_BTSP = min(puPlateau_peak_dFoF_1);
            for nn = 1:size(Events_valid,1)
                if ~ismember(Events_valid(nn,5),pl_events(:,10)) &&...
                        Events_valid(nn,4) >= PlateauThereshold_BTSP
                    event_info = [];
                    event_info(1:3) = pl_events(1,1:3);
                    event_info(4) = GetEventPeakLap(BinnedData,Events_valid(nn,5));
                    event_info(5) = pl_events(1,5);
                    event_info(6:15) = Events_valid(nn,1:10);
                    event_info(16) = 3;
                    pl_events = [pl_events;event_info];
                end
            end
        end
    end
end

if ~isempty(pl_events)
    if ismember(cell,BinnedData.PFStats.PFIDs)
        pl_events(:,17) = 1;
    else
        pl_events(:,17) = 0;
    end
end


%%%%%% local functions
    function ValidEvent_idx = ValidEvents(ev,frame_numbers,d1,d2)

        ValidEvent_idx = (ev(:,3) > 0) & ...
            ismember(ev(:,1), frame_numbers) & ...
            ismember(ev(:,2), frame_numbers) & ...
            ismember(ev(:,5), frame_numbers) & ...
            (ev(:,6) >= d1) & ...
            (ev(:,6) <= d2);

    end


    function [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc)
        % input: event_peak_frame
        % output: event peak bin, event_lap

        jj = 0;
        event_lap = [];
        event_frame_index = [];
        for jj = 1:numel([BinnedData.LapStructure.LapNumber])
            if any(BinnedData.LapStructure(jj).FrameNumber == event_peak_frame)
                event_lap = jj;
                event_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == event_peak_frame);
                break;
            end
        end

        edges = 0:3.6:180;
        event_peak_bin = discretize(event_peak_loc, edges);

        if event_peak_bin == 50 && event_frame_index <= 10
            event_peak_bin = 1;
        end

    end

    function event_peak_lap = GetEventPeakLap(BinnedData,event_peak_frame)
        % input: event_peak_frame
        % output: event_peak_lap

        jj = 0;
        event_peak_lap = [];
        for jj = 1:numel([BinnedData.LapStructure.LapNumber])
            if any(BinnedData.LapStructure(jj).FrameNumber == event_peak_frame)
                event_peak_lap = jj;
                break;
            end
        end

    end

    function Cons_n = event_consecutive_test(event_lap,event_peak_bin,dFoF,n)

        % input: event lap, event bin, dFoF, n bins
        % output: whether the event forms consecutive n bins in space domain in a pseudolap (-24 bins and + 25 bins)

        dFoF_flat = reshape(dFoF.', 1, []);
        event_bin_flat = 50*(event_lap-1) + event_peak_bin;
        pseudolap_full = [];
        pattern = ones(1,n);

        if event_bin_flat-24 < 1
            nan_vector = [];
            pseudolap_short = [];
            nan_vector = nan(1,1-(event_bin_flat-24));
            pseudolap_short = dFoF_flat(1:(event_bin_flat+25));
            pseudolap_full = [nan_vector,pseudolap_short];
        elseif event_bin_flat+25 > numel(dFoF_flat)
            nan_vector = [];
            pseudolap_short = [];
            nan_vector = nan(1,event_bin_flat+25-numel(dFoF_flat));
            pseudolap_short = dFoF_flat((event_bin_flat-24):numel(dFoF_flat));
            pseudolap_full = [pseudolap_short,nan_vector];
        else

            pseudolap_full = dFoF_flat((event_bin_flat-24):(event_bin_flat+25));
        end

        pseudolap_firing = pseudolap_full>0;

        % Step 1: Clean up NaNs
        firing_clean = pseudolap_firing;
        firing_clean(isnan(firing_clean)) = 0;

        % Step 2: Find starting indices of the [1 1 1] pattern
        start_idx = strfind(firing_clean, pattern);

        % Step 3: Get all indices within each [1 1 1] match
        all_indices = [];

        for iii = 1:numel(start_idx)
            all_indices = [all_indices, start_idx(iii):(start_idx(iii)+2)];
        end

        % Optional: make unique if needed
        all_indices = unique(all_indices);

        Cons_n = ismember(25, all_indices);

    end

    function N_3binEvents = Get3binEvents(BinnedData,p)

        N_3binEvents = 0;
        LS = BinnedData.LapStructure;
        FN = [LS.FrameNumber];
        ev = BinnedData.Events(p).Events;
        dfof = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,p));
        if ~isempty(ev)
            ev_running = [];
            ValidEvent_idx = ValidEvents(ev,FN,0,180);
            ev_running = ev(ValidEvent_idx,:);
            if ~isempty(ev_running)
                for k = 1:size(ev_running,1)
                    [ev_bin,ev_lap] = GetEventPeakBin(BinnedData,ev_running(k,5),ev_running(k,6));
                    cons_bin_n = event_consecutive_test(ev_lap,ev_bin,dfof,3);
                    if cons_bin_n == 1
                        N_3binEvents = N_3binEvents+1;
                    end
                end
            end
        end

    end


    function dFoF_laps_block = Get_nlaps_block(n_laps,dFoF,event_lap,event_peak_bin)
        dFoF_laps_block = [];
        dFoF_laps_block_indices = [];
        dFoF_flat = reshape(dFoF.', 1, []);
        event_bin_flat = 50*(event_lap-1) + event_peak_bin;

        for t = 1:n_laps
            dFoF_laps_block_indices(t,2) = event_bin_flat + 50*(t-1);
            dFoF_laps_block_indices(t,1) = dFoF_laps_block_indices(t,2) - 24;
            dFoF_laps_block_indices(t,3) = dFoF_laps_block_indices(t,2) + 25;
        end

        for tt = 1:n_laps
            dFoF_lap_block_full = [];
            if dFoF_laps_block_indices(tt,1) < 1
                nan_vector = [];
                dFoF_lap_short = [];
                nan_vector = nan(1,1-dFoF_laps_block_indices(tt,1));
                dFoF_lap_short = dFoF_flat(1:dFoF_laps_block_indices(tt,3));
                dFoF_lap_block_full = [nan_vector,dFoF_lap_short];
            elseif dFoF_laps_block_indices(tt,3) > numel(dFoF_flat)
                nan_vector = [];
                dFoF_lap_short = [];
                nan_vector = nan(1,dFoF_laps_block_indices(tt,3)-numel(dFoF_flat));
                dFoF_lap_short = dFoF_flat(dFoF_laps_block_indices(tt,1):numel(dFoF_flat));
                dFoF_lap_block_full = [dFoF_lap_short,nan_vector];
            else
                dFoF_lap_block_full = dFoF_flat(dFoF_laps_block_indices(tt,1):dFoF_laps_block_indices(tt,3));
            end
            dFoF_laps_block = [dFoF_laps_block;dFoF_lap_block_full];
        end

    end

end