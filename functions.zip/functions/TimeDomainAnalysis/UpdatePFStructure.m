function UpdatePFStructure(PFStructure,n_ConsBins,rel,folderpath)

% this function is used to update PFStructure.mat to correct bugs

PFStructure_2 = struct();
% load data into PFStructure for further analysis
PFStructure_2.MouseID = PFStructure.MouseID;
PFStructure_2.Genotype = PFStructure.Genotype;
PFStructure_2.ImagingDay = PFStructure.ImagingDay;
PFStructure_2.LapStructure = PFStructure.LapStructure;
PFStructure_2.Cells_F_wobg = PFStructure.Cells_F_wobg;
PFStructure_2.Cells_F0_mode = PFStructure.Cells_F0_mode;
PFStructure_2.Cells_dFoF_mode = PFStructure.Cells_dFoF_mode;
PFStructure_2.Cells_dFoF_denoised = PFStructure.Cells_dFoF_denoised;
PFStructure_2.signal_threshold = PFStructure.signal_threshold;
PFStructure_2.Cells_dFoF_binned_mean = PFStructure.Cells_dFoF_binned_mean;
PFStructure_2.Cells_dFoF_binned_max = PFStructure.Cells_dFoF_binned_max;
PFStructure_2.Cells_dFoF_binned_mean_noisy = PFStructure.Cells_dFoF_binned_mean_noisy;
PFStructure_2.Events = PFStructure.Events;
PFStructure_2.Vel_by_lap = PFStructure.Vel_by_lap;
PFStructure_2.Mean_velocity = PFStructure.Mean_velocity;
PFStructure_2.AnticiLicks_Prob = PFStructure.AnticiLicks_Prob;
PFStructure_2.WS = PFStructure.WS;

PFStructure_2.SpatialInformation_cells = PFStructure.SpatialInformation_cells;
PFStructure_2.ShufflePositive_ornot = PFStructure.ShufflePositive_ornot;

clear PFStructure;

LapStructure = PFStructure_2.LapStructure;
Cells_dFoF_denoised = PFStructure_2.Cells_dFoF_denoised;

% Analyze activity of each lap
[PFStructure_2] = CellStats(PFStructure_2,LapStructure,n_ConsBins);

% Place field analysis
[PFStructure_2] = PFAnalysis(PFStructure_2,rel,0);

% plot and save the sorted PF heatmap
PFs_sorted_heatmap(PFStructure_2,folderpath);

% plot and save the histogram for PF distribution
PFs_dist_histogram(PFStructure_2,folderpath);

% save PFStructure
PFStructure = PFStructure_2;
PFS_filename = strrep(PFStructure_2.WS.FileName, '.h5', '_v3.mat');
fullpath = fullfile(folderpath,PFS_filename);
save(fullpath,'PFStructure');
fprintf('%s PFStructure saved.\n', PFS_filename);

end