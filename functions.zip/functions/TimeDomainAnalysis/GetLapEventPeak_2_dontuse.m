function lap_event_peak = GetLapEventPeak_2(BinnedData,cell,laps,event_peak_frame,event_peak_loc)

% find the peak dFoF for given laps, within +- 45 cm window of the BTSP
% event (using search table)
% for dFoF increase following BTSP analysis

lap_event_peak = [];
events = BinnedData.Events(cell).Events;
events = events((events(:,3)>0) & (events(:,6) >= 0) & (events(:,6) <= 180),:);
events_laps = nan(size(events,1),1);
[event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc);
[SearchTable_BTSP] = Get_SearchTable_BTSP_event(event_peak_bin,event_lap,BinnedData);

for t = 1:size(events,1)
    for jj = 1:numel([BinnedData.LapStructure.LapNumber])
        if any(BinnedData.LapStructure(jj).FrameNumber == events(t,5))
            events_laps(t) = jj;
            break;
        end
    end
end

for k = 1:length(laps)
    if ~isnan(laps(k))
        events_inlap = [];
        events_inlap = find(events_laps == laps(k));
        if ~isempty(events_inlap)
            events_peaks = [];
            events_peaks = events(events_inlap,4);
            lap_event_peak(k) = max(events_peaks);
        else
            lap_event_peak(k) = 0;
        end

    else
        lap_event_peak(k) = NaN;
    end
end


function [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc)
% input: event_peak_frame
% output: event peak bin, event_lap

jj = 0;
event_lap = [];
event_frame_index = [];
for jj = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(jj).FrameNumber == event_peak_frame)
        event_lap = jj;
        event_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == event_peak_frame);
        break;
    end
end

edges = 0:3.6:180;
event_peak_bin = discretize(event_peak_loc, edges);

if event_peak_bin == 50 && event_frame_index <= 10
    event_peak_bin = 1;
end

end
end