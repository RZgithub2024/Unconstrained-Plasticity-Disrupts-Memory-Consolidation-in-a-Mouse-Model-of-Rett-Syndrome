function N_3binEvents = Get3binEvents(Binned_Master_WT)

N_3binEvents = [];
for i = 1:size(Binned_Master_WT,1)
    for j = 1:size(Binned_Master_WT,2)
        BinnedData = Binned_Master_WT{i,j};
        LapStructure = BinnedData.LapStructure;
        frame_numbers = [LapStructure.FrameNumber];
        c = 0;
        for p = 1:size(BinnedData.Cells_dFoF_denoised,1)
            ev = BinnedData.Events(p).Events;
            dFoF = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,p));
            if ~isempty(ev)
                ev_running = [];
                ev_running_index = ismember(ev(:,1), frame_numbers) & ...
                    ismember(ev(:,2), frame_numbers) & ...
                    ismember(ev(:,5), frame_numbers) & ...
                    (ev(:,6) >= 0) & ...
                    (ev(:,6) <= 180) &...
                    (ev(:,3) > 0);
                ev_running = ev(ev_running_index,:);
                if ~isempty(ev_running)
                    for k = 1:size(ev_running,1)
                        [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,ev_running(k,5),ev_running(k,6));
                        if isnan(event_peak_bin)
                            ev_running(k,6)
                        end
                        Cons_n = event_consecutive_test(event_lap,event_peak_bin,dFoF,3);
                        if Cons_n == 1
                            c = c+1;
                        end
                    end
                end
            end
        end
        N_3binEvents = [N_3binEvents;c];

    end
end
end

function [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc)
% input: event_peak_frame
% output: event peak bin, event_lap

jj = 0;
event_lap = [];
event_frame_index = [];
for jj = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(jj).FrameNumber == event_peak_frame)
        event_lap = jj;
        event_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == event_peak_frame);
        break;
    end
end

edges = 0:3.6:180;
event_peak_bin = discretize(event_peak_loc, edges);

if event_peak_bin == 50 && event_frame_index <= 10
    event_peak_bin = 1;
end

end

function event_peak_lap = GetEventPeakLap(BinnedData,event_peak_frame)
% input: event_peak_frame
% output: event_peak_lap

jj = 0;
event_peak_lap = [];
for jj = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(jj).FrameNumber == event_peak_frame)
        event_peak_lap = jj;
        break;
    end
end

end

function Cons_n = event_consecutive_test(event_lap,event_peak_bin,dFoF,n)

% input: event lap, event bin, dFoF, n bins
% output: whether the event forms consecutive n bins in space domain in a pseudolap (-24 bins and + 25 bins)

dFoF_flat = reshape(dFoF.', 1, []);
event_bin_flat = 50*(event_lap-1) + event_peak_bin;
pseudolap_full = [];
pattern = ones(1,n);

if event_bin_flat-24 < 1
    nan_vector = [];
    pseudolap_short = [];
    nan_vector = nan(1,1-(event_bin_flat-24));
    pseudolap_short = dFoF_flat(1:(event_bin_flat+25));
    pseudolap_full = [nan_vector,pseudolap_short];
elseif event_bin_flat+25 > numel(dFoF_flat)
    nan_vector = [];
    pseudolap_short = [];
    nan_vector = nan(1,event_bin_flat+25-numel(dFoF_flat));
    pseudolap_short = dFoF_flat((event_bin_flat-24):numel(dFoF_flat));
    pseudolap_full = [pseudolap_short,nan_vector];
else

    pseudolap_full = dFoF_flat((event_bin_flat-24):(event_bin_flat+25));
end

pseudolap_firing = pseudolap_full>0;

% Step 1: Clean up NaNs
firing_clean = pseudolap_firing;
firing_clean(isnan(firing_clean)) = 0;

% Step 2: Find starting indices of the [1 1 1] pattern
start_idx = strfind(firing_clean, pattern);

% Step 3: Get all indices within each [1 1 1] match
all_indices = [];

for iii = 1:numel(start_idx)
    all_indices = [all_indices, start_idx(iii):(start_idx(iii)+2)];
end

% Optional: make unique if needed
all_indices = unique(all_indices);

Cons_n = ismember(25, all_indices);

end
