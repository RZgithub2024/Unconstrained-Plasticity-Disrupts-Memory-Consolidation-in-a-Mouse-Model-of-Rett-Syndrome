function [PFStats] = Get_PFdata(PFStructure)

% Get Number of PFs, Percentage of PFs, Total PFs, PF IDs

PFStats = [];
PForNot = PFStructure.PForNot;
PFStats.PFIDs = find(PForNot(:,7));
PFStats.NotPFs = find(PForNot(:,7)==0);
PFStats.Total_N = size(PForNot,1);
PFStats.No_PFs = size(PFStats.PFIDs,1);
PFStats.Percentage = (PFStats.No_PFs/PFStats.Total_N)*100;

end