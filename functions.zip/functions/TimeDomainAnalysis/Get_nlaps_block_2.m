function dFoF_laps_block = Get_nlaps_block_2(n_laps,dFoF,start_lap,center_bin)

% get n pseudo laps according to a given search center

dFoF_laps_block = [];
dFoF_laps_block_indices = [];
dFoF_flat = reshape(dFoF.', 1, []);
event_bin_flat = 50*(start_lap-1) + center_bin;

for t = 1:n_laps
    dFoF_laps_block_indices(t,2) = event_bin_flat + 50*(t-1);
    dFoF_laps_block_indices(t,1) = dFoF_laps_block_indices(t,2) - 24;
    dFoF_laps_block_indices(t,3) = dFoF_laps_block_indices(t,2) + 25;
end

for tt = 1:n_laps
    dFoF_lap_block_full = [];
    if dFoF_laps_block_indices(tt,1) < 1
        nan_vector = [];
        dFoF_lap_short = [];
        nan_vector = nan(1,1-dFoF_laps_block_indices(tt,1));
        dFoF_lap_short = dFoF_flat(1:dFoF_laps_block_indices(tt,3));
        dFoF_lap_block_full = [nan_vector,dFoF_lap_short];
    elseif dFoF_laps_block_indices(tt,3) > numel(dFoF_flat)
        nan_vector = [];
        dFoF_lap_short = [];
        nan_vector = nan(1,dFoF_laps_block_indices(tt,3)-numel(dFoF_flat));
        dFoF_lap_short = dFoF_flat(dFoF_laps_block_indices(tt,1):numel(dFoF_flat));
        dFoF_lap_block_full = [dFoF_lap_short,nan_vector];
    else
        dFoF_lap_block_full = dFoF_flat(dFoF_laps_block_indices(tt,1):dFoF_laps_block_indices(tt,3));
    end
    dFoF_laps_block = [dFoF_laps_block;dFoF_lap_block_full];
end

end