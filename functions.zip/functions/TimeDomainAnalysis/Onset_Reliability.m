function [Onset,Reliability] = Onset_Reliability(PFStructure)

%{

PF_Firing : Finds 3/5 firing criteria to find the onset of Firing within
the prospective PF and the reliability till the end of the session if onset
is found.

 
ARGS:

- Binned : (struct) Mother Structure that saves all processed Ca data. Used
here to access Binned.Cellstats (cell X nLaps X 25) with firing record for each cell. 


RETURNS:

- Onset : (double) 1 X nROIs: if detected, location of first 3/5 firing

- Reliability : (double) 1 X nROIs: If Onset detected, measured Reliability 

ALGORITHM:

- Uses a movsum window of 5 on a logical firing or not array. the window
center is 3 so corrects for that and end effects. 

- Measures Onset as first instance where lap is firing and movsum window is
3

- Reliability is measured as % of firing trials from onset 
%}



for cell = 1:size(PFStructure.Cells_dFoF_denoised,1)
    [Onset(cell),Reliability(cell)] = Find_Onset_Reliability(PFStructure,cell);    
end

end



function [Onset,Reliability] = Find_Onset_Reliability(PFStructure,Cell)

PFloc = squeeze(PFStructure.Cellstats(Cell,:,7)); % 7 is PFloc in Cellstats

% Firing or Not Array
Firing = (~isnan(PFloc));


% Get a summing sliding window and correct for end effects
Window_Sum5 = movsum(Firing,5);
% circshift window as default window center is 3 for movsum with 5
Window_Sum5 = circshift(Window_Sum5,-2);
% Correct for last 4 laps; They have movsum artifact anyways.
Window_Sum5(end-3) = nansum(Firing(end-3:end));
Window_Sum5(end-2) = nansum(Firing(end-2:end));% not needed
Window_Sum5(end-1) = nansum(Firing(end-1:end));% not needed
Window_Sum5(end) = Firing(end);


% 3 out of 5 firing is when Window Sum is 3 and its a firing lap
% Calculate Reliability and Onset if there is 3/5 firing

Firing_3_5 = find(Window_Sum5>2 & Firing);
if ~isempty(Firing_3_5)
   Onset = Firing_3_5(1);
   Reliability = nansum(Firing(Onset:end))/size(Firing(Onset:end),2);
else
   Onset = NaN;
   Reliability = NaN;
end

end