function [COM] = Find_COM(dFoF_mean_50_bins)

r = dFoF_mean_50_bins./nanmean(dFoF_mean_50_bins);

x = [];
y = [];

for p = 1:50
    p_radians = (p - 1) * (2 * pi / 50);
    x(p) = r(p) * cos(p_radians);
    y(p) = r(p) * sin(p_radians);
end

COM_x = nanmean(x);
COM_y = nanmean(y);
r_COM = sqrt(COM_x^2 + COM_y^2);
theta_COM = atan2(COM_y, COM_x);
theta_COM = mod(theta_COM, 2*pi);
COM = theta_COM / (2 * pi) * 180;

end