function [PFLoc,rhoPF] = Find_COM_2(Lap_dFoF_in_bins)

theta = deg2rad((360/50).*(1:1:50));
rho = Lap_dFoF_in_bins./nanmean(Lap_dFoF_in_bins); % Normalization by activity across track
[cartx,carty] = pol2cart(theta,rho);
[centroidx,centroidy] = centroid(polyshape(cartx,carty));
[thetaR,rhoPF] = cart2pol(centroidx,centroidy);
thetaPF = rad2deg(thetaR);

if (thetaPF<0)
   thetaPF = thetaPF + 360;
end

PFLoc = thetaPF*(180/360);

end