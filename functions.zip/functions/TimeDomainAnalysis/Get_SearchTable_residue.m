function [Search_table] = Get_SearchTable_residue(pros_PF_binloc,LapStructure)

%{

Takes a Bin and using Laps puts out the search parameters in terms of bins
and frames for every lap.

Window of search is 45 cm or 12.5 bins. So bin 25; midpoint - 24.5 so
Search 12 onwards through 37.

Search Table Params;

    1. Lap
    2. Start Search Lap
    3. Start Search Loc
    4. End Search Lap
    5. End Search Loc
    6. Flattened array start search bin
    7. Flattened array end search bin
    8. Lap Start Search Loc Frame
    9. Lap End Search Loc Frame

ALGORITHM

- For a given bin, puts out a 'search template' - tells which lap (previous or current) and bin
to look for start and end (current or next lap)
- Using the search template, populates a cell specific lap by lap search
area defined by lap number and start and end bin
- Gets the Frame number and bin number for a flattened array for the start
and end of search area for each lap.
- Corrects for expected anomalies at the start and end of sesssion. 

%}

%% Make a template to generate the search table
Search_template = zeros(1,4);
% [1) Start lap(0 or previous lap -1); 2) which bin; 3) End lap (0 or next lap +1); 4) which bin

Search_template(2) = pros_PF_binloc - 13; % 0.5 bin + another 12 before
if(pros_PF_binloc == 13) % There is no bin zero
    Search_template(2) = pros_PF_binloc - 14;
end
Search_template(4) = pros_PF_binloc + 12; % 0.5 bin + another 12 after

if Search_template(2)<0
    Search_template(1) = -1;
    Search_template(2) = 50 + Search_template(2);
end

if Search_template(4)>50
    Search_template(3) = 1;
    Search_template(4) = Search_template(4)-50;
end

%% Fill the Search table based on search template and correct starts/ends

% Get search area bins and location based on template for each lap
laps = LapStructure.LapNumber;
Search_table(:,1) = 1:numel(laps); % Lap number
Search_table(:,2) = Search_table(:,1) + Search_template(1); % Lap number to start search area
Search_table(:,3) = Search_template(:,2) * 3.6; % Location to start search area
Search_table(:,4) = Search_table(:,1) + Search_template(3); % Lap to stop search area
Search_table(:,5) = Search_template(:,4) * 3.6; % Location to end search area

% Correct for first lap and last lap if search area is before and after
% data acquisiton 
if (Search_table(1,2) == 0)
    Search_table(1,2) = 1; % Start
    Search_table(1,3) = 0;
end

% if (Search_table(end,4)>numel([LapStructure.LapNumber]))
%     Search_table(end,4) = numel([LapStructure.LapNumber]);
%     Search_table(end,5) = 180;
% end

% Fill in exact bin locations of a flatenned array and corresponding frame
% locations based on lapwise data from first 5 columns

for i = 1:numel([LapStructure.LapNumber])
%    disp(i);
   Search_table(i,6) = (i+Search_template(1)-1)*50 + Search_template(2);  % Flattened array search start bin
   Search_table(i,7) = (i+Search_template(3)-1)*50 + Search_template(4);  % Flattened array search end bin
   % Find Frame given lap and location
   Search_Lap_Start = Search_table(i,2); Search_Start_Loc = Search_table(i,3);
   % Access Lap frames and Distance. Find the minimum dist difference with
   % the target location for the lap; find the corresponding frame.
   [min_dist,idx_start] = min(abs((LapStructure(Search_Lap_Start).Distance_frame * 100)-Search_Start_Loc)); 
   Search_table(i,8) = LapStructure(Search_Lap_Start).FrameNumber(idx_start); % Frame number for start search
   Search_Lap_End = Search_table(i,4);
   Search_End_Loc = Search_table(i,5);
   [min_dist,idx_end] = min(abs((LapStructure(Search_Lap_End).Distance_frame * 100)-Search_End_Loc)); 
   Search_table(i,9) = LapStructure(Search_Lap_End).FrameNumber(idx_end); % Frame number for end search.
end

% take care of ends

if Search_table(1,6) < 0
    Search_table(1,6) =1;
end

% if Search_template(3) == 1
%     Search_table(end,7) = numel([LapStructure.LapNumber])*50;
% 
% end

end