function lap_event_peak = GetLapEventPeak(BinnedData,cell,laps)

% find the peak dFoF for given laps
% for dFoF increase following BTSP analysis 
lap_event_peak = [];
events = BinnedData.Events(cell).Events;
events = events((events(:,3)>0) & (events(:,6) >= 0) & (events(:,6) <= 180),:);
events_laps = nan(size(events,1),1);
for t = 1:size(events,1)
    for jj = 1:numel([BinnedData.LapStructure.LapNumber])
        if any(BinnedData.LapStructure(jj).FrameNumber == events(t,5))
            events_laps(t) = jj;
            break;
        end
    end
end

for k = 1:length(laps)
    if ~isnan(laps(k))
        events_inlap = [];
        events_inlap = find(events_laps == laps(k));
        if ~isempty(events_inlap)
            events_peaks = [];
            events_peaks = events(events_inlap,4);
            lap_event_peak(k) = max(events_peaks);
        else
            lap_event_peak(k) = 0;
        end

    else
        lap_event_peak(k) = NaN;
    end
end

end