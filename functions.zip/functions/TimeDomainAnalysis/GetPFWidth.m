function PFwidth_mean = GetPFWidth(BinnedData,ROI)

% calculate the PF with in cm
% average the events width of firing laps
% exclude events width <= 0 (backward running)
% ROI is the ROI ID of a PC

cellstats = squeeze(BinnedData.Cellstats(ROI,:,:));
Onset = BinnedData.Onset;
Firing_laps = find(~isnan(cellstats(:,7)));
Firing_laps(Firing_laps<Onset(ROI)) = [];

m = cellstats(Firing_laps,10);
pfw = m(m>0);
PFwidth_mean = nanmean(pfw,1);

end