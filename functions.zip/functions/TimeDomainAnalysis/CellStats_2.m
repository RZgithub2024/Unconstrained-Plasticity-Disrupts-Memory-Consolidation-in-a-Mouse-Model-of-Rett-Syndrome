function [PFStructure] = CellStats_2(PFStructure,LapStructure,n_ConsBins)

%{

CellStats : For every cell, finds the laps where there are significant
events in Time Domain with peak within 45 cm of the average peak for the session.

 
ARGS:

- Laps: (struct) 1 x nLaps houses all info regarding Laps

- Binned : (struct) Mother Structure that saves all processed Ca data. Used
here to get binned denoised dFoF. 


RETURNS:

- Binned : (struct) Adds Binned.Cellstats (cell X nLaps X 25) with firing record for each cell

ALGORITHM:

for every cell
- Gets dF/F average and finds peak for the session 
- Identifies all events with at least some part in the running domain that
have a peak within 45 cm of the average peak.
- Extracts the following details lap-wise and stores in CellStats

Cellstats:
    1. Animal ID (e.g. 209)
    2. Recording date
    3. Cell Number
    4. Lap
    5. Peak Amplitude of Event (dF/F)
    6. Peak Amplitude Location (Frame)
    7. Peak Amplitude Location (Distance - cm)
    8. Event Start Location (cm)
    9. Event End Location (cm)
    10. Event Width (cm)
    11. Event Duration (ms)
    12. COM

%}

Cellstats = [];
Search_Table = [];

for cell = 1:size(PFStructure.Cells_dFoF_denoised,1)
    [Cellstats(cell,:,:),Search_Table(cell,:,:)] = Get_cellstats(PFStructure,LapStructure,cell,n_ConsBins);
end

PFStructure.Cellstats = Cellstats;
PFStructure.Search_Table = Search_Table;
end

function [Cellstats,Search_Table] = Get_cellstats(PFStructure,LapStructure,cell,n_ConsBins)

% disp(cell); 
Cellstats = nan(numel([LapStructure.LapNumber]),25);
Cellstats(:,1) = str2num(PFStructure.MouseID(3:5));
Cellstats(:,2) = PFStructure.ImagingDay;
Cellstats(:,3) = cell;
for i = 1:numel([LapStructure.LapNumber])
    Cellstats(i,4) = i; % Lap
end

dFoF = PFStructure.Cells_dFoF_binned_mean(:,:,cell); % binned denoised dFoF;
Events = PFStructure.Events(cell).Events;
ConsBins = ones(1, n_ConsBins);

if (~isempty(Events))

   Events_Running = Events(Events(:,3)>0,:); % Filter for events that have a some part when the animal is running.
   
   %% Find Prospective PF location using peak of Avg DFoF
   Avg_dFoF = nanmean(dFoF,1);
   [~,pros_PF_binloc] = max(Avg_dFoF);
   
   %% Make Search Table for every lap
   % Search Table provides the frame numbers and bin numbers of a flattened
   % array to mark the start and end search areas for every lap
   [Search_Table] = Get_SearchTable(pros_PF_binloc,LapStructure);
   
   %% See if there are 3 continous firing bins for the location of every lap;
   Flat_firing_array = reshape((dFoF>0).',1,[]); % Flatten the dFoF array and find firing bins

   % Get centered dFoF array for COM calculation; flatten, shift, reshape
   Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
   shift = 25 - pros_PF_binloc; % positive if <25; negative if >25;
   Centered_flat_array = circshift(Flat_array,shift);
   Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM
   
   %disp(cell)
   for i = 1:numel([LapStructure.LapNumber])
       %disp(i)
       search_string = Flat_firing_array(Search_Table(i,6):Search_Table(i,7));
       if ~isempty(strfind(search_string,ConsBins)) % if there are n_ConsBins bins with continuous firing
          %disp('yes')
          % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
          event_idx = [];
          event_idx = find(Events_Running(:,5)>(Search_Table(i,8)-1) &...
              Events_Running(:,5)<(Search_Table(i,9)+1) &...
              Events_Running(:,6) >= 0 &...
              Events_Running(:,6) <= 180);
          if ~isempty(event_idx) % Can happen when there is firing inside the search but peak is outside
             [x,idx] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
             Cellstats(i,5:11) = Events_Running(event_idx(idx),4:10);
             warning('off') % suppress Polyshape warning during execution
             [PFLoc_COM,~] = Find_COM_2(Centered_dFoF(i,:));
             Cellstats(i,12) = PFLoc_COM-(shift*3.6); % COM is in cm; shift is in bins
             if Cellstats(i,12) > 180
                Cellstats(i,12) = Cellstats(i,12)-180;
             elseif Cellstats(i,12) < 0
                Cellstats(i,12) = 180 - Cellstats(i,12);
             end
             warning('on')
          end
       end

    end

else
   Search_Table = nan(numel([LapStructure.LapNumber]),9);
end

end