function [BTSPstats,PlateauThereshold_BTSP,Plateau_events] = BTSPStats_8(BinnedData)

%%
%     BTSPstats: lap based, each row is a lap
%     1. Animal ID (e.g. 32)
%     2. Longitudinal Day
%     3. Cell ID
%     4. Lap
%     5. threshold for top 20 percentile events (dFoF) of a given cell
%     6. Peak Amplitude (dFoF)
%     7. Peak Amplitude >= top 20 percetile && >= 1 && at least 5 laps
%     after qualifying events, 1 = true, 0 = false
%     8-14. Cellstats column 5-11 for putative plateaus
%     15. Post-five firing lap or not (+- 45 cm of the putative plateau)
%     16. Whether there are at least 3 out of 5 laps firing after induction
%     17. COM of BTSP induction lap
%     18. COM of mean activity of firing laps from five post-induction laps
%     19. COM shift distance (+, 0, -)
%     20. COM backward shift or not
%     21. Whether nansum(column 7,16,20) == 3, 1 = true, 0 = false
%     22. BTSP event or not, 1 = true, others = NaN
%     23. Whether a given cell is a PC, 1 = PC, 0 = non-PC
%     24-30. Events column 4-10 for post firing laps

%     Plateau_events: record plateau events
%     1. Animal ID (e.g. 32)
%     2. Longitudinal Day
%     3. Cell ID
%     4. Lap where the event happened
%     5. Plateau threshold
%     6-15. Events column 1-10
%     16. Identified BTSP induction event = 1, other plateaus = 2
%     17. Whether a given cell is a PC, 1 = PC, 0 = non-PC

% this function looks for BTSP events in both PCs and non-PCs using Cellstats data

BTSPstats = [];
PlateauThereshold_BTSP = [];
Plateau_events = {};
delete(gcp('nocreate'));
parfor cell = 1:size(BinnedData.Cells_dFoF_denoised,1)
    [BTSPstats(cell,:,:),PlateauThereshold_BTSP(cell),Plateau_events{cell}] = Get_btspstats(BinnedData,cell);
end
delete(gcp('nocreate'));
end


function [BTSPStats,PlateauThereshold_BTSP,pl_events] = Get_btspstats(BinnedData,cell)

PlateauThereshold_BTSP = NaN;
BTSPStats = nan(numel([BinnedData.LapStructure.LapNumber]),35);
pl_events = [];

if ismember(cell,BinnedData.PFStats.PFIDs)
    BTSPStats(:,23) = 1;
else
    BTSPStats(:,23) = 0;
end

BTSPStats(:,1) = str2num(BinnedData.AnimalID(3:5));
BTSPStats(:,2) = BinnedData.LongitudinalDay;
BTSPStats(:,3) = cell;
for i = 1:numel([BinnedData.LapStructure.LapNumber])
    BTSPStats(i,4) = i;
end

dFoF = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,cell));
Flat_firing_array = reshape((dFoF>0).',1,[]);
Events = [];
Events = BinnedData.Events(cell).Events;
frame_numbers = [BinnedData.LapStructure.FrameNumber];
puPlateau_peak_dFoF = [];

if ~isempty(Events)
    Events_Running = [];
    events_running_idx = [];
    events_running_idx = ismember(Events(:,1), frame_numbers) & ...
        ismember(Events(:,2), frame_numbers) & ...
        ismember(Events(:,5), frame_numbers) & ...
        (Events(:,3) > 0) & ...
        (Events(:,6) >= 0) & ...
        (Events(:,6) <= 180);
    Events_Running = Events(events_running_idx,:);
    if ~isempty(Events_Running)
        Firing_laps = [];
        Firing_laps = find(~isnan(squeeze(BinnedData.Cellstats(cell,:,5))));
        if ~isempty(Firing_laps)
            Events_top20_thres = [];
            Events_top20_thres = prctile(squeeze(BinnedData.Cellstats(cell,Firing_laps,5)),80);
            Events_Running_frames = [];
            Events_Running_frames = Events_Running(:,5);
            for n = 1:numel(Firing_laps)
                m = Firing_laps(n);
                if m <= (numel([BinnedData.LapStructure.LapNumber])-5)
                    BTSPStats(m,5) = Events_top20_thres;
                    BTSPStats(m,6) = BinnedData.Cellstats(cell,m,5);
                    if ismember(BinnedData.Cellstats(cell,m,6),Events_Running_frames)
                        if BinnedData.Cellstats(cell,m,5) >= Events_top20_thres &&...
                                BinnedData.Cellstats(cell,m,5) >= 1
                            
                            BTSPStats(m,7) = 1;
                            BTSPStats(m,8:14) = BinnedData.Cellstats(cell,m,5:11);

                            event_peak_bin = [];
                            event_peak_lap = [];
                            [event_peak_bin,event_peak_lap] =...
                                GetEventPeakBin(BinnedData,BinnedData.Cellstats(cell,m,6),BinnedData.Cellstats(cell,m,7));
                            
                            if isnan(event_peak_bin)
                                cell
                                BinnedData.Cellstats(cell,m,7)
                                return
                            end
                            
                            [SearchTable_BTSP] = Get_SearchTable_BTSP_event(event_peak_bin,event_peak_lap,BinnedData);

                            PostFiveLaps = (m+1):(m+5);
                            count = 0;
                            PostFiveLaps_firing = [];
                            for i = 1:5
                                ii = PostFiveLaps(i);
                                if ~isempty(SearchTable_BTSP)
                                    search_string_BTSP = Flat_firing_array(SearchTable_BTSP(i,1):SearchTable_BTSP(i,3));
                                    if ~isempty(strfind(search_string_BTSP,[1 1 1]))
                                        % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                                        event_idx = find(Events_Running(:,5)>(SearchTable_BTSP(i,10)-1) & Events_Running(:,5)<(SearchTable_BTSP(i,11)+1));
                                        if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside
                                            BTSPStats(ii,15) = 1;
                                            count = count + 1;
                                            PostFiveLaps_firing = [PostFiveLaps_firing,i];
                                            [~,idx] = max(Events_Running(event_idx,4)); % find the strongest event if there are multiple events
                                            BTSPStats(ii,24:30) = Events_Running(event_idx(idx),4:10);
                                        end
                                    end
                                end
                            end

                            if count >= 3
                                BTSPStats(m,16) = 1;
                                % examine the backward shift after BTSP induction
                                dFoF_laps_block = [];
                                dFoF_laps_block = Get_nlaps_block(6,dFoF,event_peak_lap,event_peak_bin);

                                warning('off');
                                [COM_induction_lap,~] = Find_COM_2(dFoF_laps_block(1,:));
                                valid_laps = PostFiveLaps_firing + 1;
                                dFoF_PostFiveLaps_firing = dFoF_laps_block(valid_laps,:);
                                dFoF_PostFiveLaps_firing_mean = nanmean(dFoF_PostFiveLaps_firing,1);
                                [COM_PostFiveLaps_firing,~] = Find_COM_2(dFoF_PostFiveLaps_firing_mean);
                                warning('on');

                                % debug
                                if isnan(COM_induction_lap)
                                    disp('induction lap');
                                    disp([num2str(cell), ',', num2str(m)]);
                                    disp(num2str(dFoF_laps_block));
                                end
                                if isnan(COM_PostFiveLaps_firing)
                                    disp('COM_PostFiveLaps_firing');
                                    disp([num2str(cell), ',', num2str(m)]);
                                    disp(num2str(dFoF_PostFiveLaps_firing));
                                end

                                BTSP_shift_cm = BeltDistShift(COM_induction_lap,COM_PostFiveLaps_firing);
                                BTSPStats(m,17) = COM_induction_lap;
                                BTSPStats(m,18) = COM_PostFiveLaps_firing;
                                BTSPStats(m,19) = BTSP_shift_cm;

                                if BTSP_shift_cm < 0
                                    BTSPStats(m,20) = 1;
                                else
                                    BTSPStats(m,20) = 0;
                                end
                            else
                                BTSPStats(m,16) = 0;
                            end
                        else
                            BTSPStats(m,7) = 0;
                        end
                    end
                end

                if nansum([BTSPStats(m,7),BTSPStats(m,16),BTSPStats(m,20)]) == 3
                    BTSPStats(m,21) = 1;
                    puPlateau_peak_dFoF = [puPlateau_peak_dFoF;BTSPStats(m,6)];
                end
            end

            btsp_idx = [];
            btsp_idx = find(BTSPStats(:,21) == 1, 1, 'first');
            if ~isempty(btsp_idx)
                BTSPStats(btsp_idx,22) = 1;
                PlateauThereshold_BTSP = min(puPlateau_peak_dFoF);
                for kk = 1:size(Events_Running,1)
                    if Events_Running(kk,4) >= PlateauThereshold_BTSP
                        event_info = [];
                        event_info(1:3) = BTSPStats(btsp_idx,1:3);
                        [~,event_info(4)] = GetEventPeakBin(BinnedData,Events_Running(kk,5),Events_Running(kk,6));
                        event_info(5) = PlateauThereshold_BTSP;
                        event_info(6:15) = Events_Running(kk,1:10);
                        if Events_Running(kk,5) == BinnedData.Cellstats(cell,btsp_idx,6)
                            event_info(16) = 1;
                        else
                            event_info(16) = 2;
                        end
                        pl_events = [pl_events;event_info];
                    end
                end
            end

        end
    end
end

if ~isempty(pl_events)
    if ismember(cell,BinnedData.PFStats.PFIDs)
        pl_events(:,17) = 1;
    else
        pl_events(:,17) = 0;
    end
end

    function [event_peak_bin,event_lap] = GetEventPeakBin(BinnedData,event_peak_frame,event_peak_loc)
        % input: event_peak_frame
        % output: event peak bin, event_lap

        event_lap = [];
        event_frame_index = [];
        for ji = 1:numel([BinnedData.LapStructure.LapNumber])
            if any(BinnedData.LapStructure(ji).FrameNumber == event_peak_frame)
                event_lap = ji;
                event_frame_index = find([BinnedData.LapStructure(ji).FrameNumber] == event_peak_frame);
                break;
            end
        end

        edges = 0:3.6:180;
        event_peak_bin = discretize(event_peak_loc, edges);
        
        if event_peak_loc >= -3.6 && event_peak_loc < 0
            event_peak_bin = 1;
        end

        if event_peak_loc > 180 && event_peak_loc <= 183.6
            event_peak_bin = 50;
        end

        if event_peak_bin == 50 && event_frame_index <= 10
            event_peak_bin = 1;
        end

    end


    function dFoF_laps_block = Get_nlaps_block(n_laps,dFoF,event_lap,event_peak_bin)
        dFoF_laps_block = [];
        dFoF_laps_block_indices = [];
        dFoF_flat = reshape(dFoF.', 1, []);
        event_bin_flat = 50*(event_lap-1) + event_peak_bin;

        for t = 1:n_laps
            dFoF_laps_block_indices(t,2) = event_bin_flat + 50*(t-1);
            dFoF_laps_block_indices(t,1) = dFoF_laps_block_indices(t,2) - 24;
            dFoF_laps_block_indices(t,3) = dFoF_laps_block_indices(t,2) + 25;
        end

        for tt = 1:n_laps
            dFoF_lap_block_full = [];
            if dFoF_laps_block_indices(tt,1) < 1
                nan_vector = [];
                dFoF_lap_short = [];
                nan_vector = nan(1,1-dFoF_laps_block_indices(tt,1));
                dFoF_lap_short = dFoF_flat(1:dFoF_laps_block_indices(tt,3));
                dFoF_lap_block_full = [nan_vector,dFoF_lap_short];
            elseif dFoF_laps_block_indices(tt,3) > numel(dFoF_flat)
                nan_vector = [];
                dFoF_lap_short = [];
                nan_vector = nan(1,dFoF_laps_block_indices(tt,3)-numel(dFoF_flat));
                dFoF_lap_short = dFoF_flat(dFoF_laps_block_indices(tt,1):numel(dFoF_flat));
                dFoF_lap_block_full = [dFoF_lap_short,nan_vector];
            else
                dFoF_lap_block_full = dFoF_flat(dFoF_laps_block_indices(tt,1):dFoF_laps_block_indices(tt,3));
            end
            dFoF_laps_block = [dFoF_laps_block;dFoF_lap_block_full];
        end

    end


end