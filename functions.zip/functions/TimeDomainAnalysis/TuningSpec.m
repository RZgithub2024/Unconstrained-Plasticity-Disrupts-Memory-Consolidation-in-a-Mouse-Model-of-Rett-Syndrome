function ts = TuningSpec(BinnedData,p)

% calculate tuning specificity for a given cell
ts = [];
Events = BinnedData.Events(p).Events;
frame_numbers = [BinnedData.LapStructure.FrameNumber];
LapStructure = BinnedData.LapStructure;
if ~isempty(Events)
    Events_Running = [];
    events_running_idx = [];
    events_running_idx = ismember(Events(:,1), frame_numbers) & ...
        ismember(Events(:,2), frame_numbers) & ...
        ismember(Events(:,5), frame_numbers) & ...
        (Events(:,3) > 0) & ...
        (Events(:,6) >= -1.8) & ...
        (Events(:,6) <= 181.8);
    Events_Running = Events(events_running_idx,:);
    if ~isempty(Events_Running)
        events_loc = [];
        occupancy_events = [];
        for k = 1:size(Events_Running,1)
            [event_peak_bin,event_lap] = GetEventPeakBin_2(BinnedData,Events_Running(k,5),Events_Running(k,6));
            occupancy = [];
            Distance_frame_running = LapStructure(event_lap).Distance_frame_running * 100;
            edges = 0:3.6:180;
            [counts,~] = histcounts(Distance_frame_running,edges);
            occupancy = counts(event_peak_bin)/sum(counts);
            events_loc = [events_loc,Events_Running(k,6)];
            occupancy_events = [occupancy_events,occupancy];
        end
        [events_rad] = loc2rad(events_loc);
        x = cos(events_rad) ./ occupancy_events;
        y = sin(events_rad) ./ occupancy_events;
        sum_x = sum(x);
        sum_y = sum(y);
        ts = sqrt(sum_x^2 + sum_y^2)/length(events_loc);
    end
end
end