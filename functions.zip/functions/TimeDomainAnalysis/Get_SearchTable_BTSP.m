function [SearchTable_BTSP] = Get_SearchTable_BTSP(cell,m,BinnedData)

%{
Window of search is 45 cm or 12.5 bins.

Search Table Column Params:

    1. Flattened array, start search bin
    2. Flattened array, midpoint of search bins
    3. Flattened array, end search bin
    4. Non-flattened array, start search bin
    5. Non-flattened array, end search bin
    6. Non-flattened array, start search location in cm
    7. Non-flattened array, end search location in cm
    8. Non-flattened array, start search lap
    9. Non-flattened array, end search lap
    10. Lap Start Search Loc Frame
    11. Lap End Search Loc Frame


%}
SearchTable_BTSP = [];
puPlateau_location_frame = BinnedData.Cellstats(cell,m,6);
puPlateau_location_cm = BinnedData.Cellstats(cell,m,7);

edges = 0:3.6:180;
puPlateau_location_bin = discretize(puPlateau_location_cm, edges);

jj = 0;
puPlateau_location_lap = [];
for jj = 1:numel([BinnedData.LapStructure.LapNumber])
    if any(BinnedData.LapStructure(jj).FrameNumber == puPlateau_location_frame)
       puPlateau_location_lap = jj;
       puPlateau_frame_index = find([BinnedData.LapStructure(jj).FrameNumber] == puPlateau_location_frame);
       break;
    end
end

if puPlateau_location_bin == 50 && puPlateau_frame_index <= 10
   puPlateau_location_bin = 1;
end

if ~(isempty(puPlateau_location_lap))

puPlateau_location_bin_flat = [];
if puPlateau_location_lap == m
   puPlateau_location_bin_flat = (m - 1) * 50 + puPlateau_location_bin;
                
elseif puPlateau_location_lap < m
   puPlateau_location_bin_flat = (m - 2) * 50 + puPlateau_location_bin;

elseif puPlateau_location_lap > m
   puPlateau_location_bin_flat = m * 50 + puPlateau_location_bin;
end


for n = 1:5
    SearchTable_BTSP(n,2) = puPlateau_location_bin_flat + 50 * n;
    SearchTable_BTSP(n,1) = SearchTable_BTSP(n,2) - 12;
    if SearchTable_BTSP(n,1) < 1
       SearchTable_BTSP(n,1) = 1;
    end
    SearchTable_BTSP(n,3) = SearchTable_BTSP(n,2) + 12;
    if SearchTable_BTSP(n,3) > 50 * max([BinnedData.LapStructure.LapNumber])
       SearchTable_BTSP(n,3) = 50 * max([BinnedData.LapStructure.LapNumber]);
    end
    
    SearchTable_BTSP(n,4) = lap_mod(SearchTable_BTSP(n,1),50);
    SearchTable_BTSP(n,5) = lap_mod(SearchTable_BTSP(n,3),50);
    SearchTable_BTSP(n,6) = SearchTable_BTSP(n,4) * 3.6;
    SearchTable_BTSP(n,7) = SearchTable_BTSP(n,5) * 3.6;

    SearchTable_BTSP(n,8) = ceil(SearchTable_BTSP(n,1)/50);
    SearchTable_BTSP(n,9) = ceil(SearchTable_BTSP(n,3)/50);

    [~,idx_start] = min(abs((BinnedData.LapStructure(SearchTable_BTSP(n,8)).Distance_frame * 100)-SearchTable_BTSP(n,6)));
    SearchTable_BTSP(n,10) = BinnedData.LapStructure(SearchTable_BTSP(n,8)).FrameNumber(idx_start);

    [~,idx_end] = min(abs((BinnedData.LapStructure(SearchTable_BTSP(n,9)).Distance_frame * 100)-SearchTable_BTSP(n,7)));
    SearchTable_BTSP(n,11) = BinnedData.LapStructure(SearchTable_BTSP(n,9)).FrameNumber(idx_end);
end
end

end