function [Events] = Find_Events(Cells_dFoF_denoised,WS)
%{

Find_Events : Uses denoised trace of every ROI to find the Ca events.

 
ARGS:

- Binned: (struct) Mothership with all data. denoised trace retrieved here. 

- WS: (struct) WS data used to find running frames 

RETURNS:

- Events : (struct) (n = nROIs; Each ROI has x events) attached to Binnned.Events with following
params:
    
    Each ROI table has following params for each event:
    
    1. Start Frame Number
    2. End Frame Number
    3. Start : End has at least 3 running frames
    4. Peak Amplitude of Event (dF/F)
    5. Peak Amplitude Location (Frame)
    6. Peak Amplitude Location (Distance - cm)
    7. Event Start Location (cm)
    8. Event End Location (cm)
    9. Event Width (cm)
    10. Event Duration (ms) 


%}

Frames_all_WS = find(WS.FrameArray);
Frames_run_WS = find(WS.FrameArray & WS.RunningOrNot);
Frames_Running = sort(find(ismember(Frames_all_WS,Frames_run_WS)));
Location = WS.Dist(Frames_all_WS);

for p = 1:size(Cells_dFoF_denoised,1)
    Events(p).Events = Get_Cell_Events(Cells_dFoF_denoised,p,Frames_Running,Location);
end

end

function [Events_cleaned] = Get_Cell_Events(Cells_dFoF_denoised,cellID,Frames_Running,Location) 

signal = Cells_dFoF_denoised(cellID,:);
signal(1) = 0;
signal(end) = 0;
% disp(cell);
if nansum(signal) > 0
    Events(:,1) = strfind((signal>0),[0 1]); % Start
    Events(:,2) = strfind((signal>0),[1 0]); % Stop
    %Events(:,3) = ismember(Events(:,1),Frames_Running)|ismember(Events(:,2),Frames_Running); % Running or Not

    for i = 1:size(Events,1)
        Events(i,3) = nansum(ismember((Events(i,1):Events(i,2)),Frames_Running))>2; % Event has at least 3 running frames
       [Events(i,4),Events(i,5)] = max(signal(Events(i,1):Events(i,2))); % Peak Amp
    end
    Events(:,5) = Events(:,5) + Events(:,1) - 1; % Peak loc (Frames)
    Events(:,6) = Location(Events(:,5))*100; % Peak loc (cm)
    Events(:,7) = Location(Events(:,1))*100; % Event Start loc (cm)
    Events(:,8) = Location(Events(:,2))*100; % Event End loc (cm)
    for ii = 1:size(Events,1)
        Events(ii,9) = EventWidth(Events(ii,7),Events(ii,8)); % Event Width (cm)
    end
    Events(:,10) = (Events(:,2)-Events(:,1)) * 33.33; % Event Duration (ms)
else
   Events = [];
end

% remove the events with any part beyond the end of the belt
if ~isempty(Events)
    events_to_remove = any(Events(:, 6:8)>183.6, 2);
    Events_cleaned = Events(~events_to_remove, :);
else
    Events_cleaned = [];
end

end