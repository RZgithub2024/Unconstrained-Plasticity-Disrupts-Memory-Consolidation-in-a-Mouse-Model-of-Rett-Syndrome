function [BTSPstats,PlateauThereshold] = BTSPStats(BinnedData)

%%
% BTSPstats:
%     1. Animal ID (e.g. 209)
%     2. Recording date
%     3. Cell Number
%     4. Lap
%     5. dFoF_peak_firing_laps_top_20 of a given cell
%     6. Peak Amplitude (dFoF)
%     7. Peak Amplitude >= top 20 percetile && >= 1
%     8-14. Cellstats column 5-11 for BTSP events
%     15. firing lap or not
%     16. 3/4/5 out of post-five lap firing
%     17. COM backward shift or not
%     18. BTSP events
%     19. Putative plateaus besides BTSP events
%     20-26. Cellstats column 5-11 for putative plateaus besides BTSP events
%     27. COM shift distance (+, 0 -)

for cell = 1:size(BinnedData.Cells_dFoF_denoised,1)
    if ismember(cell,BinnedData.PFStats.PFIDs)
       [BTSPstats(cell,:,:),PlateauThereshold(cell)] = Get_btspstats(BinnedData,cell);
    else
       BTSPstats(cell,:,:) = nan(numel([BinnedData.LapStructure.LapNumber]),30);
       PlateauThereshold(cell) = NaN;
    end
end

end


function [BTSPStats,PlateauThereshold] = Get_btspstats(BinnedData,cell)

% disp(cell);
PlateauThereshold = NaN;
BTSPStats = nan(numel([BinnedData.LapStructure.LapNumber]),30);
BTSPStats(:,1) = str2num(BinnedData.AnimalID(3:5));
BTSPStats(:,2) = BinnedData.LongitudinalDay;
BTSPStats(:,3) = cell;
for i = 1:numel([BinnedData.LapStructure.LapNumber])
    BTSPStats(i,4) = i; % Lap
end

dFoF = BinnedData.Cells_dFoF_binned_mean(:,:,cell); % binned denoised dFoF;
Events = BinnedData.Events(cell).Events;
Flat_firing_array = reshape((dFoF>0).',1,[]);
puPlateau_peak_dFoF_1 = [];
puPlateau_peak_dFoF_1_2 = [];
% PF_loc_cm = BinnedData.PForNot(cell,8);
% PF_loc_bin = round((PF_loc_cm + 1.8) / 3.6);

if (~isempty(Events))
   Events_Running = Events(Events(:,3)>0,:); % Filter for events that have a some part when the animal is running.

   %% Find Prospective PF location using peak of Avg DFoF
   Avg_dFoF = nanmean(dFoF,1);
   [~,pros_PF_binloc] = max(Avg_dFoF);
   % Get centered dFoF array for COM calculation; flatten, shift, reshape
   Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
   shift = 25 - pros_PF_binloc; % positive if <25; negative if >25;
   % disp(shift)
   % disp(PF_loc_bin)
   Centered_flat_array = circshift(Flat_array,shift);
   Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM
   % Flat_firing_array = reshape((Centered_dFoF>0).',1,[]);
   % when shift is postive, remove the activity from the last lap in the
   % first lap
   if shift > 0
      Centered_dFoF(1,1:shift) = NaN;
   end

   
   Firing_laps = find(~isnan(squeeze(BinnedData.Cellstats(cell,:,7))));
   dFoF_peak_firing_laps_top_20 = prctile(squeeze(BinnedData.Cellstats(cell,Firing_laps,5)),80);

   for n = 1:numel(Firing_laps)
       m = Firing_laps(n);
       if m <= (max([BinnedData.LapStructure.LapNumber])-5)
          BTSPStats(m,5) = dFoF_peak_firing_laps_top_20;
          BTSPStats(m,6) = BinnedData.Cellstats(cell,m,5);
          if BinnedData.Cellstats(cell,m,5) >= dFoF_peak_firing_laps_top_20 &&...
               BinnedData.Cellstats(cell,m,5) >= 1
             BTSPStats(m,7) = 1;
             BTSPStats(m,8:14) = BinnedData.Cellstats(cell,m,5:11);
             BTSP_lap_cmloc = BinnedData.Cellstats(cell,m,7);
             BTSP_lap_binloc = floor(BTSP_lap_cmloc/3.6) + 1;
             [Search_Table_puBTSP] = Get_SearchTable(BTSP_lap_binloc,BinnedData.LapStructure);
             PostFiveLaps = (m+1):(m+5);
             
             count = 0;
             PostFiveLaps_firing = [];
             for i = 1:5
                 ii = PostFiveLaps(i);
                 search_string_BTSP = Flat_firing_array(Search_Table_puBTSP(ii,6):Search_Table_puBTSP(ii,7));
                 if ~isempty(strfind(search_string_BTSP,[1 1 1]))
                    % Find events where the frame of the peak amplitude is within 45 cm of the midpoint of the search bin
                    event_idx = find(Events_Running(:,5)>(Search_Table_puBTSP(ii,8)-1) & Events_Running(:,5)<(Search_Table_puBTSP(ii,9)+1));
                    if (~isempty(event_idx)) % Can happen when there is firing inside the search but peak is outside
                       BTSPStats(ii,15) = 1;
                       count = count + 1;
                       PostFiveLaps_firing = [PostFiveLaps_firing,ii];
                       BTSPStats(ii,8:14) = BinnedData.Cellstats(cell,ii,5:11);
                    end
                 end
             end
             
             if count >= 3
                BTSPStats(m,16) = 1;
                warning('off');
                Mean_dFoF_in_bins_BTSP_lap = Centered_dFoF(m,:);
                [~,BTSP_lap_binloc_COM] = max(Mean_dFoF_in_bins_BTSP_lap,[],"omitnan");
                shift_1 = 25 - BTSP_lap_binloc_COM; % positive if <25; negative if >25;
                Centered_dFoF_BTSP_lap = circshift(Mean_dFoF_in_bins_BTSP_lap,shift_1);

                COM_BTSP_lap = Find_COM_new(Centered_dFoF_BTSP_lap)-(shift_1*3.6);

                dFoF_PostFiveLaps_firing = Centered_dFoF(PostFiveLaps_firing,:);
                dFoF_PostFiveLaps_firing_flatten = reshape(dFoF_PostFiveLaps_firing',1,[]);
                [~,PostFiveLaps_firing_binloc] = max(mean(dFoF_PostFiveLaps_firing,1,"omitnan"),[],"omitnan");
                shift_2 = 25 - PostFiveLaps_firing_binloc; % positive if <25; negative if >25;
                Centered_flat_array = circshift(dFoF_PostFiveLaps_firing_flatten,shift_2);
                Centered_dFoF_PostFiveLaps_firing = reshape(Centered_flat_array,size(dFoF_PostFiveLaps_firing,2),[])'; % use this for COM
                Centered_dFoF_mean_PostFiveLaps_firing = mean(Centered_dFoF_PostFiveLaps_firing,1,"omitnan");

                COM_PostFiveLaps_firing = Find_COM_new(Centered_dFoF_mean_PostFiveLaps_firing)-(shift_2*3.6);
                warning('on');
                
                % debug
                % disp(num2str(COM_BTSP_lap));
                % disp(num2str(COM_PostFiveLaps_firing));
                if isnan(COM_BTSP_lap)
                   disp(num2str(Centered_dFoF_BTSP_lap));
                   disp([num2str(cell), ',', num2str(m)]);
                   
                end
                if isnan(COM_PostFiveLaps_firing)
                   disp('COM_PostFiveLaps_firing');
                   disp(num2str(dFoF_PostFiveLaps_firing));
                   disp(num2str(Centered_dFoF_PostFiveLaps_firing));
                   disp(num2str(Centered_dFoF_mean_PostFiveLaps_firing));
                   disp([num2str(cell), ',', num2str(m)]);
                   disp(num2str(PostFiveLaps_firing));
                end


                BTSP_shift_cm = BeltDistShift(COM_BTSP_lap,COM_PostFiveLaps_firing);
                BTSPStats(m,27) = BTSP_shift_cm;
                if BTSP_shift_cm < 0
                   BTSPStats(m,17) = 1;
                else
                   BTSPStats(m,17) = 0;
                end
             else
                BTSPStats(m,16) = 0;
             end

             if nansum([BTSPStats(m,7),BTSPStats(m,16),BTSPStats(m,17)]) == 3
                BTSPStats(m,18) = 1;
                puPlateau_peak_dFoF_1 = [puPlateau_peak_dFoF_1;BTSPStats(m,6)];
                puPlateau_peak_dFoF_1_2 = [puPlateau_peak_dFoF_1_2;BTSPStats(m,6)];
             end
          end
       end
   end
   
   if ~isempty(puPlateau_peak_dFoF_1)
      puPlateau_thereshold = min(puPlateau_peak_dFoF_1);
      PlateauThereshold = puPlateau_thereshold;
      for nn = 1:numel(Firing_laps)
          mm = Firing_laps(nn);
          if BTSPStats(mm,18) ~= 1
             if BinnedData.Cellstats(cell,mm,5) >= puPlateau_thereshold
                BTSPStats(mm,19) = 1;
                BTSPStats(mm,20:26) = BinnedData.Cellstats(cell,mm,5:11);
                puPlateau_peak_dFoF_1_2 = [puPlateau_peak_dFoF_1_2;BinnedData.Cellstats(cell,mm,5)];
             end
          end     
      end
   end
end

end