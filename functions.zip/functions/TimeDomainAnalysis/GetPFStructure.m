function GetPFStructure(GLWC,n_ConsBins,rel,folderpath)

% perform place field analysis, save PFStructure as a .mat file
% save behavior plots
% n_ConsBins: the least number of cosecutive bins with significant signals
% rel: reliability in decimal

% get the variables from GLWC
Cells_F = GLWC.Cells_F;
LapStructure = GLWC.LapStructure;
WS = GLWC.WS;
Genotype = GLWC.Genotype;

% behavior plots
[Vel_by_lap,Mean_velocity] = Vel_plot(LapStructure,WS,folderpath);
Vel_heatmap(LapStructure,WS,folderpath);
AnticiLicks_Prob = Licks_scatter(LapStructure,WS,folderpath);

% get the session information
h5filename = WS.FileName;
MouseID = h5filename(1:5);
ImagingDay = str2double(h5filename(9));

% remove the first row of Cells_F (background signal) if necessary
% here it is not necessary
Cells_F_wobg = Cells_F;

% % calculate dFoF, 60-s window, mode
delete(gcp('nocreate'));
[Cells_F_smoothed,Cells_F0_mode,Cells_dFoF_mode] = GetdFoF_60s_mode(Cells_F_wobg);
delete(gcp('nocreate'));

% calculate denoised dFoF
delete(gcp('nocreate'));
[Cells_dFoF_denoised,signal_threshold] = Denoise(Cells_dFoF_mode);
delete(gcp('nocreate'));

% get spatially binned dFoF (mean)
[Cells_dFoF_binned_mean] = GetdFoF_SpatialBinned_mean(Cells_dFoF_denoised,LapStructure);

% get spatially binned dFoF (mean, noisy)
[Cells_dFoF_binned_mean_noisy] = GetdFoF_SpatialBinned_mean(Cells_dFoF_mode,LapStructure);

% get spatially binned dFoF (max)
[Cells_dFoF_binned_max,SpatialBins_max_over_threshold] = GetdFoF_SpatialBinned_max(Cells_dFoF_denoised,...
    signal_threshold,LapStructure);

% PF analysis below

% detect calcium events
[Events] = Find_Events(Cells_dFoF_denoised,WS);

% load data into PFStructure for further analysis
PFStructure.MouseID = MouseID;
PFStructure.Genotype = Genotype;
PFStructure.ImagingDay = ImagingDay;
PFStructure.LapStructure = LapStructure;
PFStructure.Cells_F_wobg = Cells_F_wobg;
PFStructure.Cells_F0_mode = Cells_F0_mode;
PFStructure.Cells_dFoF_mode = Cells_dFoF_mode;
PFStructure.Cells_dFoF_denoised = Cells_dFoF_denoised;
PFStructure.signal_threshold = signal_threshold;
PFStructure.Cells_dFoF_binned_mean = Cells_dFoF_binned_mean;
PFStructure.Cells_dFoF_binned_max = Cells_dFoF_binned_max;
PFStructure.Cells_dFoF_binned_mean_noisy = Cells_dFoF_binned_mean_noisy;
PFStructure.Events = Events;
PFStructure.Vel_by_lap = Vel_by_lap;
PFStructure.Mean_velocity = Mean_velocity;
PFStructure.AnticiLicks_Prob = AnticiLicks_Prob;
PFStructure.WS = WS;

% Analyze activity of each lap
[PFStructure] = CellStats(PFStructure,LapStructure,n_ConsBins);

% loop each cell and calculate SpatialInformation and SpatialInformation_ConfidenceInterval_95_upper

SpatialInformation_cells = [];
SpatialInformation_shuffled_cells = {};
SpatialInformation_ConfidenceInterval_95_upper_cells = [];
delete(gcp('nocreate'));

parfor ii = 1:size(Cells_dFoF_denoised,1)
       [SpatialInformation_cells(ii),SpatialInformation_shuffled_cells{ii},SpatialInformation_ConfidenceInterval_95_upper_cells(ii)]...
           = GrabSI90(LapStructure,Cells_dFoF_denoised(ii,:));
end

delete(gcp('nocreate'));

% compare the spatial information and the upper boundary of 95% confidence intervals
ShufflePositive_ornot = (SpatialInformation_cells > SpatialInformation_ConfidenceInterval_95_upper_cells);

PFStructure.SpatialInformation_cells = SpatialInformation_cells;
PFStructure.ShufflePositive_ornot = ShufflePositive_ornot;

% Place field analysis
[PFStructure] = PFAnalysis(PFStructure,rel,0);

% plot and save the sorted PF heatmap
PFs_sorted_heatmap(PFStructure,folderpath);

% plot and save the histogram for PF distribution
PFs_dist_histogram(PFStructure,folderpath);

% save PFStructure
PFS_filename = strrep(WS.FileName, '.h5', '.mat');
fullpath = fullfile(folderpath,PFS_filename);
save(fullpath,'PFStructure');
fprintf('%s PFStructure saved.\n', PFS_filename);

end