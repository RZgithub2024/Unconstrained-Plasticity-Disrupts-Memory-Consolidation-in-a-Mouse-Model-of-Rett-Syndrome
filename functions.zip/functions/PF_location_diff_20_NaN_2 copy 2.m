function PF_subsequent_days = PF_location_diff_20_NaN_2(PF_subsequent_days)

for j = 2:numel(PF_subsequent_days)
    shift = BeltDist(PF_subsequent_days(1),PF_subsequent_days(j));
    if shift <= 20
       PF_subsequent_days(j) = PF_subsequent_days(j);
    else
       PF_subsequent_days(j) = NaN;
    end
end

end