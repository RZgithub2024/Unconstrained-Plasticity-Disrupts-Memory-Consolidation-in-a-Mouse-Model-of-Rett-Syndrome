function PFs_dist_histogram(PFStructure,folderpath)

PForNot = PFStructure.PForNot;
PlaceField_location = PForNot(:,8);
PlaceField_location_valid = PlaceField_location(~isnan(PlaceField_location));
edges = linspace(0,180,11);

fig = figure('Visible', 'off');
histogram(PlaceField_location_valid,edges,FaceColor='#0072BD');
xlim([0 180]);
newxticks = [0,18,36,54,72,90,108,126,144,162,180];
newxticklabels = {'0','18','36','54','72','90','108','126','144','162','180'};
xticks(newxticks);
xticklabels(newxticklabels);
xlabel('Position (cm)');
ylabel('PC counts');
ax = gca;
ax.YTick = unique(round(ax.YTick));
WS = PFStructure.WS;
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);

filename = 'PFs_dist_histogram.png';
fullpath = fullfile(folderpath,filename);
saveas(fig, fullpath);

end