function Licks_scatter_F00(LapStructure,WS)

% scatter plot of licks
licks_scatter_x = [];
licks_scatter_y = [];
for k = 1:numel([LapStructure.LapNumber])
        EachCell_licks_each_lap = [LapStructure(k).LickingLocation];
        SpatialBin_edges_180_centimeter = 0:180;
        SpatialBin_edges_180_meter = SpatialBin_edges_180_centimeter / 100;
        SpatialBin_indices = discretize(EachCell_licks_each_lap,SpatialBin_edges_180_meter);
        for j = 1:180
            if numel(find(SpatialBin_indices == j)) > 0
               licks_scatter_x = [licks_scatter_x,(j-0.5)];
               licks_scatter_y = [licks_scatter_y,k];   
            end
        end
end

figure;
hold on;
scatter(licks_scatter_x,licks_scatter_y,20,"black","filled");
set(gca,'Ydir','reverse');
xlim([-0.4 180]);
LapNumber = numel([LapStructure.LapNumber]);
ylim([1 (LapNumber+0.4)]);
newyticks = [1,LapNumber];
newyticklabels = {'1',num2str(LapNumber)};
yticks(newyticks);
xticks(0:45:180);
xlabel('Position (cm)');
ylabel('Laps');
legend('Licks','Location','northeastoutside');
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);

saveas(gcf,'LicksByLap.png');

end