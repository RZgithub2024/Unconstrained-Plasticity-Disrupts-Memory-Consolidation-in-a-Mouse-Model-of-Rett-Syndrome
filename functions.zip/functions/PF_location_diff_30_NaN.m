function PF_subsequent_days = PF_location_diff_30_NaN(PF_subsequent_days)

if PF_subsequent_days(1) < 30
   PF_plus_30 = PF_subsequent_days(1)+30;
   PF_minus_30 = PF_subsequent_days(1)-30+180;
   for j = 2:numel(PF_subsequent_days)
       if PF_subsequent_days(j) <= PF_plus_30 || PF_subsequent_days(j) >= PF_minus_30
          PF_subsequent_days(j) = PF_subsequent_days(j);
       else
          PF_subsequent_days(j) = NaN;
       end
   end
end

if PF_subsequent_days(1) > 150
   PF_plus_30 = PF_subsequent_days(1)+30-180;
   PF_minus_30 = PF_subsequent_days(1)-30;
   for j = 2:numel(PF_subsequent_days)
       if PF_subsequent_days(j) <= PF_plus_30 || PF_subsequent_days(j) >= PF_minus_30
          PF_subsequent_days(j) = PF_subsequent_days(j);
       else
          PF_subsequent_days(j) = NaN;
       end
   end
end

if PF_subsequent_days(1) >= 30 && PF_subsequent_days(1) <= 150
   PF_plus_30 = PF_subsequent_days(1)+30;
   PF_minus_30 = PF_subsequent_days(1)-30;
   for j = 2:numel(PF_subsequent_days)
       if PF_subsequent_days(j) <= PF_plus_30 && PF_subsequent_days(j) >= PF_minus_30
          PF_subsequent_days(j) = PF_subsequent_days(j);
       else
          PF_subsequent_days(j) = NaN;
       end
   end    
end