function [decoded_pos,decoded_error] = GetOLE_error_time_3(FrameNumber_running,...
    Cell_ID,Cells_dFoF_noisy,w_cos,w_sin,training_mean,actual_pos_running)

% calculate decoding error using OLE method
% not require a time window

decoded_pos = [];
decoded_error = [];

time_points = FrameNumber_running;

dFoF_observed = Cells_dFoF_noisy(Cell_ID,time_points);
R_test = dFoF_observed';
R_test_c = R_test - training_mean;  % Center test data using training mean

% Decode cos(θ) and sin(θ) from test data
z_hat_cos = R_test_c * w_cos';  % M_test x 1
z_hat_sin = R_test_c * w_sin';  % M_test x 1

%% Step 7: Recover estimated angle from decoded sine and cosine
theta_hat = atan2(z_hat_sin, z_hat_cos);  % returns angle in radians (-π to π)

%% Step 8: Compute error between true and decoded positions
a_pos = actual_pos_running';
if length(a_pos) ~= length(theta_hat)
    error('actual pos and decoded pos not in the same length');
end

decoded_pos_cm = (theta_hat+pi) * 90 / pi;

theta_test = (a_pos / 180) * 2 * pi - pi; % convert cm (0–180) → radians (-π to π)
% Compute circular error: wraps difference to [-π, π]
theta_error = angle(exp(1i * (theta_hat - theta_test)));

% Mean absolute error in radians
abs_error = abs(theta_error);

% Convert radians → centimeters
abs_error_cm = abs_error * (180 / (2 * pi));

decoded_pos = [decoded_pos;decoded_pos_cm];
decoded_error = [decoded_error;abs_error_cm];


end