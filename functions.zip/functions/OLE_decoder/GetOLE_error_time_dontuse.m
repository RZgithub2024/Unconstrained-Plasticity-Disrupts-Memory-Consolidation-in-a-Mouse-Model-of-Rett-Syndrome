function [decoded_pos,decoded_error] = GetOLE_error_time(FrameNumber,FrameNumber_running,time_window_size,...
    Cell_ID,Cells_dFoF_noisy,w_cos,w_sin,training_mean,actual_pos)

% calculate decoding error using OLE method

n_window = ceil(length(FrameNumber)/time_window_size);
startIdx = [];
endIdx = [];
decoded_pos = [];
decoded_error = [];
for ii = 1:n_window
    t1 = (ii-1)*time_window_size + 1;
    t2 = min([ii*time_window_size,length(FrameNumber)]);
    startIdx(ii) = t1;
    endIdx(ii) = t2;
    time_points = FrameNumber(t1:t2);
    time_points_running = time_points(ismember(time_points,FrameNumber_running));
    if numel(time_points_running) >= 0.5 * time_window_size
        dFoF_observed = Cells_dFoF_noisy(Cell_ID,time_points_running);
        R_test = dFoF_observed';
        R_test_c = R_test - training_mean;  % Center test data using training mean

        % Decode cos(θ) and sin(θ) from test data
        z_hat_cos = R_test_c * w_cos';  % M_test x 1
        z_hat_sin = R_test_c * w_sin';  % M_test x 1

        %% Step 7: Recover estimated angle from decoded sine and cosine
        theta_hat = atan2(z_hat_sin, z_hat_cos);  % returns angle in radians (-π to π)

        %% Step 8: Compute error between true and decoded positions
        decode_pos_cm = (theta_hat+pi) * 90 / pi;
        pos = [];
        pos = repmat(decode_pos_cm,1,(t2-t1+1));

        a_pos = actual_pos(t1:t2);
        if length(a_pos) ~= length(pos)
            error('actual pos and decoded pos not the same length');
        end

        d_error = [];
        for d = 1:length(a_pos)
            d_error = [d_error,BeltDist(a_pos(d),pos(d))];
        end

    else
        pos = NaN(1,(t2-t1+1));
        d_error = [];
        d_error = NaN(1,(t2-t1+1));
    end
    decoded_pos = [decoded_pos,pos];
    decoded_error = [decoded_error;nanmean(d_error)];
end

end