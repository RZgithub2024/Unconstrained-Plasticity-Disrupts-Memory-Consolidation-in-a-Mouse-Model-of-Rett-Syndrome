function [w_cos,w_sin,training_mean] = GetOLE_train(Binned_dFoF_noisy,Cell_ID)

Binned_dFoF_noisy(isnan(Binned_dFoF_noisy)) = 0;
Binned_dFoF_noisy_cells = Binned_dFoF_noisy(:,:,Cell_ID);
train = permute(Binned_dFoF_noisy_cells, [2 1 3]);

sz = size(train);
train_flat = reshape(train, sz(1) * sz(2), sz(3));  % M x N (trials x neurons)  

%% --- Generate angular position labels for training data ---
train_pos = repmat(1.8:3.6:178.2, 1, size(train, 2)).';  % cm positions repeated for each lap
train_theta = (train_pos / 180) * 2 * pi - pi;           % convert cm (0–180) → radians (-π to π)

%% Step 1: Create target cosine and sine vectors
Z = [cos(train_theta), sin(train_theta)];  % M x 2 matrix of circular position components

%% Step 2: Center the neural responses (zero mean)
R = train_flat;        % Rename for clarity
training_mean = mean(R,1);
R_c = R - training_mean;     % Subtract mean response for each neuron (across trials)

%% Step 3: Compute neural covariance matrix
Sigma_r = cov(R_c);    % N x N covariance matrix of centered responses

%% Step 4: Compute cross-covariances between neural activity and cos/sin of position
Z_c = Z - mean(Z);     % Center target variables
Cov_cos = (Z_c(:,1)' * R_c) / (size(R,1) - 1);  % 1 x N: cov(cosθ, neural response)
Cov_sin = (Z_c(:,2)' * R_c) / (size(R,1) - 1);  % 1 x N: cov(sinθ, neural response)

%% Step 5: Calculate OLE weights using linear regression
w_cos = Cov_cos / Sigma_r;  % 1 x N weight vector to decode cos(θ)
w_sin = Cov_sin / Sigma_r;  % 1 x N weight vector to decode sin(θ)


end