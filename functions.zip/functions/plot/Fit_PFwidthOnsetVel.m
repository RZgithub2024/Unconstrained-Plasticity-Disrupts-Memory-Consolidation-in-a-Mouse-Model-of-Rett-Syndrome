function [] = Fit_PFwidthOnsetVel(s)

% x, onset velocity
% y, PF width in cm
x = s(:,1);
y = s(:,2);

figure;
hold on;
scatter(x, y, 'filled');
xlabel('Induction velocity (cm/s)');
ylabel('PF width (cm)');
title('PF width vs Induction velocity');

% Fit a linear model
linear_model = fitlm(x, y);
disp(linear_model);

slope = linear_model.Coefficients.Estimate(2)  % Coefficient of x
intercept = linear_model.Coefficients.Estimate(1)  % Intercept
p_value_slope = linear_model.Coefficients.pValue(2);
r_squared = linear_model.Rsquared.Ordinary;

y_fit = slope * x + intercept;

% Plot the regression line on the scatter plot
plot(x, y_fit, '-r', 'LineWidth', 2);  % Linear regression line

% Add the equation to the plot at a specified location
equation = sprintf('y = %.2fx + %.2f', slope, intercept);
text(35, 14, equation, 'FontSize', 14, 'Color', 'black', 'FontWeight', 'normal');
text(35, 8, ['R-squared: ',num2str(r_squared)], 'FontSize', 14, 'Color', 'black', 'FontWeight', 'normal');
text(35, 2, ['p-value: ',num2str(p_value_slope)], 'FontSize', 14, 'Color', 'black', 'FontWeight', 'normal');

set(gca, 'FontSize', 14);
hold off;

end