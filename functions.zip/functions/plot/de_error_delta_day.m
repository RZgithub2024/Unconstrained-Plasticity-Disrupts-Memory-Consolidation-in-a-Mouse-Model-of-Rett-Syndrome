function WT_delta_error = de_error_delta_day(delta_days,error_7day_WT_mean)

% get animal-wise decoder performance or correlation coefficient change of -6,-5,...,0,1,2,...,6 days

WT_delta_error = [];
for i = 1:size(error_7day_WT_mean,3)
    d_error = [];
    for k = 1:numel(delta_days)
        de = delta_days(k);
        de_error = [];
        for d = 1:size(error_7day_WT_mean,2)
            if (d+de) >= 1 && (d+de) <= 7 
                err = error_7day_WT_mean((d+de),d,i);
            else
                err = NaN;
            end
            de_error = [de_error;err];
        end
        d_error = [d_error,nanmean(de_error)];
    end
    WT_delta_error = [WT_delta_error;d_error];
end

end