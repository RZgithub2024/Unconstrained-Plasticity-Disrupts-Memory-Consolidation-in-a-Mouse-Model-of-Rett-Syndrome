function [] = ecdfPlotPFwidth(WT,RTT,zone)

% WT or RTT, cumulative distribution plot
for j = 1:7
    figure;
    hold on;
    h1 = cdfplot(WT{j});
    set(h1,'Color','blue','LineWidth',1);
    h2 = cdfplot(RTT{j});
    set(h2,'Color','red','LineWidth',1);
    legend([h1 h2],'WT','RTT','FontSize',14,'Location','southeast');
    xlim([0 90]);
    ylim([0 1]);
    xlabel('PF width (cm)');
    ylabel('Cumu.frac.PCs');
    if zone == 1
       title(['PF width, 45—135 cm, Day ',num2str(j)]);
    end
    if zone == 2
       title(['PF width, 0—45 cm, 135—180 cm, Day ',num2str(j)]);
    end
    set(gca, 'FontSize', 14);
    grid off;
    hold off;
end


end