function MeanSEMPlot(WT,RTT,d1,d2,t,yl)

WT_7_days_mean = mean(WT,1);
WT_7_days_SEM = std(WT)/...
        sqrt(size(WT,1));
RTT_7_days_mean = mean(RTT,1);
RTT_7_days_SEM = std(RTT)/...
        sqrt(size(RTT,1));

figure;
hold on;
x = d1:d2;
% WT
h1 = errorbar(x,WT_7_days_mean,WT_7_days_SEM,...
     'o-','LineWidth',1,'Color','blue','MarkerSize',4,'MarkerEdgeColor',...
     'blue','MarkerFaceColor','blue');
for m = 1:size(WT,1)
    plot(x,WT(m,:),...
    'o','MarkerSize',4,'MarkerEdgeColor','blue','MarkerFaceColor','blue');
end
% RTT
h2 = errorbar(x,RTT_7_days_mean,RTT_7_days_SEM,...
     'o-','LineWidth',1,'Color','red','MarkerSize',4,'MarkerEdgeColor',...
     'red','MarkerFaceColor','red');
for m = 1:size(RTT,1)
    plot(x,RTT(m,:),...
    'o','MarkerSize',4,'MarkerEdgeColor','red','MarkerFaceColor','red');
end

%xlim([0.8 7]);
%ylim([0 0.2]);
xlabel('Days');
ylabel(yl);
xticks(d1:d2);
title(t);
ax = gca;
ax.YLim(1) = 0;

%legend([h1 h2],'WT','RTT','FontSize',14);
set(gca, 'FontSize', 14);

hold off;

end