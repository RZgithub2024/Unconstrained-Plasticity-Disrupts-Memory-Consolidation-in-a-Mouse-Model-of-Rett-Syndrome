function cells_info_WT_log_sorted = PlotSponActivity(cells_info_WT_log_sorted,x0,Binned_Master_WT)

% Plot spontaneuous activity before PF onset based on given activity rate
% (AUC/s)
% find the cell whose AUC/s is closest to the given value
% the cell should have an onset lap, not NaN

for z = 1:numel(x0)
    cells_info_WT_log_sorted(:,(5+z)) = abs(cells_info_WT_log_sorted(:,5) - x0(z));
end

for z = 1:numel(x0)
    sort1 = sortrows(cells_info_WT_log_sorted,(5+z));
    for k = 1:size(sort1,1)
        if ~isnan(sort1(k,4))
            i = sort1(k,1);
            j = sort1(k,2);
            ROI = sort1(k,3);
            bd = Binned_Master_WT{i,j};
            LapStructure = bd.LapStructure;
            laps = 1:(sort1(k,4)-1);
            frames = [];
            for kk = 1:(sort1(k,4)-1)
                frames = [frames,LapStructure(kk).FrameNumber];
            end
            dFoF = bd.Cells_dFoF_denoised(ROI,frames);
            figure;
            rgb_blue = [0, 0.4470, 0.7410];
            plot(dFoF,'-','Color',rgb_blue,'LineWidth',1);
            ylim([-0.1 1.2]);
            xlim([0 3200]);
            daspect([500 1 1]);
            set(gca, 'Box', 'off');
            break
        end
    end

end
end