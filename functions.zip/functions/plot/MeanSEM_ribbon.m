function MeanSEM_ribbon(WT_mean,WT_SEM,RTT_mean,RTT_SEM,color1,color2,transparency)

% make a ribbon plot
% shaded area is the error bar
% shaded area transparency can be adjusted

bins = 1:1:size(WT_mean,2);

y1 = WT_mean + WT_SEM;
y2 = WT_mean - WT_SEM;

y3 = RTT_mean + RTT_SEM;
y4 = RTT_mean - RTT_SEM;

plot(WT_mean,'LineWidth',3,'Color',color1);
plot(RTT_mean,'LineWidth',3,'Color',color2);

p1 = patch([bins fliplr(bins)],[y1 fliplr(y2)],color1);
p2 = patch([bins fliplr(bins)],[y3 fliplr(y4)],color2);

p1.FaceAlpha = transparency;
p1.EdgeAlpha = 0;

p2.FaceAlpha = transparency;
p2.EdgeAlpha = 0;
end