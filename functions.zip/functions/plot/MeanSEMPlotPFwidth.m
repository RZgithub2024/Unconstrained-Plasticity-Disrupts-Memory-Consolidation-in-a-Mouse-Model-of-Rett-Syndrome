function [] = MeanSEMPlotPFwidth(WT,RTT,zone)

WT_7_days_mean = mean(WT,1);
WT_7_days_SEM = std(WT)/...
        sqrt(size(WT,1));
RTT_7_days_mean = mean(RTT,1);
RTT_7_days_SEM = std(RTT)/...
        sqrt(size(RTT,1));

figure;
hold on;
x = 1:size(WT,2);
% WT
h1 = errorbar(x,WT_7_days_mean,WT_7_days_SEM,...
     'o-','LineWidth',1,'Color','blue','MarkerSize',4,'MarkerEdgeColor',...
     'blue','MarkerFaceColor','blue');
for m = 1:size(WT,1)
    plot(x,WT(m,:),...
    'o','MarkerSize',4,'MarkerEdgeColor','blue','MarkerFaceColor','blue');
end
% RTT
h2 = errorbar(x,RTT_7_days_mean,RTT_7_days_SEM,...
     'o-','LineWidth',1,'Color','red','MarkerSize',4,'MarkerEdgeColor',...
     'red','MarkerFaceColor','red');
for m = 1:size(RTT,1)
    plot(x,RTT(m,:),...
    'o','MarkerSize',4,'MarkerEdgeColor','red','MarkerFaceColor','red');
end
hold off;
xlim([0.8 7]);
ylim([0 50]);
xlabel('Day');
ylabel('PF width (cm)');
if zone == 1
   title('Mean PF width, 45—135 cm');
end
if zone == 2
   title('Mean PF width, 0—45 cm, 135—180 cm');
end
legend([h1 h2],'WT','RTT','FontSize',14);
set(gca, 'FontSize', 14);

end