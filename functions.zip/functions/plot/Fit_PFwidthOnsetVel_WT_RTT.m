function [] = Fit_PFwidthOnsetVel_WT_RTT(s1,s2,saving)

% x, onset velocity
% y, PF width in cm
x1 = s1(:,1);
y1 = s1(:,2);
x2 = s2(:,1);
y2 = s2(:,2);

wt = size(s1)
rtt = size(s2)

rgb_blue = [0, 0.4470, 0.7410];
rgb_orange = [0.8500, 0.3250, 0.0980];

figure;
hold on;
scatter(x1, y1, 8, rgb_blue, 'filled','MarkerFaceAlpha', 0.3, 'MarkerEdgeAlpha', 0.3);
scatter(x2, y2, 8, rgb_orange, 'filled','MarkerFaceAlpha', 0.3, 'MarkerEdgeAlpha', 0.3);
xlabel('Induction velocity (cm/s)');
ylabel('PF width (cm)');
%title('PF width vs Induction velocity');

% Fit a linear model
% WT
x = linspace(0,60,101);
linear_model_1 = fitlm(x1, y1);
disp(linear_model_1);

slope_1 = linear_model_1.Coefficients.Estimate(2)  % Coefficient of x
intercept_1 = linear_model_1.Coefficients.Estimate(1)  % Intercept
p_value_slope_1 = linear_model_1.Coefficients.pValue(2);
r_squared_1 = linear_model_1.Rsquared.Ordinary;

y_fit_1 = slope_1 * x + intercept_1;

% RTT
linear_model_2 = fitlm(x2, y2);
disp(linear_model_2);

slope_2 = linear_model_2.Coefficients.Estimate(2)  % Coefficient of x
intercept_2 = linear_model_2.Coefficients.Estimate(1)  % Intercept
p_value_slope_2 = linear_model_2.Coefficients.pValue(2);
r_squared_2 = linear_model_2.Rsquared.Ordinary;

y_fit_2 = slope_2 * x + intercept_2;

% Plot the regression line on the scatter plot
plot(x, y_fit_1, '-','Color', rgb_blue, 'LineWidth', 3);  % Linear regression line
plot(x, y_fit_2, '-', 'Color', rgb_orange, 'LineWidth', 3);  % Linear regression line

equation_1 = sprintf('y = %.2fx + %.2f', slope_1, intercept_1);
WT_model = ['WT, ',equation_1,', R-squared: ',num2str(r_squared_1),', p-value: ',num2str(p_value_slope_1)];
disp(WT_model);

equation_2 = sprintf('y = %.2fx + %.2f', slope_2, intercept_2);
RTT_model = ['RTT, ',equation_2,', R-squared: ',num2str(r_squared_2),', p-value: ',num2str(p_value_slope_2)];
disp(RTT_model);

xlim([0-0.4 50+0.4]);
ylim([0 100]);
xticks(0:10:50);
set(gca, 'FontSize', 30);
set(gcf,'Position',[500 500 500 500]);
set(gca, 'TickDir', 'out');
set(gca, 'LineWidth',2);
set(gca, 'Box', 'off');
hold off;

if saving == 1
    print(gcf, 'fig2E.pdf','-dpdf','-vector','-bestfit');
end



end