function custom_colormap = Colormap_bwr()

% ==== Custom blue-white-red with wider white center ====
n = 256; % Number of total colors
white_ratio = 0.1; % Fraction of colormap near center (0) that's white
fade_ratio = (1 - white_ratio) / 2;
% Number of steps for each transition
n_blue = round(fade_ratio * n);
n_white = round(white_ratio * n);
n_red = n - n_blue - n_white;
% Blue to white (0 to 1 fade in RGB)
blue = [linspace(0,1,n_blue)', linspace(0,1,n_blue)', ones(n_blue,1)];
% White center
white = ones(n_white, 3);
% White to red
red = [ones(n_red,1), linspace(1,0,n_red)', linspace(1,0,n_red)'];
% Combine full colormap
custom_colormap = [blue; white; red];


end