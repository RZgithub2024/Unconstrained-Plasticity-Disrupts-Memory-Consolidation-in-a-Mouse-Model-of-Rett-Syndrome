function [] = Fit_PFwidthOnsetVel_WT(s1)

% x, onset velocity
% y, PF width in cm
x1 = s1(:,1);
y1 = s1(:,2);

figure;
hold on;
scatter(x1, y1, 8, 'b', 'filled','MarkerFaceAlpha', 0.2, 'MarkerEdgeAlpha', 0.2);
xlabel('Induction velocity (cm/s)');
ylabel('PF width (cm)');
title('PF width vs Induction velocity');

% Fit a linear model
% WT
x = linspace(0,60,101);
linear_model_1 = fitlm(x1, y1);
disp(linear_model_1);

slope_1 = linear_model_1.Coefficients.Estimate(2)  % Coefficient of x
intercept_1 = linear_model_1.Coefficients.Estimate(1)  % Intercept
p_value_slope_1 = linear_model_1.Coefficients.pValue(2);
r_squared_1 = linear_model_1.Rsquared.Ordinary;

y_fit_1 = slope_1 * x + intercept_1;


% Plot the regression line on the scatter plot
plot(x, y_fit_1, '-b', 'LineWidth', 3);  % Linear regression line


% Add the equation to the plot at a specified location
equation_1 = sprintf('y = %.2fx + %.2f', slope_1, intercept_1);
WT_model = ['WT, ',equation_1,', R-squared: ',num2str(r_squared_1),', p-value: ',num2str(p_value_slope_1)];
disp(WT_model);


ylim([0 105]);
set(gca, 'FontSize', 30);
set(gcf,'Position',[500 500 500 500]);
set(gca, 'TickDir', 'out');
set(gca, 'LineWidth',2);
set(gca, 'Box', 'off');
hold off;

end