function [Cells_dFoF_binned_mean] = GetdFoF_SpatialBinned_mean_old(Cells_dFoF_denoised,LapStructure)

% divide 180 cm into 50 bins and calculate the mean dFoF of each bin
% create a 3D array containing binned dFoF by lap for each cell

Cells_dFoF_binned_mean = [];

for i = 1:size(Cells_dFoF_denoised,1)
    EachCell_dFoF_binned_mean_by_lap = [];
    for k = 1:numel([LapStructure.LapNumber])
        % Distance_frame_running = [];
        EachCell_dFoF_binned_mean_each_lap = Cells_dFoF_denoised(i,[LapStructure(k).FrameNumber_running]);
        SpatialBin_edges_centimeter = 0:3.6:180;
        SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
        % Distance_frame_running = LapStructure(k).Distance_frame_running;
        % first_index = find(Distance_frame_running < 0.1, 1);
        % if ~isempty(first_index)
        %     if first_index ~= 1
        %         Distance_frame_running(1:(first_index-1)) = Distance_frame_running(first_index);
        %     end
        % end
        SpatialBin_indices = discretize(LapStructure(k).Distance_frame_running,SpatialBin_edges_meter);
        EachCell_dFoF_by_bin_mean = [];
        for j = 1:50
            Indices_in_bins = find(SpatialBin_indices == j);
            EachCell_dFoF_by_bin_mean = [EachCell_dFoF_by_bin_mean,mean(EachCell_dFoF_binned_mean_each_lap(Indices_in_bins),"omitnan")];
        end
        EachCell_dFoF_binned_mean_by_lap = [EachCell_dFoF_binned_mean_by_lap;EachCell_dFoF_by_bin_mean];
    end
    Cells_dFoF_binned_mean = cat(3,Cells_dFoF_binned_mean,EachCell_dFoF_binned_mean_by_lap);
end
end