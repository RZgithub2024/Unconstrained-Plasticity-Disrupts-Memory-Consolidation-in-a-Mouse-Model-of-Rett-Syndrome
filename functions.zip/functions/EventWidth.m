function [d] = EventWidth(x1,x2)

% calculate the location difference between the start and end frame of calcium events
% x1, event start location; x2, event end location, in cm
% d >= 0

if x2 >= x1
   d = x2 - x1;
else
   d = 180 - x1 + x2 - 0;
end

end