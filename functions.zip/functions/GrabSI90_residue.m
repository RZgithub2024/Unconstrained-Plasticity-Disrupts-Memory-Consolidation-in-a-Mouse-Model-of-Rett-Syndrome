function [SpatialInformation,SpatialInformation_ConfidenceInterval_95_upper,SpatialInformation_bins] =...
    GrabSI90_residue(BinnedData,ROI_ID,start_lap,end_lap)

LapStructure_full = BinnedData.LapStructure;
LapStructure = LapStructure_full(start_lap:end_lap);

Cells_dFoF_denoised = BinnedData.Cells_dFoF_denoised(ROI_ID,:);

SpatialBin_edges_centimeter = 0:3.6:180;
SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;

FrameIndices_entire_session = [LapStructure.FrameNumber_running];
    
% divide frames into 6 chunks
chunk_size = numel(FrameIndices_entire_session)/6;
chunk_start_indices = [];
chunk_end_indices = [];
for i = 1:6
    chunk_start_indices = [chunk_start_indices,round((i - 1) * chunk_size) + 1];
    chunk_end_indices = [chunk_end_indices,round(i * chunk_size)];
end

% Calculate probability of occupancy in spatial bins(oi)
Bin_ID_each_frame_entire_session = [];
for k = min([LapStructure.LapNumber]):max([LapStructure.LapNumber])
    Bin_ID_each_frame = discretize(LapStructure(k).Distance_frame_running,SpatialBin_edges_meter);
    Bin_ID_each_frame_entire_session = [Bin_ID_each_frame_entire_session,Bin_ID_each_frame];
end

Frame_number_in_bins_entire_session = [];
for m = 1:50
    Frame_number_each_bin = numel(find(Bin_ID_each_frame_entire_session == m));
    Frame_number_in_bins_entire_session = [Frame_number_in_bins_entire_session,Frame_number_each_bin];
end

for n = 1:50
    oi_probability_of_occupancy(n) = Frame_number_in_bins_entire_session(n)/sum(Frame_number_in_bins_entire_session,2);
end
    
% Calculate ai, a_bar, and spatial information
dFoF_each_cell_running = Cells_dFoF_denoised(FrameIndices_entire_session);

Mean_dFoF_in_bins_entire_session = [];
for m = 1:50
    Frame_each_bin_indices_SI = find(Bin_ID_each_frame_entire_session == m);
    Mean_dFoF_each_bin = mean(dFoF_each_cell_running(Frame_each_bin_indices_SI),"omitnan");
    Mean_dFoF_in_bins_entire_session = [Mean_dFoF_in_bins_entire_session,Mean_dFoF_each_bin];
end

Overall_Mean_dFoF_in_bins_entire_session = mean(Mean_dFoF_in_bins_entire_session,"omitnan");

SpatialInformation_bins = [];
for m = 1:50
    if Mean_dFoF_in_bins_entire_session(m) > 0 && Overall_Mean_dFoF_in_bins_entire_session > 0
       SpatialInformation_each_bin = oi_probability_of_occupancy(m) * Mean_dFoF_in_bins_entire_session(m) *...
           log2(Mean_dFoF_in_bins_entire_session(m) / Overall_Mean_dFoF_in_bins_entire_session);
    else
       SpatialInformation_each_bin = 0;
    end
    SpatialInformation_bins = [SpatialInformation_bins,SpatialInformation_each_bin];
end   

SpatialInformation = [];
SpatialInformation = sum(SpatialInformation_bins,2,"omitnan");

% 500 shuffles and 6 permutations
dFoF_entire_session_circularly_shifted = dFoF_each_cell_running;
SpatialInformation_shuffled = [];
for i = 1:500
    if numel(FrameIndices_entire_session) > 1000
       imin = 500;
       imax = numel(FrameIndices_entire_session)-500;
    else
       imin = 500;
       imax = 1000;
    end
    dFoF_entire_session_circularly_shifted = circshift(dFoF_entire_session_circularly_shifted,randi([imin,imax]),2);
    dFoF_entire_session_circularly_shifted_6_chunks = cell(1,6);
    for m = 1:6
        dFoF_entire_session_circularly_shifted_6_chunks{m} = ...
            dFoF_entire_session_circularly_shifted(chunk_start_indices(m):chunk_end_indices(m));
    end
    dFoF_entire_session_circularly_shifted_permutation_indices = randperm(6);
    dFoF_entire_session_circularly_shifted_6_chunks_permuted = [];
    for j = 1:6
        dFoF_entire_session_circularly_shifted_6_chunks_permuted = [dFoF_entire_session_circularly_shifted_6_chunks_permuted,...
            dFoF_entire_session_circularly_shifted_6_chunks{dFoF_entire_session_circularly_shifted_permutation_indices(j)}];
    end

    Mean_dFoF_in_bins_entire_session_shuffle = [];
    for m = 1:50
        Frame_each_bin_indices_shuffle = find(Bin_ID_each_frame_entire_session == m);
        Mean_dFoF_each_bin_shuffle = mean(dFoF_entire_session_circularly_shifted_6_chunks_permuted(Frame_each_bin_indices_shuffle),"omitnan");
        Mean_dFoF_in_bins_entire_session_shuffle = [Mean_dFoF_in_bins_entire_session_shuffle,Mean_dFoF_each_bin_shuffle];
    end

    SpatialInformation_bins_each_shuffle = [];
    for m = 1:50
        if Mean_dFoF_in_bins_entire_session_shuffle(m) > 0 && Overall_Mean_dFoF_in_bins_entire_session > 0
           SpatialInformation_each_bin_each_shuffle = oi_probability_of_occupancy(m) * Mean_dFoF_in_bins_entire_session_shuffle(m) *...
               log2(Mean_dFoF_in_bins_entire_session_shuffle(m) / Overall_Mean_dFoF_in_bins_entire_session);
        else
           SpatialInformation_each_bin_each_shuffle = 0;
        end
        SpatialInformation_bins_each_shuffle = [SpatialInformation_bins_each_shuffle,SpatialInformation_each_bin_each_shuffle];
    end

    SpatialInformation_each_shuffle = sum(SpatialInformation_bins_each_shuffle,2,"omitnan");
    SpatialInformation_shuffled = [SpatialInformation_shuffled;SpatialInformation_each_shuffle];
end

% 95 percent confidence interval of the shuffled information for each cell
pd_shuffles = fitdist(SpatialInformation_shuffled,'Normal');
ci = paramci(pd_shuffles);
SpatialInformation_ConfidenceInterval_95_upper = ci(2,1);

end