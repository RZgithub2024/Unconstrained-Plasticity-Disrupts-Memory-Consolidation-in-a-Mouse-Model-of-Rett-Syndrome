function [loc_rad] = loc2rad(loc)

% map physical locations on the belt to radian
% 0 cm = 0, 180 cm = 2*pi

loc_rad = loc / 180 * 2 * pi;

end