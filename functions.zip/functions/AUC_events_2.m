function AUC_sum = AUC_events_2(AUC_cumu,events)

% input: cumulative AUC of a given cell, events
% calculate AUC sum of specified events from the start to the end of the
% event
% at start and end, signal>=thereshold

if ~isempty(events)
    area = [];
    for i = 1:size(events,1)
        
        t1 = events(i,1)+1;
        t2 = events(i,2);
        
        AUC_event = AUC_cumu(t2) - AUC_cumu(t1);
        area = [area;AUC_event];
    end
    AUC_sum = sum(area);

elseif isempty(events)
    AUC_sum = 0;
end

end