function Display_2consecutivecells(Binned_Master, PFloc, nSamples)
% Display_2consecutivecells
%
% Randomly selects nSamples cells from the big-small-shift table and displays
% their activity on two consecutive days using vertical subplots.
% change >45 or <30 in the helper function to sort what shifts you are
% looking for.
%
% INPUTS:
% Binned_Master : cell array containing binned dF/F activity maps for each
% animal and day.
% PFloc : matrix containing animal ID, cell ID, and place-field
% locations across days.
% nSamples : number of random cells to visualize.
%
% Compute table of cells showing large (or small) place-field shifts
[bigsmallshift_table] = find_big_or_small_shifts(PFloc);
% Randomly select nSamples rows (cells) from the shift table
random_rows = randi([1 size(bigsmallshift_table,1)], 1, nSamples);
% Loop through each randomly selected sample
for i = 1:nSamples
% Extract identifiers: animal index, cell ID, and first day of the two-day pair
animal = bigsmallshift_table(random_rows(i),1);
cellID = bigsmallshift_table(random_rows(i),2);
firstDay = bigsmallshift_table(random_rows(i),3);
% Create a new figure for this cell
figure('Color','w');
% Add a descriptive title summarizing animal, cell, and days
sgtitle(sprintf('Animal %d | Cell %d | Days %d → %d', ...
animal, cellID, firstDay, firstDay+1), ...
'FontSize', 14, 'FontWeight', 'bold');
% ---------------- Day N plot ----------------
subplot(2,1,1);
imshow(Binned_Master{animal, firstDay}.Cells_dFoF_binned_mean(:,:,cellID), ...
'InitialMagnification','fit'); % Show activity map
colormap(gca, jet); % Apply jet colormap
colorbar; % Add colorbar
title(sprintf('Day %d', firstDay)); % Label the day
% ---------------- Day N+1 plot ----------------
subplot(2,1,2);
imshow(Binned_Master{animal, firstDay+1}.Cells_dFoF_binned_mean(:,:,cellID), ...
'InitialMagnification','fit'); % Show activity map on next day
colormap(gca, jet); % Apply jet colormap
colorbar; % Add colorbar
title(sprintf('Day %d', firstDay+1)); % Label the next day
end
end
function [shift_table] = find_big_or_small_shifts(PFloc)
% find_big_or_small_shifts
%
% Identifies cells that show small (or large) shifts between consecutive days.
%
% INPUT:
% PFloc : matrix containing animal ID, cell ID, and place-field locations
% across multiple days.
%
% OUTPUT:
% shift_table : rows contain [animal_index, cell_ID, firstDay]
% for each detected shift.
% Extract list of unique animals
animals = unique(PFloc(:,1));
% Initialize output table
shift_table = [];
% Loop through all rows in PFloc (each row = one cell)
for i = 1:size(PFloc,1)
% Loop through days 1–6 (columns 3–8 in PFloc correspond to day1–day6)
for j = 3:8
% Compute circular distance between place-field locations on days j and j+1
% If the distance is < 30, classify as a detected shift
if abs(BeltDist(PFloc(i,j), PFloc(i,j+1))) > 45
% Add entry: [animal_index, cell_ID, firstDay]
shift_table(end+1,1:3) = ...
[find(animals == PFloc(i,1)), PFloc(i,2), j-2];
end
end
end
end