function [Cells_dFoF_binned_max,SpatialBins_max_over_threshold] = GetdFoF_SpatialBinned_max(Cells_dFoF_denoised,...
    signal_threshold,LapStructure)

% divide 180 cm into 50 bins and calculate the maximal dFoF of each bin
% create a 3D array containing binned dFoF by lap for each cell
% if max dFoF of a given bin is higher than the signal threshold of that
% cell, return to 1; otherwise, return to 0

Cells_dFoF_binned_max = [];
SpatialBins_max_over_threshold = [];

for i = 1:size(Cells_dFoF_denoised,1)
    EachCell_dFoF_binned_max_by_lap = [];
    SpatialBins_max_over_threshold_by_lap = [];
    for k = 1:numel([LapStructure.LapNumber])
        Distance_frame_running = [];
        EachCell_dFoF_binned_max_each_lap = Cells_dFoF_denoised(i,LapStructure(k).FrameNumber_running);
        SpatialBin_edges_centimeter = 0:3.6:180;
        SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
        Distance_frame_running = LapStructure(k).Distance_frame_running;
        first_index = find(Distance_frame_running < 0.1, 1);
        if ~isempty(first_index)
            if first_index ~= 1
                Distance_frame_running(1:(first_index-1)) = Distance_frame_running(first_index);
            end
        end
        SpatialBin_indices = discretize(Distance_frame_running,SpatialBin_edges_meter);
        EachCell_dFoF_by_bin_max = [];
        SpatialBins_max_over_threshold_by_bin = [];
        for j = 1:50
            Indices_in_bins = find(SpatialBin_indices == j);
            dFoF_max = max(EachCell_dFoF_binned_max_each_lap(Indices_in_bins),[],'omitnan');
            if isempty(dFoF_max)
               EachCell_dFoF_by_bin_max = [EachCell_dFoF_by_bin_max,NaN];
               SpatialBins_max_over_threshold_by_bin = [SpatialBins_max_over_threshold_by_bin,NaN];
            else
               EachCell_dFoF_by_bin_max = [EachCell_dFoF_by_bin_max,dFoF_max];
               if dFoF_max >= signal_threshold(i)
                  SpatialBins_max_over_threshold_by_bin = [SpatialBins_max_over_threshold_by_bin,1];
               else
                  SpatialBins_max_over_threshold_by_bin = [SpatialBins_max_over_threshold_by_bin,0];
               end
            end
         end
         EachCell_dFoF_binned_max_by_lap = [EachCell_dFoF_binned_max_by_lap;EachCell_dFoF_by_bin_max];
         SpatialBins_max_over_threshold_by_lap = [SpatialBins_max_over_threshold_by_lap;SpatialBins_max_over_threshold_by_bin];
     end
     Cells_dFoF_binned_max = cat(3,Cells_dFoF_binned_max,EachCell_dFoF_binned_max_by_lap);
     SpatialBins_max_over_threshold = cat(3,SpatialBins_max_over_threshold,SpatialBins_max_over_threshold_by_lap);
end
end