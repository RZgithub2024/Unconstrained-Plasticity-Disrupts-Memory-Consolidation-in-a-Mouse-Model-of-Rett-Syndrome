function loc_CM = CircularMean(locs)

% input: locations in linear scale (0-180 cm)
% output: circular mean

% map the input to radian: -pi - pi
theta = (locs / 180) * 2 * pi - pi; % convert cm (0–180) → radians (-π to π)

% calculate the circular mean
x = cos(theta);
y = sin(theta);

mean_x = mean(x);
mean_y = mean(y);

circular_mean = atan2(mean_y, mean_x);

loc_CM = (circular_mean+pi) * 90 / pi;

end