function plotPF_ndays(i,ROI,n,PF_loc,MouseID,Binned_Master,gt,outputFolder)

% plot a cell's activity across n days
% save in .png

cell_dFoF_7days = [];
laps_7days = [];
for j = 1:7
    BinnedData = Binned_Master{i,j};
    cell_dFoF = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,ROI));
    cell_dFoF_7days = [cell_dFoF_7days;cell_dFoF];
    laps_7days = [laps_7days,numel([BinnedData.LapStructure.LapNumber])];
end
fig = figure('Visible', 'off');
ytick_days = cumsum(laps_7days);
imagesc(cell_dFoF_7days);
colormap(jet);
clim([0 2]);
xlim([0.5 50.5]);
newxticks = [0.5,25,50.5];
newxticklabels = {'0','90','180'};
xticks(newxticks);
xticklabels(newxticklabels);
newyticks = [1,ytick_days];
newyticklabels = {'1','2','3','4','5','6','7'};
yticks(newyticks);
yticklabels(newyticklabels);
set(gca, 'TickDir', 'out');
set(gca, 'LineWidth',1);
set(gca, 'Box', 'off');
xlabel('Position (cm)');
ylabel('Day');
colorbar; clb = colorbar(); ylabel(clb, "∆F/F"); clb.FontSize = 30; clb.Label.FontSize = 30; clb.LineWidth = 0.5;
set(gcf,'Position',[500 500 1000 2000]);
set(gca,'FontSize', 30);

PF_str = sprintf('%g, ', PF_loc);
PF_str = PF_str(1:end-2); 
newtitle = {['RZ0',num2str(MouseID(i)),', ROI ',num2str(ROI),', ',gt],PF_str};
title(newtitle);

% PF_str = strjoin(string(PF_loc), ', ');
% ax = gca;
% xpos = mean(xlim);
% ypos = ax.YLim(1) - 2;
% text(xpos, ypos, PF_str, 'HorizontalAlignment', 'center', 'FontSize', 30);

filenameString = sprintf('Plot_%04d',n);
fullFileName = fullfile(outputFolder, [filenameString, '.png']);
exportgraphics(fig, fullFileName, 'Resolution', 300);
close(fig);

end