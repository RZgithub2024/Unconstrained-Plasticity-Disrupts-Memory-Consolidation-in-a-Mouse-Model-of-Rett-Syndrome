function [Vel,Dist,Licks,Reward,SIFrameClock,RewardTarget,DigitalScans,filename] = ReadWaveSurfer(shortname)

%% load file and extract analog signals
% find the full file name using shortname 
shortnameh5 = strcat(shortname,'*.h5');
filename = dir(shortnameh5).name;
s = ws.loadDataFile(filename);
% extract analog signals
analogScans = s.sweep_0001.analogScans;
% velocity
Vel = analogScans(:,1);
% distance
Dist = analogScans(:,2);
% licks
Licks = analogScans(:,3);
% reward
Reward = analogScans(:,4);
% scanning frames
SIFrameClock = analogScans(:,6);
% reward conditions
RewardTarget = analogScans(:,7);

%% Extract FrameTimes and variables in terms of FrameTimes

%% Extract digital signals
DigitalScans = double(s.sweep_0001.digitalScans);

end