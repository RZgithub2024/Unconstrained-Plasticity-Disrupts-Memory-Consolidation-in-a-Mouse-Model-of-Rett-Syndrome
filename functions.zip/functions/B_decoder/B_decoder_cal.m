function decoded_pos = B_decoder_cal(FrameNumber,FrameNumber_running,time_window_size,...
    Cell_ID,Cells_ca_binary,TuningCurve_ca_bi_cells,SpatialBin_centers_cm)

% Bayesian decoder using binary calcium signal
% significant transients: 1, otherwise: 0
session_start = FrameNumber(1);
session_end = FrameNumber(end);
n_window = ceil(length(FrameNumber)/time_window_size);
tau = time_window_size/30;
startIdx = [];
endIdx = [];
decoded_pos = [];
for ii = 1:n_window
    t1 = (ii-1)*time_window_size + session_start;
    t2 = min([(ii*time_window_size+session_start-1),session_end]);
    startIdx(ii) = t1;
    endIdx(ii) = t2;
    time_points = t1:t2;
    time_points_running = time_points(ismember(time_points,FrameNumber_running));
    if numel(time_points_running) >= 0.5 * time_window_size
        ni = [];
        n = 0;
        for p = 1:numel(Cell_ID)
            n = n+1;
            ni(n,1) = sum(Cells_ca_binary(Cell_ID(p),time_points_running));
        end

        TuningCurve_ca_bi_i = TuningCurve_ca_bi_cells(Cell_ID,:);
        term0 = TuningCurve_ca_bi_i.^ni;
        term1 = prod(term0, 1);
        term2 = exp(-tau * sum(TuningCurve_ca_bi_i, 1));
        post_unnorm = term1 .* term2;
        [~, argmax_bin] = max(post_unnorm);
        pos = [];
        pos = repmat(SpatialBin_centers_cm(argmax_bin),1,(t2-t1+1));
    else
        pos = NaN(1,(t2-t1+1));
    end
    decoded_pos = [decoded_pos,pos];
end