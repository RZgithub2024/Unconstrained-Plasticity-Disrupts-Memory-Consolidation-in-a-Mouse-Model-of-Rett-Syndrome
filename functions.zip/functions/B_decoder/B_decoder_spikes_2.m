function [decoded_pos,decoded_error] = B_decoder_spikes_2(FrameNumber,FrameNumber_running,time_window_size,...
    Cell_ID,Cells_deconv_spikes,TuningCurve_FR_cells,SpatialBin_centers_cm,actual_pos)

% Bayesian decoder using deconvoluted spike data
n_window = ceil(length(FrameNumber)/time_window_size);
tau = time_window_size/30;
startIdx = [];
endIdx = [];
decoded_pos = [];
decoded_error = [];
for ii = 1:n_window
    t1 = (ii-1)*time_window_size + 1;
    t2 = min([ii*time_window_size,length(FrameNumber)]);
    startIdx(ii) = t1;
    endIdx(ii) = t2;
    time_points = FrameNumber(t1:t2);
    time_points_running = time_points(ismember(time_points,FrameNumber_running));
    if numel(time_points_running) >= 0.5 * time_window_size
        ni = [];
        spikes_observed = Cells_deconv_spikes(Cell_ID,time_points_running);
        ni = sum(spikes_observed,2);

        TuningCurve_FR_i = TuningCurve_FR_cells(Cell_ID,:);
        term0 = TuningCurve_FR_i.^ni;
        term1 = prod(term0, 1);
        term2 = exp(-tau * sum(TuningCurve_FR_i, 1));
        post_unnorm = term1 .* term2;
        [~, argmax_bin] = max(post_unnorm);
        pos = [];
        pos = repmat(SpatialBin_centers_cm(argmax_bin),1,(t2-t1+1));

        a_pos = actual_pos(t1:t2);
        if length(a_pos) ~= length(pos)
            error('actual pos and decoded pos not the same length');
        end

        d_error = [];
        for d = 1:length(a_pos)
            d_error = [d_error,BeltDist(a_pos(d),pos(d))];
        end
    else
        pos = NaN(1,(t2-t1+1));
        d_error = [];
        d_error = NaN(1,(t2-t1+1));
    end
    decoded_pos = [decoded_pos,pos];
    decoded_error = [decoded_error;nanmean(d_error)];
end

end