function [LapStructure]= GetLapStructure_0002(h5FileName,SIFrameClock_diff_threshold)

% load an .h5 file
[Vel,Dist,Licks,Reward,SIFrameClock,RewardTarget,...
    DigitalScans,filename] = ReadWaveSurfer_0002(h5FileName);
TimePoints = numel(SIFrameClock);

% calculate differences between adjacent elements and find the indices of the first timepoint of each frame
SIFrameClock_diff = diff(SIFrameClock);
FrameTimes = find(SIFrameClock_diff>SIFrameClock_diff_threshold)+1;

% create a WS-size array of frames, 0 = no frame, 1 = frame
FrameTimes_WS = zeros(TimePoints,1);
FrameTimes_WS(FrameTimes) = 1;

% calculate the baseline of velocity and subtract it from FrameTimes_Vel
Vel_bin_edges = 0:0.0005:5;
[Vel_binCounts, ~] = histcounts(Vel,Vel_bin_edges);
[~, maxIndex] = max(Vel_binCounts);
Vel_baseline = (Vel_bin_edges(maxIndex)+Vel_bin_edges(maxIndex+1))/2;
Vel_corrected = 80*(Vel - Vel_baseline);

% create a WS-size array of running or not, 0 = not running, 1 = running
Running_WS = zeros(TimePoints,1);
Running_WS(Vel_corrected>2) = 1;

% find velocity corresponding to each frame
FrameTimes_Vel = Vel_corrected(FrameTimes);

% find location corresponding to each frame
FrameTimes_Dist = Dist(FrameTimes);

% calculate differences between adjacent elements and find the indices of the first timepoint of each lick
Licks_diff = diff(Licks);
LickTimes = find(Licks_diff>5)+1;

% create a WS-size array of licks, 0 = no lick, 1 = lick
LickTimes_WS = zeros(TimePoints,1);
LickTimes_WS(LickTimes) = 1;

% create a WS-size array of reward targets, fixed to be 1
RewardTarget1 = find(RewardTarget<1);
RewardTarget_WS = zeros(TimePoints,1);
RewardTarget_WS(RewardTarget1) = 1;

% find the first time point of reward releases and create a WS-size array, 0 = no reward release, 1 = reward release
RewardRelease = find(DigitalScans==2);
RewardRelease_WS = zeros(TimePoints,1);
RewardRelease_WS(RewardRelease) = 1;
RewardRelease_WS_diff = diff(RewardRelease_WS);
RewardReleaseTimes = find(RewardRelease_WS_diff>0.8)+1;
RewardReleaseTimes_WS = zeros(TimePoints,1);
RewardReleaseTimes_WS(RewardReleaseTimes) = 1;

% find resets and create a WS-size array of resets, 0 = no reset, 1 = reset
Resets = find(DigitalScans==1);
Resets_WS = zeros(TimePoints,1);
Resets_WS(Resets) = 1;

% find the first time point and the last timepoint of each lap reset
Resets_WS_diff = diff(Resets_WS);
Reset_start = find(Resets_WS_diff>0.8)+1;
Reset_end = find(Resets_WS_diff<0)+1;
Reset_end_add_1 = [1;Reset_end];

% find the indices of the start and the end of each lap
Lap_start_end = [1;Reset_start;TimePoints];

% create a WS-size array of reset times, 0 = no reset, 1 = reset
ResetTimes_WS = zeros(TimePoints,1);
ResetTimes_WS(Reset_start) = 1;

% create an array of lap numbers
LapNumber = 1:numel(Reset_start);

% create a structure segmented by laps that contains all the parameters
FrameNumber_cumulative = [];
FrameTimes_WS_before_1st_lap = find(FrameTimes_WS(1:(Lap_start_end(2)-1))==1);
for i = 1:numel(LapNumber)
    LapStructure(i).FileName = filename;
    LapStructure(i).LapNumber = i;
    LapStructure(i).RewardLocation = 90;
    FrameTimes_abs = [];
    FrameNumber = [];
    FrameNumber_to_lap_start = [];
    FrameNumber_running = [];
    Velocity_frame = [];
    Distance_frame = [];
    Velocity_frame_running = [];
    Distance_frame_running = [];
    RunningOrNot = [];
    LickingTimes = [];
    LickingLocation = [];
    RewardDeliveryTimes = [];
    RewardDeliveryLocation = [];
    Velocity_running = [];
    Distance_running = [];
    Velocity = [];
    Distance = [];

    LapTimes_WS = Lap_start_end(i+1):(Lap_start_end(i+2)-1);

    Velocity = Vel_corrected(LapTimes_WS);
    Distance = Dist(LapTimes_WS);

    RunningTimes_in_lap = find(Running_WS(LapTimes_WS)==1);
    RunningTimes = Lap_start_end(i+1) - 1 + RunningTimes_in_lap;
    Velocity_running = Vel_corrected(RunningTimes);
    Distance_running = Dist(RunningTimes);
    
    FrameTimes_in_lap = find(FrameTimes_WS(LapTimes_WS)==1);
    FrameTimes_abs = Lap_start_end(i+1) - 1 + FrameTimes_in_lap;
    FrameNumber_to_lap_start = 1:numel(FrameTimes_in_lap);
    
    if i == 1
       FrameNumber_cumulative(i) = numel(FrameNumber_to_lap_start) + numel(FrameTimes_WS_before_1st_lap);
    else
       FrameNumber_cumulative(i) = FrameNumber_cumulative(i-1) + numel(FrameNumber_to_lap_start);
    end
    
    if i == 1
       FrameNumber = FrameNumber_to_lap_start + numel(FrameTimes_WS_before_1st_lap);
    else
       FrameNumber = FrameNumber_cumulative(i-1) + FrameNumber_to_lap_start;
    end
    
    Velocity_frame = Vel_corrected(FrameTimes_abs);
    Distance_frame = Dist(FrameTimes_abs);

    FrameTimes_running_in_lap = find(Running_WS(FrameTimes_abs)==1);
    FrameTimes_abs_running = FrameTimes_abs(FrameTimes_running_in_lap);
    FrameNumber_running_to_lap_start = FrameNumber_to_lap_start(FrameTimes_running_in_lap);

    if i == 1
       FrameNumber_running = FrameNumber_running_to_lap_start + numel(FrameTimes_WS_before_1st_lap);
    else
       FrameNumber_running = FrameNumber_cumulative(i-1) + FrameNumber_running_to_lap_start;
    end
    
    Velocity_frame_running = Vel_corrected(FrameTimes_abs_running);
    Distance_frame_running = Dist(FrameTimes_abs_running);
    RunningOrNot = Running_WS(FrameTimes_abs);

    LickingTimes_in_lap = find(LickTimes_WS(LapTimes_WS)==1);
    LickingTimes = Lap_start_end(i+1) - 1 + LickingTimes_in_lap;
    LickingLocation = Dist(LickingTimes);
    
    RewardDeliveryTimes_in_lap = find(RewardReleaseTimes_WS(LapTimes_WS)==1);
    RewardDeliveryTimes = Lap_start_end(i+1) - 1 + RewardDeliveryTimes_in_lap;
    RewardDeliveryLocation = Dist(RewardDeliveryTimes);
    
    LapStructure(i).FrameTimes_abs = FrameTimes_abs';
    LapStructure(i).FrameNumber = FrameNumber;
    LapStructure(i).FrameNumber_to_lap_start = FrameNumber_to_lap_start;
    LapStructure(i).FrameNumber_running = FrameNumber_running;
    LapStructure(i).Velocity_frame = Velocity_frame';
    LapStructure(i).Distance_frame = Distance_frame';
    LapStructure(i).Velocity_frame_running = Velocity_frame_running';
    LapStructure(i).Distance_frame_running = Distance_frame_running';
    LapStructure(i).RunningOrNot = RunningOrNot';
    LapStructure(i).LickingTimes = LickingTimes';
    LapStructure(i).LickingLocation = LickingLocation';
    LapStructure(i).RewardDeliveryTimes = RewardDeliveryTimes;
    LapStructure(i).RewardDeliveryLocation = RewardDeliveryLocation;
    LapStructure(i).Velocity_running = Velocity_running';
    LapStructure(i).Distance_running = Distance_running';
    LapStructure(i).Velocity = Velocity';
    LapStructure(i).Distance = Distance';

end

% check if there are early or missed lap resets
for i = 1:numel(LapNumber)
    if numel([LapStructure(i).Distance]) > 0
       LapStructure(i).ResetLocation = [LapStructure(i).Distance(end)];
       
       if LapStructure(i).Distance(end) <= 1.7
          LapStructure(i).ShortLapsWithEarlyReset = 1;
       else
          LapStructure(i).ShortLapsWithEarlyReset = 0;
       end

       if LapStructure(i).Distance(end) > 1.9
          LapStructure(i).LongLapsWithoutReset = 1;
       else
          LapStructure(i).LongLapsWithoutReset = 0;
       end   
    end

    if numel([LapStructure(i).Distance_frame]) > 0
       LapStructure(i).LastFrameLocation = [LapStructure(i).Distance_frame(end)];
    end
end

end
