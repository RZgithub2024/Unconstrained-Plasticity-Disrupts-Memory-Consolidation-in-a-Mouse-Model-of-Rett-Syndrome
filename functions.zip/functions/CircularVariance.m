function [cv] = CircularVariance(loc)

% calculate circular variance
[loc_rad] = loc2rad(loc);

N = length(loc_rad);
sum_cos = sum(cos(loc_rad));
sum_sin = sum(sin(loc_rad));
R = sqrt(sum_cos^2 + sum_sin^2) / N;
cv = 1 - R;

end