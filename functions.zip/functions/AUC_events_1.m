function AUC_sum = AUC_events_1(dFoF_noisy,AUC_cumu,event_peak_frames)

% input: cumulative AUC of a given cell, event peak frames
% calculate AUC sum of specified events in a zerocrossing manner

if ~isempty(event_peak_frames)
    area = [];
    t = 1:length(dFoF_noisy);
    y = dFoF_noisy;
    t2 = 0;
    for i = 1:numel(event_peak_frames)
        t0 = event_peak_frames(i);
        
        % start zerocrossing
        % Find the closest t1 < t0 where y(t1) > 0 and y(t1-1) <= 0
        t1_idx = find(y(1:t0-1) <= 0 & y(2:t0) > 0, 1, 'last');
        if ~isempty(t1_idx)
            t1 = t(t1_idx);
        else
            t1 = t(1);
            disp('No real t1 found.');
            disp(i);
        end
        
        % check if t1 >= t2; otherwise, skip current iteration
        if t1 < t2
            continue
        end

        % end zerocrossing
        % Find the cloest t2 > t0 where y(t2-1) > 0 and y(t2) <= 0
        t2_idx = find(y(t0+1:end-1) > 0 & y(t0+2:end) <= 0, 1, 'first');
        if ~isempty(t2_idx)
            t2 = t(t0+t2_idx+1);
        else
            t2 = t(end);
            disp('No real t2 found.');
            disp(i);
        end

        AUC_event = AUC_cumu(t2) - AUC_cumu(t1);
        area = [area;AUC_event];
    end
    AUC_sum = sum(area);

elseif isempty(event_peak_frames)
    AUC_sum = 0;
end
end