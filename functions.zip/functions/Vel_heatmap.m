function Vel_heatmap(LapStructure,WS,folderpath)

% heatmap of running velocity data of the entire session
Vel_by_lap = [];
for k = 1:numel([LapStructure.LapNumber])
    Distance_running = [];
    Vel_each_lap = [];
    Vel_each_lap = [LapStructure(k).Velocity_running];
    SpatialBin_edges_centimeter = 0:3.6:180;
    SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
    Distance_running = LapStructure(k).Distance_running;
    first_index = find(Distance_running < 0.1, 1);
    if ~isempty(first_index)
       if first_index ~= 1
          Distance_running(1:(first_index-1)) = Distance_running(first_index);
       end
    end
    SpatialBin_indices = discretize(Distance_running,SpatialBin_edges_meter);
    Vel_by_bin = [];
    for j = 1:50
        Indices_in_bins = find(SpatialBin_indices == j);
        Vel_by_bin = [Vel_by_bin,mean(Vel_each_lap(Indices_in_bins))];
    end
    Vel_by_lap = [Vel_by_lap;Vel_by_bin];
end

fig = figure('Visible', 'off');
imagesc(Vel_by_lap);
colormap("jet");
xlabel('Position (cm)');
ylabel('Laps');
xlim([0.5 50]);
newxticks = [0.5,12.5,25,37.5,50];  % Replace with your desired positions
newxticklabels = {'0','45','90','135','180'};  % Replace with your desired labels
newyticks = [1,size(Vel_by_lap,1)];
newyticklabels = {'1',num2str(size(Vel_by_lap,1))};
xticks(newxticks);
yticks(newyticks);
xticklabels(newxticklabels);
colorbar;
clim([0 50]);
clb = colorbar();
ylabel(clb, "Velocity (cm/s)");
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);
xline(25, '--w', 'LineWidth', 2.5);

filename = 'Heatmap_velocity.png';
fullpath = fullfile(folderpath,filename);
saveas(fig, fullpath);

end