% find the dFoF noise threshold for a single cell
function [signal_threshold] = Get_NoiseThreshold(dFoF_Cell)

EachCell_dFoF_whole_session = dFoF_Cell;
% bin all the dFoF values to get a distribution
[dFoF_binCounts,dFoF_bin_edges] = histcounts(EachCell_dFoF_whole_session);
% find the dFoF coresponding to the peak and take it as the mu of the corrected normal distribution
[~, maxIndex] = max(dFoF_binCounts);
EachCell_dFoF_histogram_mu = (dFoF_bin_edges(maxIndex)+dFoF_bin_edges(maxIndex+1))/2;
% find the dFoF less than mu and flip it around mu
EachCell_dFoF_histogram_corrected_left = EachCell_dFoF_whole_session(EachCell_dFoF_whole_session<EachCell_dFoF_histogram_mu);
EachCell_dFoF_histogram_corrected_right = 2 * EachCell_dFoF_histogram_mu - EachCell_dFoF_histogram_corrected_left;
% create a new dataset of dFoF which is symmetric around mu
EachCell_dFoF_histogram_corrected = [EachCell_dFoF_histogram_corrected_left,EachCell_dFoF_histogram_corrected_right];    
% fit the new dataset of dFoF to the normal distribution and find mu and sigma
EachCell_dFoF_pd = fitdist(EachCell_dFoF_histogram_corrected','Normal');
EachCell_dFoF_pd_mu = EachCell_dFoF_pd.mu;
EachCell_dFoF_pd_sigma = EachCell_dFoF_pd.sigma;
% calculate the significance threshold of calcium transients, = mu+3*sigma
signal_threshold = EachCell_dFoF_pd_mu+3*EachCell_dFoF_pd_sigma;

end