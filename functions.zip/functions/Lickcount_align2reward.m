function [lickcount_pseudolaps,lickornot_pseudolaps] = Lickcount_align2reward(BinnedData)

% get the binned lick count, aligned to reward location
% get binnary lick or not matrix
% 24 bins before and 25 bins after reward

LapStructure = BinnedData.LapStructure;
licks_laps = [];
for k = 1:numel([LapStructure.LapNumber])
    licks_loc = [];
    licks_loc = LapStructure(k).LickingLocation * 100;
    edges = 0:3.6:180;
    [lick_counts,~] = histcounts(licks_loc, edges);
    licks_laps = [licks_laps;lick_counts];
end
licks_laps_flat = reshape(licks_laps', 1, []);

LickOrNot_by_lap = zeros(numel([BinnedData.LapStructure.LapNumber]),50);
for k = 1:numel([BinnedData.LapStructure.LapNumber])
    Licks_each_lap = BinnedData.LapStructure(k).LickingLocation;
    SpatialBin_edges_centimeter = 0:3.6:180;
    SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
    SpatialBin_indices = discretize(Licks_each_lap,SpatialBin_edges_meter);
    for jj = 1:50
        if numel(find(SpatialBin_indices == jj)) > 0
            LickOrNot_by_lap(k,jj) = 1;
        end
    end
end
LickOrNot_by_lap_flat = reshape(LickOrNot_by_lap', 1, []);

lickcount_pseudolaps = [];
lickornot_pseudolaps = [];
for k = 1:numel([LapStructure.LapNumber])
    if ~isempty([LapStructure(k).RewardDeliveryLocation])
        reward_loc_cm = LapStructure(k).RewardDeliveryLocation(1)*100;
        if reward_loc_cm >= 0 && reward_loc_cm <= 180
            edges = 0:3.6:180;
            reward_loc_bin = discretize(reward_loc_cm,edges);
            reward_loc_bin_flat = reward_loc_bin + 50*(k-1);
            pseudo_lap = [];
            pseudo_lap = (reward_loc_bin_flat-24):(reward_loc_bin_flat+25);
            pseudo_lap(pseudo_lap<1 | pseudo_lap>numel(licks_laps_flat)) = NaN;
            lc_pseudo_lap = [];
            ln_pseudo_lap = [];
            for p = 1:length(pseudo_lap)
                if ~isnan(pseudo_lap(p))
                    lc_pseudo_lap(p) = licks_laps_flat(pseudo_lap(p));
                    ln_pseudo_lap(p) = LickOrNot_by_lap_flat(pseudo_lap(p));
                else
                    lc_pseudo_lap(p) = NaN;
                    ln_pseudo_lap(p) = NaN;
                end
            end
        else
            lc_pseudo_lap = nan(1,50);
            ln_pseudo_lap = nan(1,50);
        end
    else
        lc_pseudo_lap = nan(1,50);
        ln_pseudo_lap = nan(1,50);
    end
    lickcount_pseudolaps = [lickcount_pseudolaps;lc_pseudo_lap];
    lickornot_pseudolaps = [lickornot_pseudolaps;ln_pseudo_lap];
end

end