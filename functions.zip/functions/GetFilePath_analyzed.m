function [MouseIDStr,filePath_7days_analyzed] = GetFilePath_analyzed()
% Choose a folder with a dialog
folderPath = uigetdir('Select a folder');
if isequal(folderPath, 0)
    disp('User canceled folder selection.');
    return;
end

% Search for .mat files with "analyzed" in their names in all subfolders
PFStructureFiles = dir(fullfile(folderPath, '**', '*analyzed*.mat'));
if isempty(PFStructureFiles)
    disp('No .mat files with "analyzed" in their names found.');
    return;
end

% Extract mouse ID and two-digit numbers after "F" in file names and convert to numbers
ImagingDayNumbers = [];
filePath_all = {};
for i = 1:numel(PFStructureFiles)
    [~, fileName, ~] = fileparts(PFStructureFiles(i).name);
    filePath = fullfile(PFStructureFiles(i).folder, PFStructureFiles(i).name);
    startIndex_RZ = strfind(fileName, 'RZ') + 2;
    endIndex_RZ = startIndex_RZ + 2;
    if isempty(startIndex_RZ) || isempty(endIndex_RZ)
        disp(['Error extracting mouse ID from file: ', PFStructureFiles(i).name]);
    else
        MouseIDStr = fileName((startIndex_RZ-2):endIndex_RZ);
    end
    startIndex_F = strfind(fileName, 'F') + 1;
    endIndex_F = startIndex_F + 1;
    if isempty(startIndex_F) || isempty(endIndex_F)
        disp(['Error extracting day number from file: ', PFStructureFiles(i).name]);
    else
        numberStr = fileName(startIndex_F:endIndex_F);
        number = str2double(numberStr);
        filePath_all{i,1} = MouseIDStr;
        filePath_all{i,2} = number;
        filePath_all{i,3} = string(filePath);
        if ~isnan(number)
            ImagingDayNumbers = [ImagingDayNumbers, number];
        else
            disp(['Error converting number from file: ', PFStructureFiles(i).name]);
        end
    end
end
filePath_all_sorted = sortrows(filePath_all,1);
filePath_7days_analyzed = filePath_all_sorted(:,3)';

end
