function [Cells_F_smoothed,Cells_F0_mode,Cells_dFoF_mode] = GetdFoF_60s_mode(Cells_F)

% smooth the raw F
Cells_F_smoothed = [];
for i = 1:size(Cells_F,1)
    Cells_F_smoothed(i,:) = smooth(Cells_F(i,:));
end

% calculate F0 using a 60-s sliding window
% F0 is the mode of the sliding window in a binned manner

Cells_F0_mode = zeros(size(Cells_F_smoothed));

% Start parallel processing
% Start a parallel pool
parpool('local');

a1 = size(Cells_F_smoothed,2)-899;
a2 = size(Cells_F_smoothed,2);
a3 = size(Cells_F_smoothed,2)-900;

parfor i = 1:size(Cells_F_smoothed,1)
    % Frame 1 — 900
    F = Cells_F_smoothed(i,1:1801);
    [binCounts,binEdges] = histcounts(F);
    [~, maxIndex] = max(binCounts);
    for ii = 1:900
        Cells_F0_mode(i,ii) = (binEdges(maxIndex)+binEdges(maxIndex+1))/2;
    end

    % Frame size(Cells_F,2)-899 — size(Cells_F,2)
    F = Cells_F_smoothed(i,(size(Cells_F_smoothed,2)-1801):size(Cells_F_smoothed,2));
    [binCounts,binEdges] = histcounts(F);
    [~, maxIndex] = max(binCounts);
    for ii = a1:a2
        Cells_F0_mode(i,ii) = (binEdges(maxIndex)+binEdges(maxIndex+1))/2;
    end

    % Frames in the middle
    for ii = 901:a3
        F = Cells_F_smoothed(i,(ii-900):(ii+900));
        [binCounts,binEdges] = histcounts(F);
        [~, maxIndex] = max(binCounts);
        Cells_F0_mode(i,ii)= (binEdges(maxIndex)+binEdges(maxIndex+1))/2;
    end
end

% Close the parallel pool
delete(gcp('nocreate'));

% calculate dFoF as (F_smoothed–F0)/F0
Cells_dFoF_mode = (Cells_F_smoothed-Cells_F0_mode)./Cells_F0_mode;

end