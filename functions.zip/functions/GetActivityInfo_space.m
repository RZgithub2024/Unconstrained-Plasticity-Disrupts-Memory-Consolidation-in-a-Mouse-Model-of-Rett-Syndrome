function activityInfo = GetActivityInfo_space(dFoF_centered)

activityInfo = [];
activityInfo(1) = nansum(dFoF_centered(17:33));
activityInfo(2) = nanmean(dFoF_centered(17:33));
X1 = dFoF_centered(1:16);
X2 = dFoF_centered(34:50);
X3 = [X1,X2];
activityInfo(3) = nansum(X3);
activityInfo(4) = nanmean(X3);
activityInfo(5) = (activityInfo(1)-activityInfo(3))/(activityInfo(1)+activityInfo(3));

end