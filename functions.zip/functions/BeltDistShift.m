% calculate the actual belt distance shift for two given location, x1 and x2
% d could be positive or negative or zero
function [s] = BeltDistShift(x1,x2)

if x1 == x2
   s = 0;
end

if x1 > x2
   d1 = abs(x1-x2);
   d2 = min(x1,x2)-0+(180-max(x1,x2));
   d = min(d1,d2);
   if d1 <= 90
      s = -d;
   else
      s = d;
   end
end

if x1 < x2
   d1 = abs(x1-x2);
   d2 = min(x1,x2)-0+(180-max(x1,x2));
   d = min(d1,d2);
   if d1 > 90
      s = -d;
   else
      s = d;
   end
end

end