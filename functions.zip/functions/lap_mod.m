function b = lap_mod(A,M)

b = mod(A,M);

if b == 0
    b = 50;
end

end