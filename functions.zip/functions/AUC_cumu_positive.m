function AUC = AUC_cumu_positive(dFoF_noisy)

% calculate cumulative AUC for all positive dFoF from noisy dFoF

t = 1:length(dFoF_noisy);

% Keep only positive values (set negative values to zero)
y_positive = max(dFoF_noisy, 0);

AUC = cumtrapz(t, y_positive);

end