function AUCs = GetAUCs(plt_in_peaks,nonplt_in_peaks,plt_out_peaks,nonplt_out_peaks,...
    dFoF_noisy,laps_before_BTSP,running_time)


b = [];
b = [plt_in_peaks;...
    nonplt_in_peaks;...
    plt_out_peaks;...
    nonplt_out_peaks];

if ~isempty(b)

    AUC_cumu = AUC_cumu_positive(dFoF_noisy);
    AUCs = [];
    AUCs(1) = AUC_events_2(AUC_cumu,plt_in_peaks);
    AUCs(2) = AUC_events_2(AUC_cumu,nonplt_in_peaks);
    AUCs(3) = AUC_events_2(AUC_cumu,plt_out_peaks);
    AUCs(4) = AUC_events_2(AUC_cumu,nonplt_out_peaks);

    for n = 1:4
        AUCs(n+4) = AUCs(n)/numel(laps_before_BTSP);
        AUCs(n+12) = AUCs(n)/running_time;
    end

    AUCs(9) = (AUCs(2)-AUCs(4))/(AUCs(2)+AUCs(4));
    AUCs(10) = AUCs(1)+AUCs(2);
    AUCs(11) = AUCs(3)+AUCs(4);
    AUCs(12) = AUCs(10)/(AUCs(10)+AUCs(11));

    AUCs_cells = [AUCs_cells;AUCs];

end






end