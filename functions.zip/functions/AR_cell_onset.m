function [AR1,AR2] = AR_cell_onset(Events,laps,LapStructure,dFoF_noisy,AUC_cumu)

% calculate AUC/s using given lap ID
% AR1: AUC/s, AR2: event/s
% use AUC_events_1()

frame_numbers = [];
running_frame_numbers = [];
for k = 1:numel(laps)
    frame_numbers = [frame_numbers,LapStructure(laps(k)).FrameNumber];
    running_frame_numbers = [running_frame_numbers,LapStructure(laps(k)).FrameNumber_running];
end
running_time = numel(running_frame_numbers)/30;

if ~isempty(Events)
    Events_Running = [];
    events_running_idx = [];
    events_running_idx = ismember(Events(:,1), frame_numbers) & ...
        ismember(Events(:,2), frame_numbers) & ...
        ismember(Events(:,5), frame_numbers) & ...
        (Events(:,3) > 0) & ...
        (Events(:,6) >= 0) & ...
        (Events(:,6) <= 180);
    Events_Running = Events(events_running_idx,:);
    if ~isempty(Events_Running)
        AUCs = [];
        for k = 1:size(Events_Running,1)
            auc = [];
            auc = AUC_events_1(dFoF_noisy,AUC_cumu,Events_Running(k,5));
            AUCs = [AUCs,auc];
        end
        AR1 = sum(AUCs)/running_time;
        AR2 = size(Events_Running,1)/running_time;
    else
        AR1 = 0;
        AR2 = 0;
    end
else
    AR1 = 0;
    AR2 = 0;
end

end