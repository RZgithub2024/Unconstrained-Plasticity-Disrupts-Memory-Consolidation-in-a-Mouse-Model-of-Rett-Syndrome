function [d] = BeltDist(x1,x2)

% calculate the actual belt distance for two given location, x1 and x2, in
% cm
% d >= 0

if x1 == x2
   d = 0;
else
   d1 = abs(x1-x2);
   d2 = min(x1,x2)-0+(180-max(x1,x2));
   d = min(d1,d2);
end
end