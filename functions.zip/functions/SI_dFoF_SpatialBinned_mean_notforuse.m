function [SI_dFoF_binned_mean] = SI_dFoF_SpatialBinned_mean(dFoF_each_cell_running,LapStructure)

RunningFrame_ID = {};
RunningFrame_ID_distance = {};
for k = 1:numel([LapStructure.LapNumber])
    if k == 1
       a = numel(LapStructure(k).FrameNumber_running);
       d = LapStructure(k).Distance_frame_running;
       RunningFrame_ID{k} = 1:numel(LapStructure(k).FrameNumber_running);
       RunningFrame_ID_distance{k} = d;
    else
       b = a+1;
       a = a + numel(LapStructure(k).FrameNumber_running);
       d = LapStructure(k).Distance_frame_running;
       RunningFrame_ID{k} = b:a;
       RunningFrame_ID_distance{k} = d;
    end
end

EachCell_dFoF_binned_mean_by_lap = [];
for k = 1:numel([LapStructure.LapNumber])
    EachCell_dFoF_binned_mean_each_lap = dFoF_each_cell_running(RunningFrame_ID{k});
    SpatialBin_edges_centimeter = 0:3.6:180;
    SpatialBin_edges_meter = SpatialBin_edges_centimeter / 100;
    SpatialBin_indices = discretize(RunningFrame_ID_distance{k},SpatialBin_edges_meter);
    EachCell_dFoF_by_bin_mean = [];
    for j = 1:50
        Indices_in_bins = find(SpatialBin_indices == j);
        EachCell_dFoF_by_bin_mean = [EachCell_dFoF_by_bin_mean,mean(EachCell_dFoF_binned_mean_each_lap(Indices_in_bins),"omitnan")];
    end
    EachCell_dFoF_binned_mean_by_lap = [EachCell_dFoF_binned_mean_by_lap;EachCell_dFoF_by_bin_mean];
end
SI_dFoF_binned_mean = mean(EachCell_dFoF_binned_mean_by_lap,1,"omitnan");

end