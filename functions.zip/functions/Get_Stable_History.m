function [StableHistory_animal, PFHistory_animal] = Get_Stable_History(PFloc_animal)
for cell = 1:size(PFloc_animal,1)
    [StableHistory_animal(cell,:),PFHistory_animal(cell,:)] = compute_stability_history(PFloc_animal(cell,3:9));
end
end
function [streaks, nonNaN_count] = compute_stability_history(seq)
n = length(seq);
streaks = zeros(1, n); % Initialize with zeros
nonNaN_count = zeros(1, n); % To track nth non-NaN value
count = 0;
for i = 1:n
    if isnan(seq(i))
        streaks(i) = 0;
        nonNaN_count(i) = 0;
    else
        count = count + 1;
        nonNaN_count(i) = count;
        if i == 1 || isnan(seq(i-1)) || abs(Find_MinDistCircTrack(seq(i),seq(i-1),180)) > 30
            streaks(i) = 1;
        else
            streaks(i) = streaks(i-1) + 1;
        end
    end
end
end




function shift = Find_MinDistCircTrack(a, b, tracklength)
% Find_MinDistCircTrack - Compute circular distance between two positions.
%
% Returns signed minimum distance between two points a and b on a circular
% track of specified length (e.g., 180 cm).
%
% Syntax:
% shift = Find_MinDistCircTrack(a, b, tracklength)
%
% Inputs:
% a, b - scalar positions on a circular track
% tracklength - total length of the track (e.g., 180)
%
% Output:
% shift - signed minimal circular distance from a to b
% Normalize difference to track length
normdist = mod(b - a, tracklength);
minDist = min(tracklength - normdist, normdist);
% Determine direction of the shift
if a > b
    shift = -minDist;
else
    shift = minDist;
end
% Correction for boundary-crossing cases
if (tracklength - max(a,b) + min(a,b) > minDist - 1) && ...
        (tracklength - max(a,b) + min(a,b) < minDist + 1)
    if a > b
        shift = minDist;
    else
        shift = -minDist;
    end
end
end