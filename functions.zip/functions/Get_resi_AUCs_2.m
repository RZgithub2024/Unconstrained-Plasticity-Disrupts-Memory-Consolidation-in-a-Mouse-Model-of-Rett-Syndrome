function AUCs = Get_resi_AUCs_2(t,BTSP_lap,BinnedData,ROI,PlateauThereshold_WT,MouseID,day,Binned_noisy_WT,PF_loc_prev_cm)

% compute AUC-based selectivity index of residual activity before BTSP
% using AUC_events_2()

start_lap = max([1,(BTSP_lap-t)]);
laps_before_BTSP = start_lap:(BTSP_lap-1);
laps_start_frame = BinnedData.LapStructure(start_lap).FrameNumber(1);
laps_end_frame = BinnedData.LapStructure(BTSP_lap-1).FrameNumber(end);
events = BinnedData.Events(ROI).Events;
PlateauThereshold = PlateauThereshold_WT{MouseID,day}(ROI);
noisy = Binned_noisy_WT{MouseID,day};
dFoF_noisy = noisy.Cells_dFoF_noisy(ROI,:);
f = [];
for kk = 1:numel(laps_before_BTSP)
    f0 = BinnedData.LapStructure(laps_before_BTSP(kk)).FrameNumber_running;
    f = [f,f0];
end
running_time = numel(f)/30;

plt_in_ea = [];
nonplt_in_ea = [];
plt_out_ea = [];
nonplt_out_ea = [];

X3 = [];
X4 = [];

plt_in_events = [];
nonplt_in_events = [];
plt_out_events = [];
nonplt_out_events = [];

for k = 1:size(events,1)
    event_duration = events(k,2)-events(k,1);
    if events(k,5) >= laps_start_frame &&...
            events(k,5) <= laps_end_frame &&...
            events(k,3) == 1 &&...
            event_duration >= 5 &&...
            events(k,6) >= 0 &&...
            events(k,6) <= 180
        event_peak_loc = events(k,6);
        event_peak_dFoF = events(k,4);
        event_prev_PF_shift = BeltDistShift(PF_loc_prev_cm,event_peak_loc);
        %event_BTSP_shift = BeltDistShift(event_peak_loc,BTSP_loc);
        if abs(event_prev_PF_shift) <= 30
            if event_peak_dFoF >= PlateauThereshold  
                plt_in_ea = [plt_in_ea;event_peak_dFoF];
                plt_in_events = [plt_in_events;events(k,:)];
            elseif event_peak_dFoF < PlateauThereshold
                nonplt_in_ea = [nonplt_in_ea;event_peak_dFoF];
                nonplt_in_events = [nonplt_in_events;events(k,:)];
                X3_event = [events(k,5),event_peak_dFoF];
                X3 = [X3;X3_event];
            end
            
        elseif abs(event_prev_PF_shift) > 30
            if event_peak_dFoF >= PlateauThereshold  
                plt_out_ea = [plt_out_ea;event_peak_dFoF];
                plt_out_events = [plt_out_events;events(k,:)];
            elseif event_peak_dFoF < PlateauThereshold
                nonplt_out_ea = [nonplt_out_ea;event_peak_dFoF];
                nonplt_out_events = [nonplt_out_events;events(k,:)];
                X4_event = [events(k,5),event_peak_dFoF];
                X4 = [X4;X4_event];
            end
            
        end
    end
end

b = [];
b = [plt_in_events;...
    nonplt_in_events;...
    plt_out_events;...
    nonplt_out_events];
if ~isempty(b)
    AUC_cumu = AUC_cumu_positive(dFoF_noisy);
    AUCs = [];
    AUCs(1) = AUC_events_2(AUC_cumu,plt_in_events);
    AUCs(2) = AUC_events_2(AUC_cumu,nonplt_in_events);
    AUCs(3) = AUC_events_2(AUC_cumu,plt_out_events);
    AUCs(4) = AUC_events_2(AUC_cumu,nonplt_out_events);

    for n = 1:4
        AUCs(n+4) = AUCs(n)/numel(laps_before_BTSP);
        AUCs(n+12) = AUCs(n)/running_time;
        AUCs(n+16) = NaN;
    end

    AUCs(9) = (AUCs(2)-AUCs(4))/(AUCs(2)+AUCs(4));
    AUCs(10) = AUCs(1)+AUCs(2);
    AUCs(11) = AUCs(3)+AUCs(4);
    AUCs(12) = (AUCs(10)-AUCs(11))/(AUCs(10)+AUCs(11));
    X1 = sum(plt_in_ea) + sum(nonplt_in_ea);
    X2 = sum(plt_out_ea) + sum(nonplt_out_ea);
    AUCs(21) = (X1-X2)/(X1+X2);
    AUCs(22) = (numel(plt_in_ea)+numel(nonplt_in_ea))/numel(laps_before_BTSP);
    AUCs(23) = (numel(plt_out_ea)+numel(nonplt_out_ea))/numel(laps_before_BTSP);
    
    if ~isempty(X3)
        for cc = 1:size(X3,1)
            event_lap = GetEventLap(BinnedData,X3(cc,1));
            X3(cc,3) = event_lap;
        end

        laps = unique(X3(:,3));
        events_peak_laps = [];
        for dd = 1:length(laps)
            peaks = [];
            peaks = X3(X3(:,3) == laps(dd),2);
            if ~isempty(peaks)
                events_peak_laps = [events_peak_laps;max(peaks)];
            else
                events_peak_laps = [events_peak_laps;0];
            end
        end
        event_in_peak_lapmean = mean(events_peak_laps);
    else
        event_in_peak_lapmean = 0;
    end

    if ~isempty(X4)
        for cc = 1:size(X4,1)
            event_lap = GetEventLap(BinnedData,X4(cc,1));
            X4(cc,3) = event_lap;
        end

        laps = unique(X4(:,3));
        events_peak_laps = [];
        for dd = 1:length(laps)
            peaks = [];
            peaks = X4(X4(:,3) == laps(dd),2);
            if ~isempty(peaks)
                events_peak_laps = [events_peak_laps;max(peaks)];
            else
                events_peak_laps = [events_peak_laps;0];
            end
        end
        event_out_peak_lapmean = mean(events_peak_laps);
    else
        event_out_peak_lapmean = 0;
    end

    AUCs(24) = event_in_peak_lapmean;
    AUCs(25) = event_out_peak_lapmean;

    AUCs(26) = (AUCs(1)+AUCs(2))/numel(laps_before_BTSP);
    AUCs(27) = (AUCs(3)+AUCs(4))/numel(laps_before_BTSP);
    
    if ~isempty(X3)
        AUCs(28) = mean(X3(:,2));
    else
        AUCs(28) = 0;
    end

    if ~isempty(X4)
        AUCs(29) = mean(X4(:,2));
    else
        AUCs(29) = 0;
    end

    AUCs(30) = size(plt_in_events,1)/running_time;
    AUCs(31) = size(nonplt_in_events,1)/running_time;
    AUCs(32) = size(plt_out_events,1)/running_time;
    AUCs(33) = size(nonplt_out_events,1)/running_time;
    
    AUCs(34) = (AUCs(24)-AUCs(25))/(AUCs(24)+AUCs(25));

elseif isempty(b)
    AUCs = [];
end

end