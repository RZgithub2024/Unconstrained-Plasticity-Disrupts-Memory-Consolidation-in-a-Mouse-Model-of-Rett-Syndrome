function [Cells_dFoF_denoised,signal_threshold] = Denoise(Cells_dFoF)

Cells_dFoF_denoised = Cells_dFoF;
signal_threshold = [];

parfor i = 1:size(Cells_dFoF,1)

       dFoF_Cell = Cells_dFoF(i,:);
       %disp(i);
       signal_threshold(i) = Get_NoiseThreshold(dFoF_Cell);
       dFoF_Cell(dFoF_Cell<signal_threshold(i)) = 0;

       % prevent false break (upto 2 points below threshold)
       % [1 0 1] pattern
       off1 = strfind((dFoF_Cell>signal_threshold(i)),[1 0 1]);
       if (~isempty(off1))
          dFoF_Cell(off1 + 1) = mean([dFoF_Cell(off1) dFoF_Cell(off1 + 2)],'omitnan');
       end

       % [1 0 0 1] pattern
       off2 = strfind((dFoF_Cell>signal_threshold(i)),[1 0 0 1]);
       if (~isempty(off2))
          dFoF_Cell(off2 + 1) = mean([dFoF_Cell(off2) dFoF_Cell(off2 + 3)],'omitnan');
          dFoF_Cell(off2 + 2) = dFoF_Cell(off2 + 1);
       end

       % Only consecutive three points above threshold is signal
       % [0 1 0] pattern
       fluc1 = strfind((dFoF_Cell>signal_threshold(i)),[0 1 0]);
       if (~isempty(fluc1))
          dFoF_Cell(fluc1 +1) =0;
       end

       % [0 1 1 0] pattern
       fluc2 = strfind((dFoF_Cell>signal_threshold(i)),[0 1 1 0]);
       if (~isempty(fluc2))
          dFoF_Cell(fluc2 +1) =0;
          dFoF_Cell(fluc2 +2) =0;
       end
       
       Cells_dFoF_denoised(i,:) = dFoF_Cell;
end

% the following part is for event detection in the time domain

% % start and end with 0 so peak detection later wont fail incase the signal
% % is already above threshold or ends above threshold.
% Cells_dFoF_denoised(:,1) = 0;
% Cells_dFoF_denoised(:,end) = 0;

end