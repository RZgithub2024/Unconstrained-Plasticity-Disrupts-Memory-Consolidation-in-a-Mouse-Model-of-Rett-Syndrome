function PFs_sorted_heatmap(PFStructure,folderpath)

PFIDs = PFStructure.PFStats.PFIDs;
Onset = PFStructure.Onset;
mean_dFoF_norm_PC = [];
for k = 1:numel(PFIDs)
    PF = PFIDs(k);
    Firing_laps = find(~isnan(squeeze(PFStructure.Cellstats(PF,:,7))));
    Firing_laps(Firing_laps<Onset(PF)) = [];
    dFoF = squeeze(PFStructure.Cells_dFoF_binned_mean(:,:,PF));
    [~,pros_PF_binloc] = max(nanmean(dFoF,1));
    % Get centered dFoF array for PFloc calculation; flatten, shift, reshape
    Flat_array = reshape(dFoF.',1,[]); % Flatten the dFoF array
    shift = 25 - pros_PF_binloc; % positive if <25; negative if >25;
    Centered_flat_array = circshift(Flat_array,shift);
    Centered_dFoF = reshape(Centered_flat_array,size(dFoF,2),[])'; % use this for COM
    mean_dFoF = nanmean(Centered_dFoF(Firing_laps,:),1);
    [mean_dFoF_peak,centered_PFloc] = nanmax(mean_dFoF);
    PF_loc = centered_PFloc - shift;
    if PF_loc>50
       PF_loc = PF_loc -50;
    elseif PF_loc<1
       PF_loc = 50 + PF_loc;
    end
    PF_loc_cm = (PF_loc * 3.6) - 1.8;
    mean_dFoF_norm = mean_dFoF./mean_dFoF_peak;
    mean_dFoF_norm = circshift(mean_dFoF_norm,-shift);
    mean_dFoF_norm_PC(k,1) = PF;
    mean_dFoF_norm_PC(k,2) = PF_loc_cm;
    mean_dFoF_norm_PC(k,3:52) = mean_dFoF_norm;
end
mean_dFoF_norm_PC_sorted = sortrows(mean_dFoF_norm_PC,2);

fig = figure('Visible', 'off');
imagesc(mean_dFoF_norm_PC_sorted(:,3:52));
colormap(jet);
clim([0 1]);
xlim([0.5 50]);
ylim([1 size(mean_dFoF_norm_PC_sorted,1)])
newxticks = [0.5,12.5,25,37.5,50];
newxticklabels = {'0','45','90','135','180'};
xticks(newxticks);
xticklabels(newxticklabels);
newyticks = [1,size(mean_dFoF_norm_PC_sorted,1)];
newyticklabels = {'1',string(size(mean_dFoF_norm_PC_sorted,1))};
yticks(newyticks);
yticklabels(newyticklabels);
xlabel('Position (cm)');
ylabel('Place cell number');
colorbar;
clb = colorbar();
ylabel(clb, "norm. ∆F/F");
clb.FontSize = 14;
WS = PFStructure.WS;
title([WS.FileName(1:5) ' ' WS.FileName(7:9)]);
set(gca, 'FontSize', 14);

filename = 'PFs_sorted_heatmap.png';
fullpath = fullfile(folderpath,filename);
saveas(fig, fullpath);

end