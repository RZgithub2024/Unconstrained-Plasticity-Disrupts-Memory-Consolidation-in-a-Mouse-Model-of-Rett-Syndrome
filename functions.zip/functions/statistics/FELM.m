function [Cond,tbl,mdl_int] = FELM(WT,RTT)

days = size(WT,2);
y = [WT(:); RTT(:)];
Group = [repmat({'WT'},  numel(WT),1); repmat({'RTT'}, numel(RTT),1)];
Cond = repmat(1:days, size(WT,1)*2, 1);
Cond = Cond(:);

ok = ~isnan(y);
tbl = table(y(ok), categorical(Group(ok)), Cond(ok), ...
    'VariableNames', {'y','Group','Cond'});

% If you also want to know if the effect differs by condition:
mdl_int = fitlm(tbl, 'y ~ Group * Cond');    % tests Group:Cond interaction
anovaTbl = anova(mdl_int);
disp(anovaTbl)

% mdl = fitlm(tbl, 'y ~ Group + Cond');       % overall group effect (adjusted)
% anova(mdl);                                  % term-wise F-tests

% resid = residuals(mdl_int);
% figure;
% subplot(1,2,1);
% qqplot(resid);       % should fall near the diagonal
% subplot(1,2,2);
% histogram(resid);    % should look roughly bell-shaped

end