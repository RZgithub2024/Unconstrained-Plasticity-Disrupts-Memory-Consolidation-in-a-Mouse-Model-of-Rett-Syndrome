function anovaTbl = LMEM_2(WT,RTT)

% Linear mixed effects models

n_Days = size(WT,2);
Y = [WT;RTT]; % stack responses
n_WT   = size(WT,1);
n_RTT  = size(RTT,1);
n_Mouse = n_WT + n_RTT;

% mouse IDs
Mouse = (1:n_Mouse)'; 

% group labels
Group = [repmat("WT",n_WT,1); repmat("RTT",n_RTT,1)];

% build long-format table
Day = repmat((1:n_Days)', n_Mouse, 1);
MouseID = repelem(Mouse, n_Days);
GroupLong = repelem(Group, n_Days);
Response = reshape(Y.', [], 1);

tbl = table(categorical(MouseID), categorical(GroupLong), Day, Response, ...
            'VariableNames', {'MouseID','Group','Day','Response'});

% fit linear mixed-effects model
lme = fitlme(tbl, 'Response ~ Group*Day + (Day|MouseID)');

% Check residuals (normality, homoscedasticity)
resid = residuals(lme);
figure;
subplot(1,2,1);
qqplot(resid);       % should fall near the diagonal
subplot(1,2,2);
histogram(resid);    % should look roughly bell-shaped

% Get an ANOVA-style table
anovaTbl = anova(lme);
disp(anovaTbl)

end