function [p,tbl,stats,results,tbl_posthoc] = twowayanova_2(WT,RTT)

n_WT = size(WT,1);
n_RTT = size(RTT,1);
days = size(WT,2);

data = [WT;RTT];
group = [repmat({'WT'}, n_WT, 1); repmat({'RTT'}, n_RTT, 1)];
day = repmat(1:days, (n_WT+n_RTT), 1);
day_flat = day(:);
data_flat = data(:);
group_flat = repmat(group, days, 1);
[p, tbl, stats] = anovan(data_flat, {group_flat, day_flat}, 'model', 'interaction', 'varnames', {'Group', 'Day'});

[results,~,~,gnames] = multcompare(stats, 'Dimension', [1 2], 'CType', 'tukey-kramer');

tbl_posthoc = array2table(results,"VariableNames", ...
    ["Group A","Group B","Lower Limit","A-B","Upper Limit","P-value"]);
tbl_posthoc.("Group A")=gnames(tbl_posthoc.("Group A"));
tbl_posthoc.("Group B")=gnames(tbl_posthoc.("Group B"));
tbl_posthoc

% normality test
resid = stats.resid;
residuals_flat = resid(:);
normalDistribAnalyser(residuals_flat)


% test for homogeneity of variances
val = [WT(:); RTT(:)];
group = [repmat({'WT'},numel(WT),1); repmat({'RTT'},numel(RTT),1)];
cond  = repmat(1:days, size(WT,1)*2, 1);
cond = cond(:);
ok = ~isnan(val);
disp('LeveneAbsolute');
size(val(ok))
size(group(ok))
[p, stats] = vartestn(val(ok), group(ok), 'TestType','LeveneAbsolute')

end