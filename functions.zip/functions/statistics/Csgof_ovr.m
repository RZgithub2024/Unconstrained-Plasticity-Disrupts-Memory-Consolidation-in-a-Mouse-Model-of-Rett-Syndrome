function [h,pval,chi2stat,df] = Csgof_ovr(A,N_PCs,edges)

% Chi-square goodness-of-fit test in MATLAB
% This test compares your observed counts per bin against the expected counts
% under a uniform distribution (equal probability across all bins).
% A is normalized fraction after binning
% only used to check PF location distribution in overrepresentation

N_bins = numel(edges)-1;
counts = A .* N_PCs;

N = sum(counts);                   % total number of data points
expected = N * ones(1,N_bins)/N_bins;      % expected counts per bin (equal)

chi2stat = sum((counts - expected).^2 ./ expected);
df = length(counts) - 1;           % degrees of freedom = bins-1
pval = chi2cdf(chi2stat, df, 'upper');  % upper-tail probability

if pval < 0.05
    h = 1;
else
    h = 0;
end

end