function [ranovatbl,anovatbl,results_posthoc] = twrm_ANOVA(WT,RTT)

% Two-way repeated measures ANOVA
n_Days = size(WT,2);
Y = [WT;RTT];
n_WT = size(WT,1);
n_RTT = size(RTT,1);
n_Mouse = n_WT + n_RTT;

Group = [repmat("WT",n_WT,1); repmat("RTT",n_RTT,1)];
Group = categorical(Group);
TG = array2table(Group);
DayNames = "Day" + (1:n_Days);

T = array2table(Y, 'VariableNames', DayNames);
tbl = [TG,T];

WD = table((1:n_Days)','VariableNames',{'Time'});
formula = sprintf('%s-%s ~ Group', DayNames(1), DayNames(end));
rm = fitrm(tbl, formula, 'WithinDesign', WD);

% Repeated-measures ANOVA
ranovatbl = ranova(rm, 'WithinModel','Time');
disp(ranovatbl)

% Between-subject effect (Group)
anovatbl = anova(rm);
disp(anovatbl)

% test the normality of raw data
Yfit = predict(rm);
residuals = Y - Yfit;
residuals_flat = residuals(:);
normalDistribAnalyser(residuals_flat)

% Mauchly's test of sphericity
mauchlyTbl = mauchly(rm);
disp(mauchlyTbl)
if mauchlyTbl.pValue < 0.05
    disp('Sphericity is violated.');
    epsilon_tbl = epsilon(rm)
else
    disp('Sphericity is met.');
end

% post-hoc comparison
results_posthoc = multcompare(rm, 'Group', 'By', 'Time');

end