function [ranova_results,mc] = rmanova(data)

% repeat measured ANOVA, 8 days
% Animal IDs
animals = (1:size(data,1))';

% Create table with time points
X_table = array2table(data, 'VariableNames', {'T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8'});

% Define time points as within-subject factors
time = table((1:8)', 'VariableNames', {'Time'});

% Fit repeated measures model
rm = fitrm(X_table, 'T1-T8 ~ 1', 'WithinDesign', time);

% Run repeated measures ANOVA
ranova_results = ranova(rm);
disp(ranova_results);

% Perform pairwise comparisons
mc = multcompare(rm, 'Time','ComparisonType','tukey-kramer');

% Display pairwise results
disp(mc);

end