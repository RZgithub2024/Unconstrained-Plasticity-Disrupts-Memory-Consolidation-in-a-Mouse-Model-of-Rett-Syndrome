function [mean_a,SEM_a] = MeanSem_omitnan(a)

% calculate mean and SEM, omit NaN values

mean_a = nanmean(a, 1);
n = sum(~isnan(a), 1);
SEM_a = nanstd(a, 0, 1) ./ sqrt(n);


end