function x_SEM = SEM_omitnan(x)

x_SEM = [];
for k = 1:size(x,2)
    x_SEM(k) = std(x(:,k),'omitnan')/...
        sqrt(size(x,1)-numel(find(isnan(x(:,k)))));
end

end