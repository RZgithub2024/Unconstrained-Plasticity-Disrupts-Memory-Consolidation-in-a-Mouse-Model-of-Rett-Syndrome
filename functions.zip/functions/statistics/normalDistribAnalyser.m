%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Normal Distribution Analyser%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Developed by Mr.Aswin Sekhar C S, B.Tech Electronics and Communication Engineering, National Institute of Technology Calicut 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Typical Usage of the Normal Distribution Analyser function %%%
% % % clc;
% % % clear;
% % % close all;
% % % data_normal = randn(100, 1);              % Normally distributed data
% % % data_uniform = rand(100, 1);              % Uniformly distributed data
% % % data_exponential = exprnd(2, 100, 1);     % Exponential distribution
% % % data_chi2 = chi2rnd(3, 100, 1);           % Chi-square distribution
% % % data_lognormal = lognrnd(0, 1, 100, 1);   % Lognormal distribution
% % % data_mixed = [randn(50, 1); exprnd(2, 50, 1)]; % Mixture of normal and exponential data
% % % data_to_test = {data_normal, data_uniform, data_exponential, data_chi2, data_lognormal, data_mixed};
% % % for i = 1:length(data_to_test)
% % %     fprintf('Testing data set %d:\n', i);
% % %     disp('------------------------');
% % %     normalDistribAnalyser(data_to_test{i});  % Usage of the function
% % %     fprintf('\n\n');
% % % end
%%%Inputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1. data: It is the input data in which you want to check whether it's a Normal Distribution or not. %%%
%%%Outputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1. It will compute the Histogram, Quantile-Quantile(Q-Q) Plot, Skewness and Kurtosis, Shapiro-Wilk Test, Kolmogorov-Smirnov Test, Anderson-Darling Test, Jarque-Bera Test, Lilliefors Test and plot a table with all these p-values of individual tests along with the plots and automatically tells, whether the input data is following a Normal distribution or not  %%%
%%%Theory%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1. Histogram:
% A histogram is a graphical representation of the distribution of your data. It displays the frequencies of data points within specified intervals (bins). When the histogram forms a symmetric bell-shaped curve resembling the normal distribution, it suggests that the data follows a normal distribution. Multiple peaks in the histogram indicate a departure from normality.
% 
%%% 2. Quantile-Quantile (Q-Q) Plot:
% A Q-Q plot is used to visually assess whether a dataset follows a particular theoretical distribution, such as the normal distribution. It compares the quantiles of your data to the expected quantiles of the theoretical distribution. In the case of normality, if the points on the Q-Q plot closely follow a straight line, it indicates that the data is normally distributed. Deviations from the line suggest departures from normality.
% 
%%% 3. Skewness and Kurtosis:
% Skewness measures the asymmetry of the probability distribution of a real-valued random variable. A skewness value close to 0 indicates near symmetry, while positive or negative values indicate right or left skew, respectively. Kurtosis measures the "tailedness" of the distribution. High kurtosis values suggest heavier tails compared to the normal distribution, while low values indicate lighter tails.
% 
%%% 4. Shapiro-Wilk Test:
% The Shapiro-Wilk test is a statistical test used to assess the normality of a dataset. It quantifies how well the data follows a normal distribution. The test produces a p-value, and a low p-value indicates that the data significantly deviates from normality.
% 
%%% 5. Kolmogorov-Smirnov Test:
% The Kolmogorov-Smirnov test is another goodness-of-fit test that compares the empirical distribution of the data to a specified theoretical distribution. It computes a test statistic and produces a p-value. A low p-value suggests a departure from normality.
% 
%%% 6. Anderson-Darling Test:
% The Anderson-Darling test is a statistical test that evaluates whether a dataset comes from a specific distribution, such as the normal distribution. It calculates a test statistic and provides a critical value for a given significance level. If the test statistic exceeds the critical value, the null hypothesis (normality) is rejected.
% 
%%% 7. Jarque-Bera Test:
% The Jarque-Bera test is used to assess the normality of data based on its skewness and kurtosis. It computes a test statistic that follows a chi-squared distribution. A significant test statistic indicates a departure from normality.
%
%%% 8. Lilliefors Test:
% It is a modification of the Kolmogorov-Smirnov (K-S) test that takes into account the estimated parameters (mean and standard deviation) of the dataset.A low p-value obtained from the Lilliefors test suggests a significant departure from normality, while a high p-value indicates that the data is consistent with a normal distribution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%This is the source code of the "Normal Distribution Analyser" function described in,
%%%This code is shared for non-commercial ethical research%%%%%
%%%For any queries please contact aswinsek007@gmail.com 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function normalDistribAnalyser(data)
disp('Histogram:');
figure;
subplot(1,2,1);
histogram(data);
disp('Q-Q Plot:');
subplot(1,2,2);
qqplot(data);
skew = skewness(data);
kurt = kurtosis(data);
[h_sw, p_sw] = shapiroWilk(data);
[h_ks, p_ks] = kstest(data);
[h_ad, p_ad, stats_ad] = adtest(data);
[h_jb, p_jb] = jbtest(data);
[h_lil, p_lil] = lillietest(data);
disp('--------------------------------------------------------');
disp('|   Test                |      p-value              |');
disp('---------------------------------------------------------');
disp(['| Skewness             |  ', num2str(skew),'         ']);
disp(['| Kurtosis             |  ', num2str(kurt),'         ']);
disp(['| Shapiro-Wilk         |  ', num2str(p_sw),'         ']);
disp(['| Kolmogorov-Smirnov   |  ', num2str(p_ks),'         ']);
disp(['| Anderson-Darling     |  ', num2str(p_ad),'         ']);
disp(['| Jarque-Bera          |  ', num2str(p_jb),'         ']);
disp(['| Lilliefors           |  ', num2str(p_lil),'        ']);
disp('-----------------------------------------------------------');
% if h_sw == 0 && h_ks == 0 && h_ad == 0 && h_jb == 0 && h_lil == 0
%     disp('The data is likely to be Normally distributed.');
% else
%     disp('The data does not appear to follow a Normal distribution.');
% end

if h_sw == 0
    disp('Shapiro-Wilk test: the data is likely to be normally distributed.');
else
    disp('Shapiro-Wilk test: the data does not appear to follow a normal distribution.');
end

if h_lil == 0
    disp('Lilliefors test: the data is likely to be normally distributed.');
else
    disp('Lilliefors test: the data does not appear to follow a normal distribution.');
end

end
function [hOut, Pval, wOut] = shapiroWilk(input_data, alphaValue)
if numel(input_data) == length(input_data)
    input_data  =  input_data(:);               
else
    error(' Input sample ''X'' must be a vector.');
end
input_data  =  input_data(~isnan(input_data));
if length(input_data) < 3
   error(' Sample vector ''X'' must have at least 3 valid observations.');
end
if length(input_data) > 5000
    warning('Shapiro-Wilk test might be inaccurate due to large sample size ( > 5000).');
end
if (nargin >= 2) && ~isempty(alphaValue)
   if ~isscalar(alphaValue)
      error(' Significance level ''Alpha'' must be a scalar.');
   end
   if (alphaValue <= 0 || alphaValue >= 1)
      error(' Significance level ''Alpha'' must be between 0 and 1.'); 
   end
else
   alphaValue  =  0.05;
end
input_data       =   sort(input_data); 
n       =   length(input_data);
mtilde  =   norminv(((1:n)' - 3/8) / (n + 1/4));
weights =   zeros(n,1); 
if kurtosis(input_data) > 3   
weights =   1/sqrt(mtilde'*mtilde) * mtilde;

wOut   =   (weights' * input_data)^2 / ((input_data - mean(input_data))' * (input_data - mean(input_data)));
N      =   log(n);
k1      =   log(N) - N;
k2      =   log(N) + 2/N;
M      =   -1.2725 + (1.0521 * k1);
sigma   =   1.0308 - (0.26758 * k2);
new_statistic  =   log(1 - wOut);
normal_statistic =   (new_statistic - M) / sigma;
Pval   =   1 - normcdf(normal_statistic, 0, 1);    
else
c    =   1/sqrt(mtilde'*mtilde) * mtilde;
u    =   1/sqrt(n);
PolyCoef_1   =   [-2.706056 , 4.434685 , -2.071190 , -0.147981 , 0.221157 , c(n)];
PolyCoef_2   =   [-3.582633 , 5.682633 , -1.752461 , -0.293762 , 0.042981 , c(n-1)];
PolyCoef_3   =   [-0.0006714 , 0.0250540 , -0.39978 , 0.54400];
PolyCoef_4   =   [-0.0020322 , 0.0627670 , -0.77857 , 1.38220];
PolyCoef_5   =   [0.00389150 , -0.083751 , -0.31082 , -1.5861];
PolyCoef_6   =   [0.00303020 , -0.082676 , -0.48030];
PolyCoef_7   =   [0.459 , -2.273];
weights(n)   =   polyval(PolyCoef_1 , u);
weights(1)   =   -weights(n);
if n > 5
weights(n-1) =   polyval(PolyCoef_2 , u);
weights(2)   =   -weights(n-1);

count  =   3;
phi    =   (mtilde'*mtilde - 2 * mtilde(n)^2 - 2 * mtilde(n-1)^2) / ...
(1 - 2 * weights(n)^2 - 2 * weights(n-1)^2);
else
count  =   2;
phi    =   (mtilde'*mtilde - 2 * mtilde(n)^2) / ...
(1 - 2 * weights(n)^2);
end
if n == 3
weights(1)  =   1/sqrt(2);
weights(n)  =   -weights(1);
phi = 1;
end
weights(count : n-count+1)  =  mtilde(count : n-count+1) / sqrt(phi);
wOut   =   (weights' * input_data) ^2 / ((input_data - mean(input_data))' * (input_data - mean(input_data)));
newn    =   log(n);
if (n >= 4) && (n <= 11)
M      =   polyval(PolyCoef_3 , n);
sigma   =   exp(polyval(PolyCoef_4 , n));    
gam     =   polyval(PolyCoef_7 , n);
newSWstatistic  =   -log(gam-log(1-wOut));
elseif n > 11
M      =   polyval(PolyCoef_5 , newn);
sigma   =   exp(polyval(PolyCoef_6 , newn));
newSWstatistic  =   log(1 - wOut);
elseif n == 3
M      =   0;
sigma   =   1;
newSWstatistic  =   0;
end
NormalSWstatistic   =   (newSWstatistic - M) / sigma;
Pval       =   1 - normcdf(NormalSWstatistic, 0, 1);
if n == 3
Pval  =   6/pi * (asin(sqrt(wOut)) - asin(sqrt(3/4))); 
end   
end
hOut  = (alphaValue >= Pval);
end
