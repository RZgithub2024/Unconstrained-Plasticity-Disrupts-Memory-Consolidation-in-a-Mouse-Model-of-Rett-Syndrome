function BTSP_SI_subplot(Binned_Master_WT,j,i,ii,gt,BTSP_lap,start_lap,end_lap,residue_SI_peak_bin,plot_n,outputFolder)

fig = figure('Visible', 'off');
days = [(j-1),j];

for k = 1:2

    BinnedData = Binned_Master_WT{i,days(k)};
    cell_dFoF = squeeze(BinnedData.Cells_dFoF_binned_mean(:,:,ii));
    laps = numel([BinnedData.LapStructure.LapNumber]);

    subplot(1,2,k);
    imagesc(cell_dFoF);
    hold on;
    colormap(jet);
    clim([0 2]);
    xlim([-0.5 50.5]);
    newxticks = [0.5,25.5,50.5];
    newxticklabels = {'0','90','180'};
    xticks(newxticks);
    xticklabels(newxticklabels);
    newyticks = [1,laps];
    newyticklabels = {'1',num2str(laps)};
    yticks(newyticks);
    yticklabels(newyticklabels);
    set(gca, 'TickDir', 'out');
    set(gca, 'LineWidth',1);
    set(gca, 'Box', 'off');
    xlabel('Position (cm)');
    ylabel('Laps');
    
    %set(gcf,'Position',[500 500 1000 1000]);
    set(gca,'FontSize', 18);

    if k == 1
       newtitle = {['Mouse ',num2str(i),', ROI ',num2str(ii),', ','Day ',num2str(days(k)),', ',gt]};
       title(newtitle,'FontSize',10);
       hold off;
    end

    if k == 2
        y_row = BTSP_lap;
        x_start = -0.5;
        x_end = 0.5;
        % plot the small red horizontal bar to label the 1st BTSP lap
        plot([x_start x_end], [y_row y_row], 'r-', 'LineWidth', 3);
        if ~isnan(residue_SI_peak_bin)
            x_val = residue_SI_peak_bin;
            y_start = start_lap;
            y_end = end_lap;
            % plot SI peak location
            plot([x_val x_val], [y_start y_end], 'w--', 'LineWidth', 0.5); % White dashed line

            newtitle = {['Mouse ',num2str(i),', ROI ',num2str(ii),', ','Day ',num2str(days(k)),', ',gt]};
            title(newtitle,'FontSize',10);

        elseif isnan(residue_SI_peak_bin)
            newtitle = {['Mouse ',num2str(i),', ROI ',num2str(ii),', ','Day ',...
                num2str(days(k)),', ',gt,', SI<=shuffle']};
            title(newtitle,'FontSize',10);
        end
        %colorbar; clb = colorbar(); ylabel(clb, "∆F/F"); clb.FontSize = 14; clb.Label.FontSize = 14; clb.LineWidth = 0.5;
        hold off;
    end
end

filenameString = sprintf('Plot_%04d',plot_n);
fullFileName = fullfile(outputFolder, [filenameString, '.png']);
exportgraphics(fig, fullFileName, 'Resolution', 300);
close(fig);

end