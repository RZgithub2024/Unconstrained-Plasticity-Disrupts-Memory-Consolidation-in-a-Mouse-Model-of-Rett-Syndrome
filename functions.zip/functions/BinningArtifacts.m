function [distributed,distributed_norm] = BinningArtifacts(locs)

edges1 = -90:15:270;
edges2 = -85:15:275;
edges3 = -80:15:280;

left_tail = locs(locs>90)-180;
right_tail = locs(locs<90)+180;

a = [];

distrib(1,:) = histcounts(cat(1,left_tail,locs,right_tail),edges1);
distrib(2,:) = histcounts(cat(1,left_tail,locs,right_tail),edges2);
distrib(3,:) = histcounts(cat(1,left_tail,locs,right_tail),edges3);

for j = 1:3
    for i = 1:size(distrib,2)
        a(j,i*3-2+j-1:i*3+j-1)= distrib(j,i)/3;
    end
end

distributed = nanmean(a(:,19:54),1);
distributed_norm = distributed/nansum(distributed);
end
