function [gx] = Gaussian_1d(x)
%
% Returns a [:,:,:] array where every [:,:,x] is gaussian filtered.
%%
gx = [];

f_ravel = x;
% padding = 15;
% fPad = horzcat(f((51-15+1):51),f,f(:,1:15));
w = gausswin(5);
filtered = filter(w,1,f_ravel);
filtered = circshift(filtered,-2); %%% filtering with window 5 induces an artificial 2 bin shift.
% filtered_f = reshape(filtered_cell,(size(dFoF,2)),(size(dFoF,1)))';
%filtered_cell = filter(w,1,fPad,[],2);
% filtered(i,:) = filtered_cell((padding+1):(padding+51));
gx = filtered;

end